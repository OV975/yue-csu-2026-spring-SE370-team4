$ErrorActionPreference = "Stop"

mvn clean package
