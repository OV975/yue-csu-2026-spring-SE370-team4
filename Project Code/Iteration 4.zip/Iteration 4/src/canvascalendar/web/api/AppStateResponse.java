package canvascalendar.web.api;

import java.util.List;

public record AppStateResponse(
    List<CalendarResponse> calendars,
    List<EventResponse> events,
    List<TestCaseOptionResponse> testCases,
    String activeTestCaseId
) {
}
