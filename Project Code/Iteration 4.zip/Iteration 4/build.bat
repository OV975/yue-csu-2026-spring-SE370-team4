@echo off
setlocal

mvn clean package
