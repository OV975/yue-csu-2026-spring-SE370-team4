# View And Edit In VS Code

## What You Need Installed

1. Visual Studio Code
2. JDK 17 or newer
3. Maven(optional)
4. VS Code extension `Extension Pack for Java`
5. VS Code extension `Spring Boot Extension Pack`

## Open The Project

1. Start VS Code.
2. Select `File` -> `Open Folder`.
3. Choose the project folder that contains `pom.xml`.
4. Wait for VS Code Java import to finish.

## Main Files To Edit

- `pom.xml`
- `src/canvascalendar/CanvasCalendarWebApplication.java`
- `src/canvascalendar/web/controller/CalendarApiController.java`
- `src/canvascalendar/web/service/CalendarWebService.java`
- `src/main/resources/static/index.html`
- `src/main/resources/static/app.js`
- `src/main/resources/static/styles.css`

## Run The Localhost App

### Option 1: Run And Debug

1. Open `Run and Debug`.
2. Select `Launch Canvas Calendar Plus+ Web`.
3. Press `F5`.
4. Open `http://localhost:8080`.

### Option 2: Terminal

1. Open the integrated terminal.
2. Run:

```powershell
mvn spring-boot:run
```

3. Open `http://localhost:8080`.

## Build The Project

```powershell
mvn clean package
```

## Browser App Flow

1. The browser loads `src/main/resources/static/index.html`.
2. `app.js` calls the backend at `/api/state`, `/api/events`, `/api/calendars`, and `/api/google-calendar-sync`.
3. `CalendarApiController` handles those routes.
4. `CalendarWebService` reads and writes `data/events.db` and `data/calendars.db`.

## If VS Code Does Not See Java

1. Press `Ctrl+Shift+P`
2. Run `Java: Configure Java Runtime`
3. Point VS Code to your JDK 17+ installation
