package canvascalendar.storage;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

public final class TestCaseSelectionStore {
    private static final String TEST_CASE_ID_KEY = "activeTestCaseId";

    private final Path path;

    public TestCaseSelectionStore(Path path) {
        this.path = path;
    }

    public String load() {
        if (!Files.exists(path)) {
            return null;
        }

        Properties properties = new Properties();
        try (InputStream input = Files.newInputStream(path)) {
            properties.load(input);
            return properties.getProperty(TEST_CASE_ID_KEY);
        } catch (IOException error) {
            return null;
        }
    }

    public void save(String testCaseId) throws IOException {
        if (path.getParent() != null) {
            Files.createDirectories(path.getParent());
        }

        Properties properties = new Properties();
        properties.setProperty(TEST_CASE_ID_KEY, testCaseId == null ? "" : testCaseId);
        try (OutputStream output = Files.newOutputStream(path)) {
            properties.store(output, "Canvas Calendar Plus test case selection");
        }
    }
}
