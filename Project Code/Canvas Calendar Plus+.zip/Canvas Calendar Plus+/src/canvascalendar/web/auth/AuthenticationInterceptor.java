package canvascalendar.web.auth;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

@Component
public final class AuthenticationInterceptor implements HandlerInterceptor {
    public static final String AUTHENTICATED_SESSION_KEY = "canvasCalendarAuthenticated";

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        HttpSession session = request.getSession(false);
        boolean authenticated = session != null && Boolean.TRUE.equals(session.getAttribute(AUTHENTICATED_SESSION_KEY));
        if (authenticated) {
            return true;
        }

        String requestPath = request.getRequestURI();
        if (requestPath.startsWith("/api/")) {
            response.sendError(HttpServletResponse.SC_UNAUTHORIZED, "Login required.");
            return false;
        }

        response.sendRedirect("/login");
        return false;
    }
}
