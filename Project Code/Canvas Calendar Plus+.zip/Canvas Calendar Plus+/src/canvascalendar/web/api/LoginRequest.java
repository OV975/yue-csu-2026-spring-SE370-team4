package canvascalendar.web.api;

public record LoginRequest(
    String username,
    String password
) {
}
