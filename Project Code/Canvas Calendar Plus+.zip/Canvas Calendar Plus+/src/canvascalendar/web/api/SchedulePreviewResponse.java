package canvascalendar.web.api;

import java.util.List;

public record SchedulePreviewResponse(
    String id,
    String label,
    List<SchedulePreviewItemResponse> classes
) {
}
