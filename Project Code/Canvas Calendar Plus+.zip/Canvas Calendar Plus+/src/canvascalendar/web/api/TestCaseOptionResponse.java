package canvascalendar.web.api;

public record TestCaseOptionResponse(
    String id,
    String name
) {
}
