package canvascalendar.web.api;

public record LoginResponse(
    boolean success,
    String redirectUrl,
    String message
) {
}
