package canvascalendar.web.api;

public record SchedulePreviewItemResponse(
    String title,
    String time
) {
}
