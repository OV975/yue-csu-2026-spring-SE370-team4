package canvascalendar.web.controller;

import canvascalendar.web.auth.AuthenticationInterceptor;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public final class AuthPageController {
    @GetMapping("/")
    public String home(HttpSession session) {
        return isAuthenticated(session) ? "redirect:/calendar" : "redirect:/login";
    }

    @GetMapping("/login")
    public String login(HttpSession session) {
        return isAuthenticated(session) ? "redirect:/calendar" : "forward:/login.html";
    }

    @GetMapping("/calendar")
    public String calendar(HttpSession session) {
        return isAuthenticated(session) ? "forward:/index.html" : "redirect:/login";
    }

    private boolean isAuthenticated(HttpSession session) {
        return session != null && Boolean.TRUE.equals(session.getAttribute(AuthenticationInterceptor.AUTHENTICATED_SESSION_KEY));
    }
}
