package canvascalendar.web.controller;

import canvascalendar.web.api.LoginRequest;
import canvascalendar.web.api.LoginResponse;
import canvascalendar.web.auth.AuthenticationInterceptor;
import jakarta.servlet.http.HttpSession;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

@RestController
@RequestMapping("/api/auth")
public final class AuthController {
    private static final String USERNAME = "ovilla";
    private static final String PASSWORD = "123456";

    @PostMapping("/login")
    public LoginResponse login(@RequestBody LoginRequest request, HttpSession session) {
        if (request == null) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Request body is required.");
        }

        if (!USERNAME.equals(request.username()) || !PASSWORD.equals(request.password())) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Invalid username or password.");
        }

        session.setAttribute(AuthenticationInterceptor.AUTHENTICATED_SESSION_KEY, true);
        session.setAttribute("canvasCalendarUsername", USERNAME);
        return new LoginResponse(true, "/calendar", "Login successful.");
    }

    @PostMapping("/logout")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void logout(HttpSession session) {
        session.invalidate();
    }
}
