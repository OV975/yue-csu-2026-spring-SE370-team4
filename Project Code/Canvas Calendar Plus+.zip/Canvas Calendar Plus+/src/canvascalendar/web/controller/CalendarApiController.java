package canvascalendar.web.controller;

import canvascalendar.integration.google.GoogleCalendarSyncException;
import canvascalendar.web.api.AppStateResponse;
import canvascalendar.web.api.CalendarResponse;
import canvascalendar.web.api.CalendarUpdateRequest;
import canvascalendar.web.api.EventResponse;
import canvascalendar.web.api.EventUpsertRequest;
import canvascalendar.web.api.GoogleCalendarSyncRequest;
import canvascalendar.web.api.GoogleCalendarSyncResponse;
import canvascalendar.web.service.CalendarWebService;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

@RestController
@RequestMapping("/api")
public final class CalendarApiController {
    private final CalendarWebService service;

    public CalendarApiController(CalendarWebService service) {
        this.service = service;
    }

    @GetMapping("/state")
    public AppStateResponse state() {
        return service.getState();
    }

    @PostMapping("/events")
    @ResponseStatus(HttpStatus.CREATED)
    public EventResponse createEvent(@RequestBody EventUpsertRequest request) {
        try {
            return service.createEvent(request);
        } catch (IllegalArgumentException error) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, error.getMessage());
        }
    }

    @PutMapping("/events/{id}")
    public EventResponse updateEvent(@PathVariable String id, @RequestBody EventUpsertRequest request) {
        try {
            return service.updateEvent(id, request);
        } catch (IllegalArgumentException error) {
            HttpStatus status = error.getMessage().startsWith("Event not found") ? HttpStatus.NOT_FOUND : HttpStatus.BAD_REQUEST;
            throw new ResponseStatusException(status, error.getMessage());
        }
    }

    @DeleteMapping("/events/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deleteEvent(@PathVariable String id) {
        try {
            service.deleteEvent(id);
        } catch (IllegalArgumentException error) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, error.getMessage());
        }
    }

    @PutMapping("/calendars/{id}")
    public CalendarResponse updateCalendar(@PathVariable String id, @RequestBody CalendarUpdateRequest request) {
        try {
            return service.updateCalendar(id, request == null ? null : request.visible());
        } catch (IllegalArgumentException error) {
            HttpStatus status = error.getMessage().startsWith("Calendar not found") ? HttpStatus.NOT_FOUND : HttpStatus.BAD_REQUEST;
            throw new ResponseStatusException(status, error.getMessage());
        }
    }

    @PostMapping("/google-calendar-sync")
    public GoogleCalendarSyncResponse syncGoogleCalendar(@RequestBody GoogleCalendarSyncRequest request) {
        if (request == null) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Request body is required.");
        }
        try {
            return service.syncGoogleCalendar(request.feedUrl(), request.calendarName());
        } catch (GoogleCalendarSyncException error) {
            throw new ResponseStatusException(HttpStatus.BAD_GATEWAY, error.getMessage());
        } catch (IllegalArgumentException error) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, error.getMessage());
        }
    }

    @PostMapping("/test-cases/{id}/load")
    public AppStateResponse loadTestCase(@PathVariable String id) {
        try {
            return service.loadTestCase(id);
        } catch (IllegalArgumentException error) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, error.getMessage());
        }
    }
}
