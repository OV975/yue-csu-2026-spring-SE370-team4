package canvascalendar.model;

import java.awt.Color;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public final class SampleDataFactory {
    private static final LocalDate TERM_START = LocalDate.of(2026, 1, 20);
    private static final LocalDate TERM_END = LocalDate.of(2026, 5, 8);
    private static final String TEST_CASE_PREFIX = "testcase:";
    private static final DateTimeFormatter TIME_FORMAT = DateTimeFormatter.ofPattern("h:mm a", Locale.US);
    private static final Map<String, TestCaseDefinition> TEST_CASES = buildTestCases();

    private SampleDataFactory() {
    }

    public static String defaultTestCaseId() {
        return "omar";
    }

    public static boolean isKnownTestCase(String testCaseId) {
        return TEST_CASES.containsKey(testCaseId);
    }

    public static List<TestCaseOption> availableTestCases() {
        List<TestCaseOption> options = new ArrayList<>();
        for (TestCaseDefinition definition : TEST_CASES.values()) {
            options.add(new TestCaseOption(definition.id(), definition.name()));
        }
        return options;
    }

    public static List<SchedulePreview> availableSchedulePreviews() {
        List<SchedulePreview> previews = new ArrayList<>();
        for (String testCaseId : List.of("omar", "brianna", "pike")) {
            TestCaseDefinition definition = TEST_CASES.get(testCaseId);
            if (definition == null) {
                continue;
            }

            List<ClassPreview> classes = new ArrayList<>();
            for (ClassMeeting meeting : definition.classes()) {
                classes.add(new ClassPreview(
                    meeting.code(),
                    TIME_FORMAT.format(meeting.startTime())
                ));
            }
            previews.add(new SchedulePreview(definition.id(), definition.personName(), classes));
        }
        return previews;
    }

    public static TestCaseSchedule createTestCaseSchedule(String testCaseId) {
        TestCaseDefinition definition = TEST_CASES.get(testCaseId);
        if (definition == null) {
            throw new IllegalArgumentException("Unknown test case: " + testCaseId);
        }

        List<CourseCalendar> calendars = new ArrayList<>();
        List<CalendarEvent> events = new ArrayList<>();

        for (int index = 0; index < definition.classes().size(); index += 1) {
            ClassMeeting meeting = definition.classes().get(index);
            String calendarId = calendarId(definition.id(), meeting.code());
            calendars.add(new CourseCalendar(calendarId, meeting.code(), colorForIndex(index)));

            for (LocalDate date = TERM_START; !date.isAfter(TERM_END); date = date.plusDays(1)) {
                if (!meeting.days().contains(date.getDayOfWeek())) {
                    continue;
                }
                LocalDateTime start = LocalDateTime.of(date, meeting.startTime());
                LocalDateTime end = LocalDateTime.of(date, meeting.endTime());
                events.add(new CalendarEvent(
                    eventId(definition.id(), meeting.code(), date),
                    meeting.code(),
                    calendarId,
                    start,
                    end,
                    meeting.location(),
                    "Class starts at " + TIME_FORMAT.format(meeting.startTime()) + "."
                ));
            }
        }

        return new TestCaseSchedule(definition.id(), definition.name(), calendars, events);
    }

    public static boolean isManagedTestCaseCalendar(String testCaseId, String calendarId) {
        return calendarId != null && calendarId.startsWith(TEST_CASE_PREFIX + testCaseId + ":calendar:");
    }

    public static boolean isManagedTestCaseEvent(String testCaseId, String eventId) {
        return eventId != null && eventId.startsWith(TEST_CASE_PREFIX + testCaseId + ":event:");
    }

    public static List<CourseCalendar> createCalendars() {
        return createTestCaseSchedule(defaultTestCaseId()).calendars();
    }

    public static List<CalendarEvent> createEvents(LocalDate ignoredAnchorDate) {
        return createTestCaseSchedule(defaultTestCaseId()).events();
    }

    private static Map<String, TestCaseDefinition> buildTestCases() {
        Map<String, TestCaseDefinition> definitions = new LinkedHashMap<>();

        definitions.put("brianna", new TestCaseDefinition(
            "brianna",
            "Brianna's Courses",
            "Brianna",
            List.of(
                classMeeting("CS 310-02 LEC (23275)", List.of(DayOfWeek.MONDAY, DayOfWeek.WEDNESDAY, DayOfWeek.FRIDAY), 8, 30, 9, 20, "University Hall 272"),
                classMeeting("CS 311-01 LEC (20818)", List.of(DayOfWeek.MONDAY, DayOfWeek.WEDNESDAY, DayOfWeek.FRIDAY), 9, 30, 10, 20, "Academic Hall 201"),
                classMeeting("CS 351-04 LEC (23278)", List.of(DayOfWeek.TUESDAY, DayOfWeek.THURSDAY), 7, 30, 8, 45, "Markstein Hall 106"),
                classMeeting("SE 370-10 LEC (20629)", List.of(DayOfWeek.MONDAY, DayOfWeek.WEDNESDAY), 13, 30, 14, 20, "University Hall 272"),
                classMeeting("SE 370-11A LAB (20630)", List.of(DayOfWeek.MONDAY, DayOfWeek.WEDNESDAY), 16, 0, 17, 15, "Academic Hall 206")
            )
        ));

        definitions.put("omar", new TestCaseDefinition(
            "omar",
            "Omar's Courses",
            "Omar",
            List.of(
                classMeeting("BUS 303-01 LEC (23849)", List.of(DayOfWeek.TUESDAY, DayOfWeek.THURSDAY), 19, 0, 20, 15, "Synchronous Virtual Instr"),
                classMeeting("CS 351-03 LEC (20569)", List.of(DayOfWeek.MONDAY, DayOfWeek.WEDNESDAY), 14, 30, 15, 45, "University Hall 272"),
                classMeeting("CS 433-04 LEC (22992)", List.of(DayOfWeek.MONDAY, DayOfWeek.WEDNESDAY, DayOfWeek.FRIDAY), 10, 30, 11, 20, "University Hall 272"),
                classMeeting("CS 436-01 LEC (20559)", List.of(DayOfWeek.TUESDAY, DayOfWeek.THURSDAY), 9, 0, 10, 15, "Academic Hall 206"),
                classMeeting("SE 370-10 LEC (20629)", List.of(DayOfWeek.MONDAY, DayOfWeek.WEDNESDAY), 13, 30, 14, 20, "University Hall 272"),
                classMeeting("SE 370-11A LAB (20630)", List.of(DayOfWeek.MONDAY, DayOfWeek.WEDNESDAY), 16, 0, 17, 15, "Academic Hall 206")
            )
        ));

        definitions.put("pike", new TestCaseDefinition(
            "pike",
            "Pike's Courses",
            "Pike",
            List.of(
                classMeeting("CS 351-02 LEC (20566)", List.of(DayOfWeek.MONDAY, DayOfWeek.WEDNESDAY, DayOfWeek.FRIDAY), 10, 30, 11, 20, "Academic Hall 206"),
                classMeeting("DNCE 390-10 LEC (21717)", List.of(DayOfWeek.TUESDAY, DayOfWeek.THURSDAY), 16, 0, 16, 50, "Arts Building 101"),
                classMeeting("DNCE 390-11A ACT (21718)", List.of(DayOfWeek.TUESDAY, DayOfWeek.THURSDAY), 17, 0, 17, 50, "Arts Building 101"),
                classMeeting("GEO 102-17 LEC (21319)", List.of(DayOfWeek.MONDAY, DayOfWeek.WEDNESDAY), 14, 30, 15, 45, "Academic Hall 301"),
                classMeeting("MATH 242-04 LEC (20851)", List.of(DayOfWeek.TUESDAY, DayOfWeek.THURSDAY), 14, 30, 15, 45, "Academic Hall 411A"),
                classMeeting("SE 370-10 LEC (20629)", List.of(DayOfWeek.MONDAY, DayOfWeek.WEDNESDAY), 13, 30, 14, 20, "University Hall 272"),
                classMeeting("SE 370-11A LAB (20630)", List.of(DayOfWeek.MONDAY, DayOfWeek.WEDNESDAY), 16, 0, 17, 15, "Academic Hall 206")
            )
        ));

        return definitions;
    }

    private static ClassMeeting classMeeting(
        String code,
        List<DayOfWeek> days,
        int startHour,
        int startMinute,
        int endHour,
        int endMinute,
        String location
    ) {
        return new ClassMeeting(code, days, LocalTime.of(startHour, startMinute), LocalTime.of(endHour, endMinute), location);
    }

    private static String calendarId(String testCaseId, String courseCode) {
        return TEST_CASE_PREFIX + testCaseId + ":calendar:" + slug(courseCode);
    }

    private static String eventId(String testCaseId, String courseCode, LocalDate date) {
        return TEST_CASE_PREFIX + testCaseId + ":event:" + slug(courseCode) + ":" + date;
    }

    private static String slug(String value) {
        return value.toLowerCase(Locale.US)
            .replaceAll("[^a-z0-9]+", "-")
            .replaceAll("(^-|-$)", "");
    }

    private static Color colorForIndex(int index) {
        Color[] palette = {
            new Color(0x4C72B0),
            new Color(0xD47A00),
            new Color(0x1F7A65),
            new Color(0x7B4DB3),
            new Color(0x2196E3),
            new Color(0xF44336),
            new Color(0x2E8B73)
        };
        return palette[index % palette.length];
    }

    public record TestCaseOption(
        String id,
        String name
    ) {
    }

    public record TestCaseSchedule(
        String id,
        String name,
        List<CourseCalendar> calendars,
        List<CalendarEvent> events
    ) {
    }

    public record SchedulePreview(
        String id,
        String personName,
        List<ClassPreview> classes
    ) {
    }

    public record ClassPreview(
        String title,
        String time
    ) {
    }

    private record TestCaseDefinition(
        String id,
        String name,
        String personName,
        List<ClassMeeting> classes
    ) {
    }

    private record ClassMeeting(
        String code,
        List<DayOfWeek> days,
        LocalTime startTime,
        LocalTime endTime,
        String location
    ) {
    }
}
