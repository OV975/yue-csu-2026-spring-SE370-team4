package canvascalendar.ui;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAdjusters;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JSeparator;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

import canvascalendar.model.CalendarEvent;
import canvascalendar.model.CalendarView;
import canvascalendar.model.CourseCalendar;
import canvascalendar.model.SampleDataFactory;
import canvascalendar.storage.CourseCalendarStore;
import canvascalendar.storage.CsvExporter;
import canvascalendar.storage.EventStore;
import canvascalendar.ui.theme.ThemedBackgroundPanel;
import canvascalendar.ui.theme.UiTheme;
import canvascalendar.ui.theme.UiThemeStore;

public final class CanvasCalendarFrame extends JFrame {
    private static final DateTimeFormatter TITLE_MONTH = DateTimeFormatter.ofPattern("MMMM yyyy");
    private static final DateTimeFormatter TITLE_WEEK = DateTimeFormatter.ofPattern("MMM d");
    private static final Color MUTED_TEXT = new Color(0x6B778C);

    private final Path storePath = Paths.get("data", "events.db");
    private final Path calendarStorePath = Paths.get("data", "calendars.db");
    private final Path themeStorePath = Paths.get("data", "ui-theme.properties");
    private final Path exportPath = Paths.get("data", "calendar-export.csv");

    private final EventStore eventStore = new EventStore(storePath);
    private final CourseCalendarStore calendarStore = new CourseCalendarStore(calendarStorePath);
    private final UiThemeStore themeStore = new UiThemeStore(themeStorePath);
    private final CsvExporter csvExporter = new CsvExporter();

    private final List<CourseCalendar> calendars = new ArrayList<>();
    private final List<CalendarEvent> events = new ArrayList<>();
    private final Map<String, CourseCalendar> calendarIndex = new HashMap<>();
    private final Map<CalendarView, JButton> viewButtons = new EnumMap<>(CalendarView.class);

    private final JLabel titleLabel = new JLabel();
    private final JLabel subtitleLabel = new JLabel("Assignments and events across all courses");
    private final JPanel mainViewPanel = new JPanel(new CardLayout());
    private final JPanel miniMonthPanel = new JPanel(new java.awt.GridLayout(0, 7, 4, 4));
    private final JPanel calendarListPanel = new JPanel();
    private final JPanel upcomingPanel = new JPanel();
    private final JTextField searchField = new JTextField(18);
    private final ThemedBackgroundPanel rootPanel;

    private final MonthViewPanel monthViewPanel = new MonthViewPanel();
    private final WeekViewPanel weekViewPanel = new WeekViewPanel();
    private final AgendaViewPanel agendaViewPanel = new AgendaViewPanel();

    private JPanel sidebarPanel;
    private JPanel headerPanel;
    private JPanel bodyPanel;
    private UiTheme theme;
    private LocalDate focusDate = LocalDate.now();
    private CalendarView currentView = CalendarView.MONTH;
    private String searchQuery = "";

    public CanvasCalendarFrame() {
        super("Canvas Calendar Plus+");
        this.theme = themeStore.load();
        this.rootPanel = new ThemedBackgroundPanel(theme);

        setContentPane(rootPanel);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setMinimumSize(new Dimension(1360, 860));
        setSize(1440, 900);
        setLocationRelativeTo(null);

        loadState();
        buildUi();
        applyTheme();
        refreshAll();
    }

    private void loadState() {
        try {
            events.addAll(eventStore.load());
        } catch (Exception error) {
            events.clear();
        }

        try {
            calendars.addAll(calendarStore.load());
        } catch (Exception error) {
            calendars.clear();
        }

        if (calendars.isEmpty()) {
            calendars.addAll(SampleDataFactory.createCalendars());
        }
        if (events.isEmpty()) {
            events.addAll(SampleDataFactory.createEvents(LocalDate.now()));
            persistStores();
        }

        ensureCalendarsForEvents();
        rebuildCalendarIndex();
        events.sort(CalendarEvent.BY_START);
    }

    private void buildUi() {
        rootPanel.setLayout(new BorderLayout(16, 16));
        rootPanel.setBorder(BorderFactory.createEmptyBorder(16, 16, 16, 16));

        sidebarPanel = buildSidebar();
        headerPanel = buildHeader();

        bodyPanel = new JPanel(new BorderLayout(0, 12));
        bodyPanel.setOpaque(false);
        bodyPanel.add(headerPanel, BorderLayout.NORTH);
        bodyPanel.add(buildMainView(), BorderLayout.CENTER);

        rootPanel.add(sidebarPanel, BorderLayout.WEST);
        rootPanel.add(bodyPanel, BorderLayout.CENTER);
    }

    private JPanel buildSidebar() {
        JPanel sidebar = new JPanel();
        sidebar.setLayout(new BoxLayout(sidebar, BoxLayout.Y_AXIS));
        sidebar.setPreferredSize(new Dimension(300, 0));

        JLabel logo = new JLabel("Calendar");
        logo.setFont(logo.getFont().deriveFont(Font.BOLD, scaled(24f)));
        sidebar.add(logo);
        sidebar.add(Box.createVerticalStrut(6));

        subtitleLabel.setForeground(MUTED_TEXT);
        subtitleLabel.setFont(subtitleLabel.getFont().deriveFont(scaled(12f)));
        sidebar.add(subtitleLabel);
        sidebar.add(Box.createVerticalStrut(14));

        sidebar.add(sectionLabel("Search"));
        configureSearchField();
        sidebar.add(searchField);
        sidebar.add(Box.createVerticalStrut(18));

        JButton addButton = new JButton("Add Event");
        addButton.addActionListener(e -> openCreateDialog(focusDate));
        sidebar.add(addButton);
        sidebar.add(Box.createVerticalStrut(10));

        JButton customizeButton = new JButton("Customize UI");
        customizeButton.addActionListener(e -> openCustomizationDialog());
        sidebar.add(customizeButton);
        sidebar.add(Box.createVerticalStrut(18));

        sidebar.add(sectionLabel("Mini Month"));
        miniMonthPanel.setOpaque(false);
        sidebar.add(miniMonthPanel);
        sidebar.add(Box.createVerticalStrut(18));

        sidebar.add(sectionLabel("Calendars"));
        calendarListPanel.setOpaque(false);
        calendarListPanel.setLayout(new BoxLayout(calendarListPanel, BoxLayout.Y_AXIS));
        sidebar.add(calendarListPanel);

        sidebar.add(Box.createVerticalStrut(18));
        sidebar.add(sectionLabel("Upcoming"));
        upcomingPanel.setOpaque(false);
        upcomingPanel.setLayout(new BoxLayout(upcomingPanel, BoxLayout.Y_AXIS));
        sidebar.add(upcomingPanel);
        sidebar.add(Box.createVerticalGlue());
        return sidebar;
    }

    private JPanel buildHeader() {
        JPanel header = new JPanel(new BorderLayout());

        JPanel left = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        left.setOpaque(false);

        JButton previousButton = new JButton("<");
        previousButton.addActionListener(e -> moveRange(-1));
        JButton todayButton = new JButton("Today");
        todayButton.addActionListener(e -> {
            focusDate = LocalDate.now();
            refreshAll();
        });
        JButton nextButton = new JButton(">");
        nextButton.addActionListener(e -> moveRange(1));

        titleLabel.setFont(titleLabel.getFont().deriveFont(Font.BOLD, scaled(26f)));

        left.add(previousButton);
        left.add(todayButton);
        left.add(nextButton);
        left.add(new JSeparator(SwingConstants.VERTICAL));
        left.add(titleLabel);

        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        right.setOpaque(false);
        JButton exportButton = new JButton("Export CSV");
        exportButton.addActionListener(e -> exportVisibleEvents());
        right.add(exportButton);
        right.add(createViewButton("Month", CalendarView.MONTH));
        right.add(createViewButton("Week", CalendarView.WEEK));
        right.add(createViewButton("Agenda", CalendarView.AGENDA));

        header.add(left, BorderLayout.WEST);
        header.add(right, BorderLayout.EAST);
        return header;
    }

    private JLabel sectionLabel(String text) {
        JLabel label = new JLabel(text);
        label.setFont(label.getFont().deriveFont(Font.BOLD, scaled(13f)));
        label.setBorder(BorderFactory.createEmptyBorder(0, 0, 8, 0));
        return label;
    }

    private JButton createViewButton(String label, CalendarView view) {
        JButton button = new JButton(label);
        button.addActionListener(e -> {
            currentView = view;
            refreshAll();
        });
        viewButtons.put(view, button);
        return button;
    }

    private JPanel buildMainView() {
        JPanel wrapper = new JPanel(new BorderLayout());
        wrapper.setOpaque(false);

        mainViewPanel.setOpaque(false);
        mainViewPanel.add(monthViewPanel, CalendarView.MONTH.name());
        mainViewPanel.add(weekViewPanel, CalendarView.WEEK.name());
        mainViewPanel.add(agendaViewPanel, CalendarView.AGENDA.name());

        wrapper.add(mainViewPanel, BorderLayout.CENTER);
        return wrapper;
    }

    private void moveRange(int delta) {
        switch (currentView) {
            case MONTH -> focusDate = focusDate.plusMonths(delta);
            case WEEK -> focusDate = focusDate.plusWeeks(delta);
            case AGENDA -> focusDate = focusDate.plusDays(delta * 7L);
            default -> {
            }
        }
        refreshAll();
    }

    private void refreshAll() {
        titleLabel.setText(createTitle());
        applyTheme();
        refreshViewButtons();
        refreshCalendarToggles();
        refreshMiniMonth();
        refreshUpcoming();
        refreshMainView();
    }

    private String createTitle() {
        switch (currentView) {
            case WEEK:
                LocalDate start = focusDate.with(TemporalAdjusters.previousOrSame(DayOfWeek.SUNDAY));
                LocalDate end = start.plusDays(6);
                return TITLE_WEEK.format(start) + " - " + end.format(DateTimeFormatter.ofPattern("MMM d, yyyy"));
            case AGENDA:
                return "Agenda starting " + focusDate.format(DateTimeFormatter.ofPattern("MMM d, yyyy"));
            case MONTH:
            default:
                return TITLE_MONTH.format(focusDate);
        }
    }

    private void applyTheme() {
        Color borderColor = mix(theme.getSurfaceColor(), Color.BLACK, 0.15);
        rootPanel.setTheme(theme);
        sidebarPanel.setBackground(theme.getSidebarBackgroundColor());
        sidebarPanel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(borderColor),
            BorderFactory.createEmptyBorder(16, 16, 16, 16)
        ));
        headerPanel.setBackground(theme.getSurfaceColor());
        headerPanel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(borderColor),
            BorderFactory.createEmptyBorder(14, 16, 14, 16)
        ));
        titleLabel.setFont(titleLabel.getFont().deriveFont(Font.BOLD, scaled(26f)));
        subtitleLabel.setFont(subtitleLabel.getFont().deriveFont(scaled(12f)));
        mainViewPanel.repaint();
        rootPanel.repaint();
    }

    private void refreshMiniMonth() {
        miniMonthPanel.removeAll();
        LocalDate first = YearMonth.from(focusDate).atDay(1);
        LocalDate gridStart = first.with(TemporalAdjusters.previousOrSame(DayOfWeek.SUNDAY));
        Color borderColor = mix(theme.getSurfaceColor(), Color.BLACK, 0.15);
        Color selected = mix(theme.getSurfaceColor(), theme.getAccentColor(), 0.18);

        String[] headers = {"S", "M", "T", "W", "T", "F", "S"};
        for (String header : headers) {
            JLabel label = new JLabel(header, SwingConstants.CENTER);
            label.setForeground(MUTED_TEXT);
            label.setFont(label.getFont().deriveFont(scaled(11f)));
            miniMonthPanel.add(label);
        }

        for (int index = 0; index < 42; index++) {
            LocalDate date = gridStart.plusDays(index);
            JButton button = new JButton(String.valueOf(date.getDayOfMonth()));
            button.setMargin(new java.awt.Insets(2, 2, 2, 2));
            button.setFocusPainted(false);
            button.setBackground(theme.getSurfaceColor());
            button.setBorder(BorderFactory.createLineBorder(borderColor));
            button.setFont(button.getFont().deriveFont(scaled(11f)));
            if (!YearMonth.from(date).equals(YearMonth.from(focusDate))) {
                button.setForeground(new Color(0x9AA5B1));
            }
            if (date.equals(LocalDate.now())) {
                button.setBorder(BorderFactory.createLineBorder(theme.getAccentColor(), 2));
            }
            if (date.equals(focusDate)) {
                button.setBackground(selected);
            }
            button.addActionListener(e -> {
                focusDate = date;
                refreshAll();
            });
            miniMonthPanel.add(button);
        }
        miniMonthPanel.revalidate();
        miniMonthPanel.repaint();
    }

    private void refreshUpcoming() {
        upcomingPanel.removeAll();
        List<CalendarEvent> filtered = getVisibleEvents();
        filtered.sort(Comparator.comparing(CalendarEvent::getStart));

        int shown = 0;
        for (CalendarEvent event : filtered) {
            if (event.getEnd().toLocalDate().isBefore(LocalDate.now())) {
                continue;
            }
            upcomingPanel.add(createUpcomingItem(event));
            shown++;
            if (shown >= 6) {
                break;
            }
        }

        if (shown == 0) {
            JLabel label = new JLabel("No upcoming items");
            label.setForeground(MUTED_TEXT);
            label.setFont(label.getFont().deriveFont(scaled(12f)));
            upcomingPanel.add(label);
        }

        upcomingPanel.revalidate();
        upcomingPanel.repaint();
    }

    private Component createUpcomingItem(CalendarEvent event) {
        CourseCalendar calendar = calendarIndex.get(event.getCourseId());
        JLabel label = new JLabel("<html><b>" + escape(event.getTitle()) + "</b><br/>"
            + escape(event.getStart().format(DateTimeFormatter.ofPattern("MMM d, h:mm a")))
            + (calendar == null ? "" : "<br/>" + escape(calendar.getName()))
            + "</html>");
        label.setFont(label.getFont().deriveFont(scaled(12f)));
        label.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(0, 4, 0, 0, calendar == null ? theme.getAccentColor() : calendar.getColor()),
            BorderFactory.createEmptyBorder(6, 8, 10, 8)
        ));

        JPanel wrapper = new JPanel(new BorderLayout());
        wrapper.setOpaque(false);
        wrapper.add(label, BorderLayout.CENTER);
        return wrapper;
    }

    private void refreshMainView() {
        List<CalendarEvent> filteredEvents = getVisibleEvents();
        monthViewPanel.render(
            focusDate,
            LocalDate.now(),
            filteredEvents,
            calendarIndex,
            theme,
            this::setFocusDate,
            this::openCreateDialog,
            this::openEditDialog
        );
        weekViewPanel.render(
            focusDate,
            LocalDate.now(),
            filteredEvents,
            calendarIndex,
            theme,
            this::setFocusDate,
            this::openCreateDialog,
            this::openEditDialog
        );
        agendaViewPanel.render(
            focusDate,
            filteredEvents,
            calendarIndex,
            theme,
            this::openEditDialog
        );

        CardLayout layout = (CardLayout) mainViewPanel.getLayout();
        layout.show(mainViewPanel, currentView.name());
        repaint();
    }

    private void refreshViewButtons() {
        Color borderColor = mix(theme.getSurfaceColor(), Color.BLACK, 0.15);
        for (Map.Entry<CalendarView, JButton> entry : viewButtons.entrySet()) {
            boolean active = entry.getKey() == currentView;
            JButton button = entry.getValue();
            button.setBackground(active ? theme.getAccentColor() : theme.getSurfaceColor());
            button.setForeground(active ? Color.WHITE : Color.BLACK);
            button.setOpaque(true);
            button.setBorder(BorderFactory.createLineBorder(active ? theme.getAccentColor() : borderColor));
            button.setFont(button.getFont().deriveFont(scaled(12f)));
        }
    }

    private void refreshCalendarToggles() {
        calendarListPanel.removeAll();
        for (CourseCalendar calendar : calendars) {
            calendarListPanel.add(buildCalendarToggle(calendar));
        }
        calendarListPanel.revalidate();
        calendarListPanel.repaint();
    }

    private Component buildCalendarToggle(CourseCalendar calendar) {
        JCheckBox checkBox = new JCheckBox(calendar.getName(), calendar.isVisible());
        checkBox.setOpaque(false);
        checkBox.setForeground(calendar.getColor().darker());
        checkBox.setFont(checkBox.getFont().deriveFont(scaled(12f)));
        checkBox.addActionListener(e -> {
            calendar.setVisible(checkBox.isSelected());
            persistAndRefresh();
        });

        JPanel wrapper = new JPanel(new BorderLayout());
        wrapper.setOpaque(false);
        wrapper.setBorder(BorderFactory.createEmptyBorder(0, 0, 8, 0));
        wrapper.add(checkBox, BorderLayout.CENTER);
        return wrapper;
    }

    private void setFocusDate(LocalDate date) {
        focusDate = date;
        refreshAll();
    }

    private List<CalendarEvent> getVisibleEvents() {
        List<CalendarEvent> filtered = new ArrayList<>();
        for (CalendarEvent event : events) {
            CourseCalendar calendar = calendarIndex.get(event.getCourseId());
            if (calendar != null && calendar.isVisible() && matchesSearch(event, calendar)) {
                filtered.add(event);
            }
        }
        filtered.sort(CalendarEvent.BY_START);
        return filtered;
    }

    private void openCreateDialog(LocalDate date) {
        EventEditorDialog.Result result = EventEditorDialog.showDialog(this, calendars, null, date);
        if (result == null || result.getEvent() == null) {
            return;
        }
        events.add(result.getEvent());
        events.sort(CalendarEvent.BY_START);
        persistAndRefresh();
    }

    private void openEditDialog(CalendarEvent source) {
        EventEditorDialog.Result result = EventEditorDialog.showDialog(this, calendars, source.copy(), source.getStart().toLocalDate());
        if (result == null) {
            return;
        }
        if (result.isDeleted()) {
            events.removeIf(existing -> existing.getId().equals(source.getId()));
            persistAndRefresh();
            return;
        }
        CalendarEvent updated = result.getEvent();
        if (updated == null) {
            return;
        }
        for (int index = 0; index < events.size(); index++) {
            if (events.get(index).getId().equals(source.getId())) {
                events.set(index, updated);
                break;
            }
        }
        events.sort(CalendarEvent.BY_START);
        persistAndRefresh();
    }

    private void openCustomizationDialog() {
        UiTheme updated = UiCustomizationDialog.showDialog(this, theme);
        if (updated == null) {
            return;
        }
        theme = updated;
        try {
            themeStore.save(theme);
        } catch (Exception error) {
            JOptionPane.showMessageDialog(this, "Unable to save UI customization settings.", "Theme save error", JOptionPane.ERROR_MESSAGE);
        }
        refreshAll();
    }

    private void persistAndRefresh() {
        persistStores();
        refreshAll();
    }

    private void persistStores() {
        try {
            eventStore.save(events);
            calendarStore.save(calendars);
        } catch (Exception error) {
            JOptionPane.showMessageDialog(this, "Unable to save calendar data.", "Save error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void configureSearchField() {
        searchField.setMaximumSize(new Dimension(Integer.MAX_VALUE, 30));
        searchField.setFont(searchField.getFont().deriveFont(scaled(12f)));
        searchField.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
                updateSearch();
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                updateSearch();
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                updateSearch();
            }
        });
    }

    private void updateSearch() {
        searchQuery = searchField.getText().trim().toLowerCase();
        refreshAll();
    }

    private boolean matchesSearch(CalendarEvent event, CourseCalendar calendar) {
        if (searchQuery.isEmpty()) {
            return true;
        }

        String haystack = String.join(" ",
            event.getTitle(),
            event.getLocation(),
            event.getDetails(),
            calendar.getName()
        ).toLowerCase();
        return haystack.contains(searchQuery);
    }

    private void rebuildCalendarIndex() {
        calendarIndex.clear();
        for (CourseCalendar calendar : calendars) {
            calendarIndex.put(calendar.getId(), calendar);
        }
    }

    private void ensureCalendarsForEvents() {
        Set<String> knownIds = new HashSet<>();
        for (CourseCalendar calendar : calendars) {
            knownIds.add(calendar.getId());
        }

        for (CalendarEvent event : events) {
            if (knownIds.contains(event.getCourseId())) {
                continue;
            }
            CourseCalendar fallback = new CourseCalendar(event.getCourseId(), "Imported Calendar", new Color(0x6B7280));
            calendars.add(fallback);
            knownIds.add(fallback.getId());
        }
    }

    private void exportVisibleEvents() {
        try {
            csvExporter.export(exportPath, getVisibleEvents(), calendarIndex);
            JOptionPane.showMessageDialog(this, "Exported current calendar view to " + exportPath + ".", "Export complete", JOptionPane.INFORMATION_MESSAGE);
        } catch (Exception error) {
            JOptionPane.showMessageDialog(this, "Unable to export events to " + exportPath + ".", "Export error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private float scaled(float size) {
        return theme.isLargeText() ? size + 2f : size;
    }

    private Color mix(Color first, Color second, double amountSecond) {
        double amountFirst = 1.0 - amountSecond;
        int red = (int) Math.round((first.getRed() * amountFirst) + (second.getRed() * amountSecond));
        int green = (int) Math.round((first.getGreen() * amountFirst) + (second.getGreen() * amountSecond));
        int blue = (int) Math.round((first.getBlue() * amountFirst) + (second.getBlue() * amountSecond));
        return new Color(red, green, blue);
    }

    private String escape(String value) {
        return value.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
    }
}
