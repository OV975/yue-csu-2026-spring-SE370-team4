const STORAGE_KEYS = {
  theme: "canvas-calendar-plus.theme",
  backgroundImage: "canvas-calendar-plus.background-image",
  floatingWidgets: "canvas-calendar-plus.floating-widgets",
  accentRgb: "canvas-calendar-plus.accent-rgb",
  sectionState: "canvas-calendar-plus.section-state"
};

const POP_IN_DURATION_MS = 260;
const MAX_BACKGROUND_DIMENSION = 1920;
const BACKGROUND_EXPORT_QUALITIES = [0.82, 0.68, 0.56];
const FLOATING_MARGIN = 12;
const PANEL_SNAP_THRESHOLD = 22;
const PANEL_SNAP_GAP = 12;

const state = {
  calendars: [],
  events: [],
  testCases: [],
  schedulePreviews: [],
  activeTestCaseId: "",
  focusDate: new Date(2026, 0, 20),
  view: "month",
  search: "",
  theme: localStorage.getItem(STORAGE_KEYS.theme) || "light",
  backgroundImage: localStorage.getItem(STORAGE_KEYS.backgroundImage) || "",
  accentRgb: loadAccentRgb(),
  sectionState: loadSectionState(),
  floatingWidgets: loadFloatingWidgets(),
  dragging: null,
  widgetPopTimers: new Map()
};

const resizeObserver = typeof ResizeObserver === "function"
  ? new ResizeObserver(handleWidgetResize)
  : null;

const elements = {
  root: document.documentElement,
  body: document.body,
  searchInput: document.getElementById("searchInput"),
  testCaseSelect: document.getElementById("testCaseSelect"),
  loadTestCaseButton: document.getElementById("loadTestCaseButton"),
  calendarFilters: document.getElementById("calendarFilters"),
  upcomingList: document.getElementById("upcomingList"),
  monthView: document.getElementById("monthView"),
  agendaView: document.getElementById("agendaView"),
  viewTitle: document.getElementById("viewTitle"),
  miniMonthTitle: document.getElementById("miniMonthTitle"),
  miniMonthGrid: document.getElementById("miniMonthGrid"),
  prevButton: document.getElementById("prevButton"),
  nextButton: document.getElementById("nextButton"),
  miniPrevButton: document.getElementById("miniPrevButton"),
  miniNextButton: document.getElementById("miniNextButton"),
  todayButton: document.getElementById("todayButton"),
  monthViewButton: document.getElementById("monthViewButton"),
  agendaViewButton: document.getElementById("agendaViewButton"),
  addEventButton: document.getElementById("addEventButton"),
  settingsButton: document.getElementById("settingsButton"),
  eventDialog: document.getElementById("eventDialog"),
  eventForm: document.getElementById("eventForm"),
  eventDialogTitle: document.getElementById("eventDialogTitle"),
  eventId: document.getElementById("eventId"),
  eventTitle: document.getElementById("eventTitle"),
  eventCalendar: document.getElementById("eventCalendar"),
  eventStart: document.getElementById("eventStart"),
  eventEnd: document.getElementById("eventEnd"),
  eventLocation: document.getElementById("eventLocation"),
  eventDetails: document.getElementById("eventDetails"),
  deleteEventButton: document.getElementById("deleteEventButton"),
  cancelEventButton: document.getElementById("cancelEventButton"),
  syncGoogleCalendarButton: document.getElementById("syncGoogleCalendarButton"),
  syncDialog: document.getElementById("syncDialog"),
  syncForm: document.getElementById("syncForm"),
  googleCalendarFeedUrl: document.getElementById("googleCalendarFeedUrl"),
  googleCalendarName: document.getElementById("googleCalendarName"),
  cancelSyncButton: document.getElementById("cancelSyncButton"),
  settingsDialog: document.getElementById("settingsDialog"),
  themeModeSelect: document.getElementById("themeModeSelect"),
  accentRedInput: document.getElementById("accentRedInput"),
  accentGreenInput: document.getElementById("accentGreenInput"),
  accentBlueInput: document.getElementById("accentBlueInput"),
  accentPreview: document.getElementById("accentPreview"),
  accentValueLabel: document.getElementById("accentValueLabel"),
  backgroundImageInput: document.getElementById("backgroundImageInput"),
  backgroundStatus: document.getElementById("backgroundStatus"),
  clearBackgroundButton: document.getElementById("clearBackgroundButton"),
  resetLayoutButton: document.getElementById("resetLayoutButton"),
  closeSettingsButton: document.getElementById("closeSettingsButton"),
  sectionToggles: Array.from(document.querySelectorAll("[data-section-toggle]")),
  sectionBodies: Array.from(document.querySelectorAll("[data-section-body]")),
  widgets: Array.from(document.querySelectorAll(".widget"))
};

document.addEventListener("DOMContentLoaded", async () => {
  applyStoredAppearance();
  updateBackgroundStatus();
  wireEvents();
  initializeWidgets();

  try {
    await refreshState();
    render();
  } catch (error) {
    console.error(error);
    alert(error?.message || "Unable to load the calendar state.");
  }
});

function wireEvents() {
  elements.searchInput.addEventListener("input", () => {
    state.search = elements.searchInput.value.trim().toLowerCase();
    render();
  });
  elements.loadTestCaseButton.addEventListener("click", onLoadTestCase);

  elements.prevButton.addEventListener("click", () => {
    state.focusDate = new Date(state.focusDate.getFullYear(), state.focusDate.getMonth() - 1, 1);
    render();
  });

  elements.nextButton.addEventListener("click", () => {
    state.focusDate = new Date(state.focusDate.getFullYear(), state.focusDate.getMonth() + 1, 1);
    render();
  });

  elements.miniPrevButton.addEventListener("click", () => {
    state.focusDate = new Date(state.focusDate.getFullYear(), state.focusDate.getMonth() - 1, 1);
    render();
  });

  elements.miniNextButton.addEventListener("click", () => {
    state.focusDate = new Date(state.focusDate.getFullYear(), state.focusDate.getMonth() + 1, 1);
    render();
  });

  elements.todayButton.addEventListener("click", () => {
    state.focusDate = new Date();
    render();
  });

  elements.monthViewButton.addEventListener("click", () => setView("month"));
  elements.agendaViewButton.addEventListener("click", () => setView("agenda"));
  elements.addEventButton.addEventListener("click", () => openEventDialog());
  elements.cancelEventButton.addEventListener("click", () => elements.eventDialog.close());
  elements.deleteEventButton.addEventListener("click", onDeleteEvent);
  elements.eventForm.addEventListener("submit", onSaveEvent);
  elements.syncGoogleCalendarButton.addEventListener("click", () => elements.syncDialog.showModal());
  elements.cancelSyncButton.addEventListener("click", () => elements.syncDialog.close());
  elements.syncForm.addEventListener("submit", onSyncGoogleCalendar);

  elements.settingsButton.addEventListener("click", () => {
    elements.themeModeSelect.value = state.theme;
    syncAccentInputs();
    updateBackgroundStatus();
    elements.settingsDialog.showModal();
  });
  elements.closeSettingsButton.addEventListener("click", () => elements.settingsDialog.close());
  elements.themeModeSelect.addEventListener("change", onThemeChange);
  elements.accentRedInput.addEventListener("input", onAccentInputChange);
  elements.accentGreenInput.addEventListener("input", onAccentInputChange);
  elements.accentBlueInput.addEventListener("input", onAccentInputChange);
  elements.backgroundImageInput.addEventListener("change", onBackgroundSelected);
  elements.clearBackgroundButton.addEventListener("click", clearBackgroundImage);
  elements.resetLayoutButton.addEventListener("click", resetFloatingLayout);

  for (const toggle of elements.sectionToggles) {
    toggle.addEventListener("click", () => toggleSection(toggle.dataset.sectionToggle));
    toggle.addEventListener("keydown", event => {
      if (event.key !== "Enter" && event.key !== " ") {
        return;
      }
      event.preventDefault();
      toggleSection(toggle.dataset.sectionToggle);
    });
  }

  window.addEventListener("mousemove", onWidgetDrag);
  window.addEventListener("mouseup", stopWidgetDrag);
  window.addEventListener("resize", () => requestAnimationFrame(applyFloatingLayout));
}

function initializeWidgets() {
  for (const widget of elements.widgets) {
    if (resizeObserver) {
      resizeObserver.observe(widget);
    }

    widget.addEventListener("dblclick", event => {
      event.stopPropagation();
      if (event.target.closest("button, input, select, textarea, label")) {
        return;
      }
      event.preventDefault();
      toggleWidgetFloating(widget);
    });

    widget.addEventListener("mousedown", event => {
      if (!widget.classList.contains("floating")) {
        return;
      }
      if (event.target.closest("button, input, select, textarea, label")) {
        return;
      }

      const bounds = widget.getBoundingClientRect();
      if ((event.clientY - bounds.top) > 54) {
        return;
      }

      state.dragging = {
        widget,
        id: widget.dataset.widgetId,
        offsetX: event.clientX - bounds.left,
        offsetY: event.clientY - bounds.top
      };
      widget.classList.add("dragging");
      event.stopPropagation();
      event.preventDefault();
    });
  }

  applyFloatingLayout();
  applySectionState();
}

async function refreshState() {
  const response = await fetch("/api/state");
  if (!response.ok) {
    throw new Error("Unable to load calendar state.");
  }
  const data = await response.json();
  state.calendars = data.calendars ?? [];
  state.events = data.events ?? [];
  state.testCases = data.testCases ?? [];
  state.schedulePreviews = data.schedulePreviews ?? [];
  state.activeTestCaseId = data.activeTestCaseId ?? "";
}

function render() {
  elements.monthView.classList.toggle("hidden", state.view !== "month");
  elements.agendaView.classList.toggle("hidden", state.view !== "agenda");
  elements.monthViewButton.classList.toggle("active", state.view === "month");
  elements.agendaViewButton.classList.toggle("active", state.view === "agenda");

  renderViewTitle();
  renderMiniMonth();
  renderTestCaseOptions();
  renderCalendarFilters();
  renderUpcoming();
  renderEventCalendarOptions();

  if (state.view === "month") {
    renderMonthView();
  } else {
    renderAgendaView();
  }

  requestAnimationFrame(applyFloatingLayout);
}

function setView(view) {
  state.view = view;
  render();
}

function renderViewTitle() {
  if (state.view === "month") {
    elements.viewTitle.textContent = state.focusDate.toLocaleDateString(undefined, { month: "long", year: "numeric" });
    return;
  }
  elements.viewTitle.textContent = `Agenda from ${state.focusDate.toLocaleDateString(undefined, {
    month: "short",
    day: "numeric",
    year: "numeric"
  })}`;
}

function renderCalendarFilters() {
  elements.calendarFilters.innerHTML = "";

  for (const calendar of state.calendars) {
    const item = document.createElement("button");
    item.type = "button";
    item.className = `calendar-option${calendar.visible ? " is-visible" : ""}`;
    item.style.setProperty("--calendar-color", calendar.color);
    item.setAttribute("aria-pressed", calendar.visible ? "true" : "false");
    item.title = calendar.visible ? "Hide calendar" : "Show calendar";
    item.addEventListener("click", async () => {
      const nextVisible = !calendar.visible;
      const response = await fetch(`/api/calendars/${encodeURIComponent(calendar.id)}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ visible: nextVisible })
      });

      if (!response.ok) {
        alert(await readError(response));
        return;
      }

      calendar.visible = nextVisible;
      render();
    });

    const visibility = document.createElement("span");
    visibility.className = "calendar-visibility";
    visibility.setAttribute("aria-hidden", "true");

    const swatch = document.createElement("span");
    swatch.className = "calendar-swatch";
    swatch.style.background = calendar.color;

    const text = document.createElement("span");
    text.className = "calendar-name";
    text.textContent = calendar.name;

    const actions = document.createElement("span");
    actions.className = "calendar-actions";
    actions.setAttribute("aria-hidden", "true");
    actions.textContent = "...";

    item.append(visibility, swatch, text, actions);
    elements.calendarFilters.append(item);
  }
}

function renderTestCaseOptions() {
  const previousValue = elements.testCaseSelect.value;
  elements.testCaseSelect.innerHTML = "";

  for (const testCase of state.testCases) {
    const option = document.createElement("option");
    option.value = testCase.id;
    option.textContent = testCase.name;
    elements.testCaseSelect.append(option);
  }

  if (state.activeTestCaseId) {
    elements.testCaseSelect.value = state.activeTestCaseId;
  } else if (previousValue) {
    elements.testCaseSelect.value = previousValue;
  }
}

function renderMiniMonth() {
  const firstOfMonth = new Date(state.focusDate.getFullYear(), state.focusDate.getMonth(), 1);
  const gridStart = new Date(firstOfMonth);
  gridStart.setDate(firstOfMonth.getDate() - firstOfMonth.getDay());

  elements.miniMonthTitle.textContent = state.focusDate.toLocaleDateString(undefined, {
    month: "long",
    year: "numeric"
  });
  elements.miniMonthGrid.innerHTML = "";

  for (let index = 0; index < 42; index += 1) {
    const date = new Date(gridStart);
    date.setDate(gridStart.getDate() + index);

    const button = document.createElement("button");
    button.type = "button";
    button.className = "mini-day";
    if (date.getMonth() !== state.focusDate.getMonth()) {
      button.classList.add("outside");
    }
    if (sameDay(date, new Date())) {
      button.classList.add("today");
    }
    if (sameDay(date, state.focusDate)) {
      button.classList.add("selected");
    }

    button.textContent = String(date.getDate());
    button.addEventListener("click", () => {
      state.focusDate = new Date(date.getFullYear(), date.getMonth(), date.getDate());
      render();
    });

    elements.miniMonthGrid.append(button);
  }
}

function renderUpcoming() {
  elements.upcomingList.innerHTML = "";

  const preview = state.schedulePreviews.find(item => item.id === state.activeTestCaseId)
    ?? state.schedulePreviews[0];

  if (!preview || !Array.isArray(preview.classes) || preview.classes.length === 0) {
    const empty = document.createElement("p");
    empty.className = "agenda-meta";
    empty.textContent = "No course previews available.";
    elements.upcomingList.append(empty);
    return;
  }

  for (const course of preview.classes) {
    const item = document.createElement("div");
    item.className = "upcoming-item";
    item.innerHTML = `
      <strong>${escapeHtml(course.title)}</strong>
      <div class="upcoming-meta">${escapeHtml(course.time)}</div>
    `;
    elements.upcomingList.append(item);
  }
}

function renderMonthView() {
  const firstOfMonth = new Date(state.focusDate.getFullYear(), state.focusDate.getMonth(), 1);
  const gridStart = new Date(firstOfMonth);
  gridStart.setDate(firstOfMonth.getDate() - firstOfMonth.getDay());

  const grid = document.createElement("div");
  grid.className = "month-grid";

  for (const header of ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"]) {
    const cell = document.createElement("div");
    cell.className = "weekday";
    cell.textContent = header;
    grid.append(cell);
  }

  for (let index = 0; index < 42; index += 1) {
    const date = new Date(gridStart);
    date.setDate(gridStart.getDate() + index);

    const cell = document.createElement("div");
    cell.className = "month-cell";
    if (date.getMonth() !== state.focusDate.getMonth()) {
      cell.classList.add("outside");
    }
    if (sameDay(date, state.focusDate)) {
      cell.classList.add("selected");
    }

    const dayHeader = document.createElement("div");
    dayHeader.className = "month-day";
    dayHeader.innerHTML = `<span>${date.getDate()}</span><button type="button">+</button>`;
    dayHeader.querySelector("button").addEventListener("click", () => openEventDialog(null, toDateTimeLocal(date, 11)));

    const dayEvents = document.createElement("div");
    dayEvents.className = "month-events";

    const events = filteredEvents()
      .filter(event => occursOnDate(event, date))
      .sort(byStart)
      .slice(0, 3);

    for (const event of events) {
      const calendar = findCalendar(event.courseId);
      const button = document.createElement("button");
      button.className = "event-pill";
      button.style.color = calendar?.color ?? "#0D6EFD";
      button.textContent = `${formatTime(event.start)} ${event.title}`;
      button.addEventListener("click", () => openEventDialog(event));
      dayEvents.append(button);
    }

    cell.append(dayHeader, dayEvents);
    grid.append(cell);
  }

  elements.monthView.innerHTML = "";
  elements.monthView.append(grid);
}

function renderAgendaView() {
  const list = document.createElement("div");
  list.className = "agenda-list";

  const events = filteredEvents()
    .filter(event => new Date(event.end) >= startOfDay(state.focusDate))
    .sort(byStart);

  if (events.length === 0) {
    const empty = document.createElement("p");
    empty.className = "agenda-meta";
    empty.textContent = "No matching events.";
    elements.agendaView.innerHTML = "";
    elements.agendaView.append(empty);
    return;
  }

  for (const event of events) {
    const card = document.createElement("button");
    card.className = "agenda-card";
    card.style.borderLeftColor = findCalendar(event.courseId)?.color ?? "#0D6EFD";
    card.innerHTML = `
      <strong>${escapeHtml(event.title)}</strong>
      <div class="agenda-meta">${formatDateTime(event.start)} to ${formatDateTime(event.end)}</div>
      <div class="agenda-meta">${escapeHtml(event.location || "Location TBA")}</div>
      ${event.details ? `<p>${escapeHtml(event.details)}</p>` : ""}
    `;
    card.addEventListener("click", () => openEventDialog(event));
    list.append(card);
  }

  elements.agendaView.innerHTML = "";
  elements.agendaView.append(list);
}

function renderEventCalendarOptions() {
  const currentValue = elements.eventCalendar.value;
  elements.eventCalendar.innerHTML = "";

  for (const calendar of state.calendars) {
    const option = document.createElement("option");
    option.value = calendar.id;
    option.textContent = calendar.name;
    elements.eventCalendar.append(option);
  }

  if (currentValue) {
    elements.eventCalendar.value = currentValue;
  }
}

function openEventDialog(event = null, startValue = null) {
  const defaultStart = startValue ?? toDateTimeLocal(new Date());
  const defaultEnd = toDateTimeLocal(addHours(new Date(defaultStart), 1));

  elements.eventDialogTitle.textContent = event ? "Edit Event" : "Add Event";
  elements.deleteEventButton.classList.toggle("hidden", !event);
  elements.eventId.value = event?.id ?? "";
  elements.eventTitle.value = event?.title ?? "";
  elements.eventCalendar.value = event?.courseId ?? state.calendars[0]?.id ?? "";
  elements.eventStart.value = event ? toDateTimeLocal(new Date(event.start)) : defaultStart;
  elements.eventEnd.value = event ? toDateTimeLocal(new Date(event.end)) : defaultEnd;
  elements.eventLocation.value = event?.location ?? "";
  elements.eventDetails.value = event?.details ?? "";
  elements.eventDialog.showModal();
}

async function onSaveEvent(submitEvent) {
  submitEvent.preventDefault();
  const payload = {
    title: elements.eventTitle.value.trim(),
    courseId: elements.eventCalendar.value,
    start: normalizeLocalDateTime(elements.eventStart.value),
    end: normalizeLocalDateTime(elements.eventEnd.value),
    location: elements.eventLocation.value.trim(),
    details: elements.eventDetails.value.trim()
  };

  const id = elements.eventId.value;
  const response = await fetch(id ? `/api/events/${encodeURIComponent(id)}` : "/api/events", {
    method: id ? "PUT" : "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload)
  });

  if (!response.ok) {
    alert(await readError(response));
    return;
  }

  elements.eventDialog.close();
  await refreshState();
  render();
}

async function onDeleteEvent() {
  const id = elements.eventId.value;
  if (!id) {
    return;
  }

  const response = await fetch(`/api/events/${encodeURIComponent(id)}`, { method: "DELETE" });
  if (!response.ok) {
    alert(await readError(response));
    return;
  }

  elements.eventDialog.close();
  await refreshState();
  render();
}

async function onLoadTestCase() {
  const testCaseId = elements.testCaseSelect.value;
  if (!testCaseId) {
    return;
  }

  const response = await fetch(`/api/test-cases/${encodeURIComponent(testCaseId)}/load`, {
    method: "POST"
  });
  if (!response.ok) {
    alert(await readError(response));
    return;
  }

  const data = await response.json();
  state.calendars = data.calendars ?? [];
  state.events = data.events ?? [];
  state.testCases = data.testCases ?? [];
  state.schedulePreviews = data.schedulePreviews ?? [];
  state.activeTestCaseId = data.activeTestCaseId ?? testCaseId;
  state.focusDate = new Date(2026, 0, 20);
  render();
}

async function onSyncGoogleCalendar(submitEvent) {
  submitEvent.preventDefault();

  const response = await fetch("/api/google-calendar-sync", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      feedUrl: elements.googleCalendarFeedUrl.value.trim(),
      calendarName: elements.googleCalendarName.value.trim()
    })
  });

  if (!response.ok) {
    alert(await readError(response));
    return;
  }

  elements.syncDialog.close();
  await refreshState();
  render();
}

function onThemeChange() {
  state.theme = elements.themeModeSelect.value;
  localStorage.setItem(STORAGE_KEYS.theme, state.theme);
  applyStoredAppearance();
}

function onAccentInputChange() {
  const nextAccent = readAccentInputs();
  state.accentRgb = nextAccent;
  persistAccentRgb(nextAccent);
  applyStoredAppearance();
  updateAccentPreview();
}

async function onBackgroundSelected() {
  const file = elements.backgroundImageInput.files?.[0];
  if (!file) {
    return;
  }

  updateBackgroundStatus(`Optimizing ${file.name}...`);

  try {
    state.backgroundImage = await createOptimizedBackgroundDataUrl(file);
    applyStoredAppearance();
    persistBackgroundImage(state.backgroundImage);
    updateBackgroundStatus(`${file.name} is now your background.`);
  } catch (error) {
    console.error(error);
    updateBackgroundStatus("Unable to use that image. Try a smaller JPG, PNG, or WebP file.");
    alert(error?.message || "Unable to use that image as the background.");
  }
}

function clearBackgroundImage() {
  state.backgroundImage = "";
  elements.backgroundImageInput.value = "";
  localStorage.removeItem(STORAGE_KEYS.backgroundImage);
  applyStoredAppearance();
  updateBackgroundStatus();
}

function toggleSection(sectionId) {
  if (!sectionId) {
    return;
  }
  const current = state.sectionState[sectionId];
  state.sectionState[sectionId] = current === false;
  persistSectionState();
  applySectionState();
}

function applySectionState() {
  for (const toggle of elements.sectionToggles) {
    const sectionId = toggle.dataset.sectionToggle;
    const expanded = state.sectionState[sectionId] !== false;
    const section = toggle.closest(".rail-section");
    const caret = toggle.querySelector(".section-caret");
    const body = elements.sectionBodies.find(item => item.dataset.sectionBody === sectionId);

    toggle.setAttribute("aria-expanded", expanded ? "true" : "false");
    if (caret) {
      caret.innerHTML = expanded ? "&#9660;" : "&#9654;";
    }
    if (section) {
      section.classList.toggle("rail-section-collapsed", !expanded);
    }
    if (body) {
      body.hidden = !expanded;
    }
  }
}

function applyStoredAppearance() {
  elements.body.dataset.theme = state.theme;
  const background = state.backgroundImage ? `url("${state.backgroundImage}")` : "none";
  setThemeVariable("--background-image", background);
  applyAccentTheme();
}

function applyAccentTheme() {
  if (!state.accentRgb) {
    clearThemeVariable("--accent");
    clearThemeVariable("--accent-strong");
    clearThemeVariable("--accent-soft");
    clearThemeVariable("--border");
    clearThemeVariable("--border-strong");
    clearThemeVariable("--calendar-line");
    clearThemeVariable("--calendar-line-strong");
    clearThemeVariable("--accent-highlight");
    updateAccentPreview();
    return;
  }

  const { r, g, b } = state.accentRgb;
  const borderAlpha = state.theme === "dark" ? 0.5 : 0.28;
  const borderStrongAlpha = state.theme === "dark" ? 0.72 : 0.42;
  const softAlpha = state.theme === "dark" ? 0.22 : 0.16;
  const highlightAlpha = state.theme === "dark" ? 0.2 : 0.12;
  const strongAdjustment = state.theme === "dark" ? 28 : -18;
  const strongR = adjustChannel(r, strongAdjustment);
  const strongG = adjustChannel(g, strongAdjustment);
  const strongB = adjustChannel(b, strongAdjustment);

  setThemeVariable("--accent", toRgbString(r, g, b));
  setThemeVariable("--accent-strong", toRgbString(strongR, strongG, strongB));
  setThemeVariable("--accent-soft", `rgba(${r}, ${g}, ${b}, ${softAlpha})`);
  setThemeVariable("--border", `rgba(${r}, ${g}, ${b}, ${borderAlpha})`);
  setThemeVariable("--border-strong", `rgba(${r}, ${g}, ${b}, ${borderStrongAlpha})`);
  setThemeVariable("--calendar-line", `rgba(${r}, ${g}, ${b}, ${Math.min(0.8, borderAlpha + 0.08)})`);
  setThemeVariable("--calendar-line-strong", `rgba(${r}, ${g}, ${b}, ${Math.min(0.86, borderStrongAlpha + 0.06)})`);
  setThemeVariable("--accent-highlight", `rgba(${r}, ${g}, ${b}, ${highlightAlpha})`);
  updateAccentPreview();
}

function setThemeVariable(name, value) {
  elements.root.style.setProperty(name, value);
  elements.body.style.setProperty(name, value);
}

function clearThemeVariable(name) {
  elements.root.style.removeProperty(name);
  elements.body.style.removeProperty(name);
}

function persistBackgroundImage(value) {
  try {
    localStorage.setItem(STORAGE_KEYS.backgroundImage, value);
  } catch (error) {
    throw new Error("The image was too large to save. Try a smaller image.");
  }
}

function updateBackgroundStatus(message = null) {
  if (message) {
    elements.backgroundStatus.textContent = message;
    return;
  }
  elements.backgroundStatus.textContent = state.backgroundImage
    ? "A custom background is active."
    : "No custom background selected.";
}

function updateAccentPreview() {
  if (!elements.accentPreview || !elements.accentValueLabel) {
    return;
  }

  if (!state.accentRgb) {
    elements.accentPreview.style.background = "linear-gradient(135deg, #5f7270, #4f615f)";
    elements.accentValueLabel.textContent = "Using the default accent color.";
    return;
  }

  const { r, g, b } = state.accentRgb;
  elements.accentPreview.style.background = toRgbString(r, g, b);
  elements.accentValueLabel.textContent = `Accent RGB: ${r}, ${g}, ${b}`;
}

function syncAccentInputs() {
  const accent = state.accentRgb ?? { r: 95, g: 114, b: 112 };
  elements.accentRedInput.value = accent.r;
  elements.accentGreenInput.value = accent.g;
  elements.accentBlueInput.value = accent.b;
  updateAccentPreview();
}

function toggleWidgetFloating(widget) {
  const widgetId = widget.dataset.widgetId;
  const current = state.floatingWidgets[widgetId];

  if (current) {
    delete state.floatingWidgets[widgetId];
    widget.classList.remove("floating", "dragging");
    widget.style.left = "";
    widget.style.top = "";
    widget.style.width = "";
    widget.style.height = "";
    persistFloatingWidgets();
    triggerWidgetPop(widget);
    return;
  }

  const bounds = widget.getBoundingClientRect();
  state.floatingWidgets[widgetId] = {
    left: Math.round(clamp(bounds.left, FLOATING_MARGIN, Math.max(FLOATING_MARGIN, window.innerWidth - bounds.width - FLOATING_MARGIN))),
    top: Math.round(clamp(bounds.top, FLOATING_MARGIN, Math.max(FLOATING_MARGIN, window.innerHeight - bounds.height - FLOATING_MARGIN))),
    width: Math.round(bounds.width),
    height: Math.round(bounds.height)
  };

  persistFloatingWidgets();
  applyFloatingLayout();
  triggerWidgetPop(widget);
}

function applyFloatingLayout() {
  for (const widget of elements.widgets) {
    const widgetId = widget.dataset.widgetId;
    const saved = state.floatingWidgets[widgetId];

    if (!saved) {
      widget.classList.remove("floating", "dragging");
      widget.style.left = "";
      widget.style.top = "";
      widget.style.width = "";
      widget.style.height = "";
      continue;
    }

    const isCalendarView = widget.classList.contains("calendar-view");
    const defaultWidth = isCalendarView ? 900 : 420;
    const preferredWidth = saved.width || Math.round(widget.getBoundingClientRect().width) || defaultWidth;
    const maxWidth = Math.max(280, window.innerWidth - 24);
    const safeWidth = Math.round(clamp(preferredWidth, 280, maxWidth));
    const preferredHeight = saved.height || Math.round(widget.getBoundingClientRect().height);
    const maxHeight = Math.max(180, window.innerHeight - 24);
    const safeHeight = preferredHeight ? Math.round(clamp(preferredHeight, 140, maxHeight)) : null;
    const snappedPosition = getSnappedFloatingPosition(
      widgetId,
      saved.left ?? FLOATING_MARGIN,
      saved.top ?? FLOATING_MARGIN,
      safeWidth,
      safeHeight || widget.offsetHeight || 220
    );
    const left = snappedPosition.left;
    const top = snappedPosition.top;

    widget.classList.add("floating");
    widget.style.left = `${left}px`;
    widget.style.top = `${top}px`;
    widget.style.width = `${safeWidth}px`;
    widget.style.height = safeHeight ? `${safeHeight}px` : "";

    state.floatingWidgets[widgetId] = {
      left,
      top,
      width: safeWidth,
      height: safeHeight
    };
  }
}

function handleWidgetResize(entries) {
  for (const entry of entries) {
    const widget = entry.target;
    const widgetId = widget.dataset.widgetId;
    if (!widget.classList.contains("floating") || !state.floatingWidgets[widgetId]) {
      continue;
    }

    state.floatingWidgets[widgetId].width = Math.round(entry.contentRect.width);
    state.floatingWidgets[widgetId].height = Math.round(entry.contentRect.height);
  }

  persistFloatingWidgets();
}

function onWidgetDrag(event) {
  if (!state.dragging) {
    return;
  }

  const widget = state.dragging.widget;
  const snappedPosition = getSnappedFloatingPosition(
    state.dragging.id,
    event.clientX - state.dragging.offsetX,
    event.clientY - state.dragging.offsetY,
    widget.offsetWidth,
    widget.offsetHeight
  );
  const left = snappedPosition.left;
  const top = snappedPosition.top;

  widget.style.left = `${left}px`;
  widget.style.top = `${top}px`;
  state.floatingWidgets[state.dragging.id] = {
    ...state.floatingWidgets[state.dragging.id],
    left,
    top,
    width: widget.offsetWidth,
    height: widget.offsetHeight
  };
}

function stopWidgetDrag() {
  if (!state.dragging) {
    return;
  }

  const widget = state.dragging.widget;
  const savedPosition = state.floatingWidgets[state.dragging.id];
  const currentLeft = savedPosition?.left ?? (Number.parseFloat(widget.style.left) || FLOATING_MARGIN);
  const currentTop = savedPosition?.top ?? (Number.parseFloat(widget.style.top) || FLOATING_MARGIN);
  const snappedPosition = getSnappedFloatingPosition(
    state.dragging.id,
    currentLeft,
    currentTop,
    widget.offsetWidth,
    widget.offsetHeight
  );
  widget.style.left = `${snappedPosition.left}px`;
  widget.style.top = `${snappedPosition.top}px`;
  state.floatingWidgets[state.dragging.id] = {
    ...state.floatingWidgets[state.dragging.id],
    left: snappedPosition.left,
    top: snappedPosition.top,
    width: widget.offsetWidth,
    height: widget.offsetHeight
  };
  state.dragging.widget.classList.remove("dragging");
  persistFloatingWidgets();
  state.dragging = null;
}

function resetFloatingLayout() {
  state.floatingWidgets = {};
  persistFloatingWidgets();
  applyFloatingLayout();
}

function triggerWidgetPop(widget) {
  widget.classList.remove("pop-in");
  window.clearTimeout(state.widgetPopTimers.get(widget.dataset.widgetId));
  widget.offsetWidth;
  widget.classList.add("pop-in");

  const timeout = window.setTimeout(() => {
    widget.classList.remove("pop-in");
    state.widgetPopTimers.delete(widget.dataset.widgetId);
  }, POP_IN_DURATION_MS);

  state.widgetPopTimers.set(widget.dataset.widgetId, timeout);
}

function getSnappedFloatingPosition(widgetId, proposedLeft, proposedTop, width, height) {
  const maxLeft = Math.max(FLOATING_MARGIN, window.innerWidth - width - FLOATING_MARGIN);
  const maxTop = Math.max(FLOATING_MARGIN, window.innerHeight - height - FLOATING_MARGIN);
  const baseLeft = Math.round(clamp(proposedLeft, FLOATING_MARGIN, maxLeft));
  const baseTop = Math.round(clamp(proposedTop, FLOATING_MARGIN, maxTop));

  const xCandidates = [FLOATING_MARGIN, maxLeft];
  const yCandidates = [FLOATING_MARGIN, maxTop];

  for (const [otherId, otherState] of Object.entries(state.floatingWidgets)) {
    if (otherId === widgetId || !otherState) {
      continue;
    }

    const otherWidth = otherState.width || 0;
    const otherHeight = otherState.height || 0;
    const otherLeft = clamp(otherState.left ?? FLOATING_MARGIN, FLOATING_MARGIN, Math.max(FLOATING_MARGIN, window.innerWidth - otherWidth - FLOATING_MARGIN));
    const otherTop = clamp(otherState.top ?? FLOATING_MARGIN, FLOATING_MARGIN, Math.max(FLOATING_MARGIN, window.innerHeight - otherHeight - FLOATING_MARGIN));
    const otherRight = otherLeft + otherWidth;
    const otherBottom = otherTop + otherHeight;

    xCandidates.push(
      otherLeft,
      otherRight - width,
      otherLeft - width - PANEL_SNAP_GAP,
      otherRight + PANEL_SNAP_GAP
    );
    yCandidates.push(
      otherTop,
      otherBottom - height,
      otherTop - height - PANEL_SNAP_GAP,
      otherBottom + PANEL_SNAP_GAP
    );
  }

  return {
    left: snapAxis(baseLeft, xCandidates, maxLeft),
    top: snapAxis(baseTop, yCandidates, maxTop)
  };
}

function snapAxis(value, candidates, maxValue) {
  let snapped = value;
  let closestDistance = PANEL_SNAP_THRESHOLD + 1;

  for (const candidate of candidates) {
    if (!Number.isFinite(candidate)) {
      continue;
    }
    const boundedCandidate = Math.round(clamp(candidate, FLOATING_MARGIN, maxValue));
    const distance = Math.abs(value - boundedCandidate);
    if (distance <= PANEL_SNAP_THRESHOLD && distance < closestDistance) {
      snapped = boundedCandidate;
      closestDistance = distance;
    }
  }

  return snapped;
}

function filteredEvents() {
  const visibleCalendarIds = new Set(state.calendars.filter(calendar => calendar.visible).map(calendar => calendar.id));
  return state.events.filter(event => {
    if (!visibleCalendarIds.has(event.courseId)) {
      return false;
    }
    if (!state.search) {
      return true;
    }
    const calendar = findCalendar(event.courseId);
    const haystack = `${event.title} ${event.location} ${event.details} ${calendar?.name ?? ""}`.toLowerCase();
    return haystack.includes(state.search);
  });
}

function findCalendar(id) {
  return state.calendars.find(calendar => calendar.id === id);
}

function byStart(left, right) {
  return new Date(left.start) - new Date(right.start);
}

function occursOnDate(event, date) {
  const start = startOfDay(new Date(event.start));
  const end = startOfDay(new Date(event.end));
  const current = startOfDay(date);
  return current >= start && current <= end;
}

function startOfDay(date) {
  return new Date(date.getFullYear(), date.getMonth(), date.getDate());
}

function sameDay(left, right) {
  return left.getFullYear() === right.getFullYear()
    && left.getMonth() === right.getMonth()
    && left.getDate() === right.getDate();
}

function formatDateTime(value) {
  return new Date(value).toLocaleString(undefined, {
    month: "short",
    day: "numeric",
    year: "numeric",
    hour: "numeric",
    minute: "2-digit"
  });
}

function formatTime(value) {
  return new Date(value).toLocaleTimeString(undefined, {
    hour: "numeric",
    minute: "2-digit"
  });
}

function toDateTimeLocal(date, hourOverride = null) {
  const working = new Date(date);
  if (hourOverride !== null) {
    working.setHours(hourOverride, 0, 0, 0);
  }
  const timezoneOffset = working.getTimezoneOffset();
  const local = new Date(working.getTime() - timezoneOffset * 60000);
  return local.toISOString().slice(0, 16);
}

function normalizeLocalDateTime(value) {
  return value ? `${value}:00` : value;
}

function addHours(date, hours) {
  const next = new Date(date);
  next.setHours(next.getHours() + hours);
  return next;
}

async function readError(response) {
  try {
    const data = await response.json();
    return data.message || data.error || `Request failed with status ${response.status}`;
  } catch {
    return `Request failed with status ${response.status}`;
  }
}

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll("\"", "&quot;");
}

function loadFloatingWidgets() {
  try {
    const parsed = JSON.parse(localStorage.getItem(STORAGE_KEYS.floatingWidgets) || "{}");
    return parsed && typeof parsed === "object" ? parsed : {};
  } catch {
    return {};
  }
}

function loadSectionState() {
  try {
    const parsed = JSON.parse(localStorage.getItem(STORAGE_KEYS.sectionState) || "{}");
    return {
      courses: parsed.courses !== false,
      upcoming: parsed.upcoming !== false,
      undated: parsed.undated === true
    };
  } catch {
    return {
      courses: true,
      upcoming: true,
      undated: false
    };
  }
}

function loadAccentRgb() {
  try {
    const parsed = JSON.parse(localStorage.getItem(STORAGE_KEYS.accentRgb) || "null");
    if (!parsed || typeof parsed !== "object") {
      return null;
    }
    const r = clampRgb(parsed.r);
    const g = clampRgb(parsed.g);
    const b = clampRgb(parsed.b);
    if (r === null || g === null || b === null) {
      return null;
    }
    return { r, g, b };
  } catch {
    return null;
  }
}

function readAccentInputs() {
  const r = clampRgb(elements.accentRedInput.value);
  const g = clampRgb(elements.accentGreenInput.value);
  const b = clampRgb(elements.accentBlueInput.value);

  if (r === null || g === null || b === null) {
    return null;
  }
  return { r, g, b };
}

function persistAccentRgb(value) {
  if (!value) {
    localStorage.removeItem(STORAGE_KEYS.accentRgb);
    return;
  }
  localStorage.setItem(STORAGE_KEYS.accentRgb, JSON.stringify(value));
}

function clampRgb(value) {
  if (value === "" || value === null || value === undefined) {
    return null;
  }
  const numeric = Number(value);
  if (!Number.isFinite(numeric)) {
    return null;
  }
  return Math.max(0, Math.min(255, Math.round(numeric)));
}

function adjustChannel(value, delta) {
  return Math.max(0, Math.min(255, value + delta));
}

function toRgbString(r, g, b) {
  return `rgb(${r}, ${g}, ${b})`;
}

function persistFloatingWidgets() {
  localStorage.setItem(STORAGE_KEYS.floatingWidgets, JSON.stringify(state.floatingWidgets));
}

function persistSectionState() {
  localStorage.setItem(STORAGE_KEYS.sectionState, JSON.stringify(state.sectionState));
}

function clamp(value, min, max) {
  return Math.min(Math.max(value, min), max);
}

async function createOptimizedBackgroundDataUrl(file) {
  const dataUrl = await readFileAsDataUrl(file);
  const image = await loadImage(dataUrl);
  const scale = Math.min(1, MAX_BACKGROUND_DIMENSION / Math.max(image.width, image.height));
  const width = Math.max(1, Math.round(image.width * scale));
  const height = Math.max(1, Math.round(image.height * scale));

  const canvas = document.createElement("canvas");
  canvas.width = width;
  canvas.height = height;

  const context = canvas.getContext("2d");
  if (!context) {
    throw new Error("Your browser could not prepare the image.");
  }

  context.drawImage(image, 0, 0, width, height);

  const preferredMimeType = file.type === "image/png" ? "image/png" : "image/jpeg";
  const exportCandidates = preferredMimeType === "image/png"
    ? [canvas.toDataURL("image/png"), ...BACKGROUND_EXPORT_QUALITIES.map(quality => canvas.toDataURL("image/jpeg", quality))]
    : BACKGROUND_EXPORT_QUALITIES.map(quality => canvas.toDataURL("image/jpeg", quality));

  const usableExport =
    exportCandidates.find(candidate => candidate.length < 4_500_000)
    || exportCandidates[exportCandidates.length - 1];
  if (!usableExport) {
    throw new Error("The selected image could not be encoded.");
  }

  return usableExport;
}

function readFileAsDataUrl(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error("Unable to read the selected image."));
    reader.onload = () => resolve(typeof reader.result === "string" ? reader.result : "");
    reader.readAsDataURL(file);
  });
}

function loadImage(source) {
  return new Promise((resolve, reject) => {
    const image = new Image();
    image.onload = () => resolve(image);
    image.onerror = () => reject(new Error("The selected file is not a supported image."));
    image.src = source;
  });
}
