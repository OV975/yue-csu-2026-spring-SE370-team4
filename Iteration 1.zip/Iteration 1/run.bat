@echo off
setlocal

set "SCRIPT_DIR=%~dp0"
set "JAR_PATH=%SCRIPT_DIR%target\canvas-calendar-plus-1.0.0.jar"

if exist "%JAR_PATH%" (
    goto runJar
)

call "%SCRIPT_DIR%build.bat"
if errorlevel 1 exit /b 1

if exist "%JAR_PATH%" (
    goto runJar
)

where java >nul 2>nul
if %ERRORLEVEL% NEQ 0 (
    if exist "C:\Program Files\Java\latest\bin\java.exe" set "PATH=C:\Program Files\Java\latest\bin;%PATH%"
    if exist "C:\Program Files\Java\jdk-26\bin\java.exe" set "PATH=C:\Program Files\Java\jdk-26\bin;%PATH%"
    if exist "C:\Program Files\Java\jdk-17\bin\java.exe" set "PATH=C:\Program Files\Java\jdk-17\bin;%PATH%"
)

java -cp out canvascalendar.CanvasCalendarApp
exit /b %ERRORLEVEL%

:runJar
where java >nul 2>nul
if %ERRORLEVEL% NEQ 0 (
    if exist "C:\Program Files\Java\latest\bin\java.exe" set "PATH=C:\Program Files\Java\latest\bin;%PATH%"
    if exist "C:\Program Files\Java\jdk-26\bin\java.exe" set "PATH=C:\Program Files\Java\jdk-26\bin;%PATH%"
    if exist "C:\Program Files\Java\jdk-17\bin\java.exe" set "PATH=C:\Program Files\Java\jdk-17\bin;%PATH%"
)

where java >nul 2>nul
if %ERRORLEVEL% NEQ 0 (
    echo.
    echo Unable to start Canvas Calendar Plus+.
    echo Reason: Java is not installed or not available on PATH.
    echo.
    echo Install a JDK 17 or newer, then run run.bat again.
    exit /b 1
)

java -jar "%JAR_PATH%"
