@echo off
setlocal
set "SCRIPT_DIR=%~dp0"

where javac >nul 2>nul
if %ERRORLEVEL% NEQ 0 (
    if exist "C:\Program Files\Java\latest\bin\javac.exe" set "PATH=C:\Program Files\Java\latest\bin;%PATH%"
    if exist "C:\Program Files\Java\jdk-26\bin\javac.exe" set "PATH=C:\Program Files\Java\jdk-26\bin;%PATH%"
    if exist "C:\Program Files\Java\jdk-17\bin\javac.exe" set "PATH=C:\Program Files\Java\jdk-17\bin;%PATH%"
)

where javac >nul 2>nul
if %ERRORLEVEL% NEQ 0 (
    echo.
    echo Unable to build Canvas Calendar Plus+.
    echo Reason: javac is not installed or not available on PATH.
    echo.
    echo Install a JDK 17 or newer, then run build.bat again.
    exit /b 1
)

pushd "%SCRIPT_DIR%"
if not exist out mkdir out
if not exist target mkdir target

javac -d out src\canvascalendar\*.java src\canvascalendar\model\*.java src\canvascalendar\storage\*.java src\canvascalendar\integration\*.java src\canvascalendar\integration\dto\*.java src\canvascalendar\integration\json\*.java src\canvascalendar\ui\*.java src\canvascalendar\ui\theme\*.java
if errorlevel 1 (
    popd
    exit /b 1
)

jar --create --file target\canvas-calendar-plus-1.0.0.jar --main-class canvascalendar.CanvasCalendarApp -C out .
if errorlevel 1 (
    popd
    exit /b 1
)

popd
echo Build completed.
