$ErrorActionPreference = "Stop"

$scriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$fallbackJavaHomes = @(
    "C:\Program Files\Java\latest",
    "C:\Program Files\Java\jdk-26",
    "C:\Program Files\Java\jdk-17"
)

if (-not (Get-Command java -ErrorAction SilentlyContinue)) {
    foreach ($candidate in $fallbackJavaHomes) {
        if (Test-Path (Join-Path $candidate "bin\java.exe")) {
            $env:JAVA_HOME = $candidate
            $env:PATH = "$($env:JAVA_HOME)\bin;$env:PATH"
            break
        }
    }
}

$jar = Join-Path $scriptRoot "target\canvas-calendar-plus-1.0.0.jar"
if (Test-Path $jar) {
    if (-not (Get-Command java -ErrorAction SilentlyContinue)) {
        Write-Host ""
        Write-Host "Unable to start Canvas Calendar Plus+."
        Write-Host "Reason: Java is not installed or not available on PATH."
        Write-Host ""
        Write-Host "Install a JDK 17 or newer, then run .\run.ps1 again."
        exit 1
    }

    & java -jar $jar
    exit $LASTEXITCODE
}

& "$scriptRoot\build.ps1"

if (-not (Get-Command java -ErrorAction SilentlyContinue)) {
    Write-Host ""
    Write-Host "Unable to start Canvas Calendar Plus+."
    Write-Host "Reason: Java is not installed or not available on PATH."
    Write-Host ""
    Write-Host "Install a JDK 17 or newer, then run .\run.ps1 again."
    exit 1
}

& java -cp out canvascalendar.CanvasCalendarApp
