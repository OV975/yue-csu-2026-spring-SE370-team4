$ErrorActionPreference = "Stop"

$scriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$fallbackJavaHomes = @(
    "C:\Program Files\Java\latest",
    "C:\Program Files\Java\jdk-26",
    "C:\Program Files\Java\jdk-17"
)

if (-not (Get-Command javac -ErrorAction SilentlyContinue)) {
    foreach ($candidate in $fallbackJavaHomes) {
        if (Test-Path (Join-Path $candidate "bin\javac.exe")) {
            $env:JAVA_HOME = $candidate
            $env:PATH = "$($env:JAVA_HOME)\bin;$env:PATH"
            break
        }
    }
}

if (-not (Get-Command javac -ErrorAction SilentlyContinue)) {
    Write-Host ""
    Write-Host "Unable to build Canvas Calendar Plus+."
    Write-Host "Reason: javac is not installed or not available on PATH."
    Write-Host ""
    Write-Host "Install a JDK 17 or newer, then run .\build.ps1 again."
    exit 1
}

Push-Location $scriptRoot
try {
    if (-not (Test-Path out)) {
        New-Item -ItemType Directory -Path out | Out-Null
    }

    if (-not (Test-Path target)) {
        New-Item -ItemType Directory -Path target | Out-Null
    }

    javac -d out src\canvascalendar\*.java src\canvascalendar\model\*.java src\canvascalendar\storage\*.java src\canvascalendar\integration\*.java src\canvascalendar\integration\dto\*.java src\canvascalendar\integration\json\*.java src\canvascalendar\ui\*.java src\canvascalendar\ui\theme\*.java
    if ($LASTEXITCODE -ne 0) {
        exit $LASTEXITCODE
    }

    jar --create --file target\canvas-calendar-plus-1.0.0.jar --main-class canvascalendar.CanvasCalendarApp -C out .
    Write-Host "Build completed."
} finally {
    Pop-Location
}
