package canvascalendar.ui;

import canvascalendar.model.CalendarEvent;
import canvascalendar.model.CalendarView;
import canvascalendar.model.CourseCalendar;
import canvascalendar.model.SampleDataFactory;
import canvascalendar.storage.CsvExporter;
import canvascalendar.storage.EventStore;
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAdjusters;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JSeparator;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

public final class CanvasCalendarFrame extends JFrame {
    private static final Color APP_BACKGROUND = new Color(0xEEF2F7);
    private static final Color SIDEBAR_BACKGROUND = Color.WHITE;
    private static final Color BORDER = new Color(0xD9E2EC);
    private static final Color PRIMARY = new Color(0x0D6EFD);
    private static final DateTimeFormatter TITLE_MONTH = DateTimeFormatter.ofPattern("MMMM yyyy");
    private static final DateTimeFormatter TITLE_WEEK = DateTimeFormatter.ofPattern("MMM d");

    private final Path storePath = Paths.get("data", "events.db");
    private final Path exportPath = Paths.get("data", "calendar-export.csv");
    private final EventStore eventStore = new EventStore(storePath);
    private final CsvExporter csvExporter = new CsvExporter();
    private final List<CourseCalendar> calendars = SampleDataFactory.createCalendars();
    private final List<CalendarEvent> events = new ArrayList<>();
    private final Map<String, CourseCalendar> calendarIndex = new HashMap<>();
    private final Map<CalendarView, JButton> viewButtons = new EnumMap<>(CalendarView.class);

    private final JLabel titleLabel = new JLabel();
    private final JPanel mainViewPanel = new JPanel(new CardLayout());
    private final JPanel miniMonthPanel = new JPanel(new java.awt.GridLayout(0, 7, 4, 4));
    private final JPanel upcomingPanel = new JPanel();
    private final JTextField searchField = new JTextField(18);

    private final MonthViewPanel monthViewPanel = new MonthViewPanel();
    private final WeekViewPanel weekViewPanel = new WeekViewPanel();
    private final AgendaViewPanel agendaViewPanel = new AgendaViewPanel();

    private LocalDate focusDate = LocalDate.now();
    private CalendarView currentView = CalendarView.MONTH;
    private String searchQuery = "";

    public CanvasCalendarFrame() {
        super("Canvas Calendar Plus+");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setMinimumSize(new Dimension(1360, 860));
        setSize(1440, 900);
        setLocationRelativeTo(null);
        getContentPane().setBackground(APP_BACKGROUND);

        for (CourseCalendar calendar : calendars) {
            calendarIndex.put(calendar.getId(), calendar);
        }

        loadEvents();
        buildUi();
        refreshAll();
    }

    private void loadEvents() {
        try {
            events.addAll(eventStore.load());
            if (events.isEmpty()) {
                events.addAll(SampleDataFactory.createEvents(LocalDate.now()));
                eventStore.save(events);
            }
        } catch (Exception error) {
            events.clear();
            events.addAll(SampleDataFactory.createEvents(LocalDate.now()));
        }
        events.sort(CalendarEvent.BY_START);
    }

    private void buildUi() {
        setLayout(new BorderLayout(16, 16));
        ((JPanel) getContentPane()).setBorder(BorderFactory.createEmptyBorder(16, 16, 16, 16));

        add(buildSidebar(), BorderLayout.WEST);

        JPanel content = new JPanel(new BorderLayout(0, 12));
        content.setOpaque(false);
        content.add(buildHeader(), BorderLayout.NORTH);
        content.add(buildMainView(), BorderLayout.CENTER);

        add(content, BorderLayout.CENTER);
    }

    private JPanel buildSidebar() {
        JPanel sidebar = new JPanel();
        sidebar.setLayout(new BoxLayout(sidebar, BoxLayout.Y_AXIS));
        sidebar.setBackground(SIDEBAR_BACKGROUND);
        sidebar.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(BORDER),
            BorderFactory.createEmptyBorder(16, 16, 16, 16)
        ));
        sidebar.setPreferredSize(new Dimension(300, 0));

        JLabel logo = new JLabel("Calendar");
        logo.setFont(logo.getFont().deriveFont(Font.BOLD, 24f));
        sidebar.add(logo);
        sidebar.add(Box.createVerticalStrut(6));

        JLabel subtitle = new JLabel("Assignments and events across all courses");
        subtitle.setForeground(new Color(0x6B778C));
        sidebar.add(subtitle);
        sidebar.add(Box.createVerticalStrut(14));

        sidebar.add(sectionLabel("Search"));
        configureSearchField();
        sidebar.add(searchField);
        sidebar.add(Box.createVerticalStrut(18));

        JButton addButton = new JButton("Add Event");
        addButton.addActionListener(e -> openCreateDialog(focusDate));
        sidebar.add(addButton);
        sidebar.add(Box.createVerticalStrut(18));

        sidebar.add(sectionLabel("Mini Month"));
        miniMonthPanel.setOpaque(false);
        sidebar.add(miniMonthPanel);
        sidebar.add(Box.createVerticalStrut(18));

        sidebar.add(sectionLabel("Calendars"));
        for (CourseCalendar calendar : calendars) {
            sidebar.add(buildCalendarToggle(calendar));
        }

        sidebar.add(Box.createVerticalStrut(18));
        sidebar.add(sectionLabel("Upcoming"));
        upcomingPanel.setOpaque(false);
        upcomingPanel.setLayout(new BoxLayout(upcomingPanel, BoxLayout.Y_AXIS));
        sidebar.add(upcomingPanel);
        sidebar.add(Box.createVerticalGlue());
        return sidebar;
    }

    private Component buildCalendarToggle(CourseCalendar calendar) {
        JCheckBox checkBox = new JCheckBox(calendar.getName(), calendar.isVisible());
        checkBox.setOpaque(false);
        checkBox.setForeground(calendar.getColor().darker());
        checkBox.addActionListener(e -> {
            calendar.setVisible(checkBox.isSelected());
            refreshAll();
        });

        JPanel wrapper = new JPanel(new BorderLayout());
        wrapper.setOpaque(false);
        wrapper.setBorder(BorderFactory.createEmptyBorder(0, 0, 8, 0));
        wrapper.add(checkBox, BorderLayout.CENTER);
        return wrapper;
    }

    private JLabel sectionLabel(String text) {
        JLabel label = new JLabel(text);
        label.setFont(label.getFont().deriveFont(Font.BOLD, 13f));
        label.setBorder(BorderFactory.createEmptyBorder(0, 0, 8, 0));
        return label;
    }

    private JPanel buildHeader() {
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(Color.WHITE);
        header.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(BORDER),
            BorderFactory.createEmptyBorder(14, 16, 14, 16)
        ));

        JPanel left = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        left.setOpaque(false);

        JButton previousButton = new JButton("<");
        previousButton.addActionListener(e -> moveRange(-1));
        JButton todayButton = new JButton("Today");
        todayButton.addActionListener(e -> {
            focusDate = LocalDate.now();
            refreshAll();
        });
        JButton nextButton = new JButton(">");
        nextButton.addActionListener(e -> moveRange(1));

        titleLabel.setFont(titleLabel.getFont().deriveFont(Font.BOLD, 26f));

        left.add(previousButton);
        left.add(todayButton);
        left.add(nextButton);
        left.add(new JSeparator(SwingConstants.VERTICAL));
        left.add(titleLabel);

        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        right.setOpaque(false);
        JButton exportButton = new JButton("Export CSV");
        exportButton.addActionListener(e -> exportVisibleEvents());
        right.add(exportButton);
        right.add(createViewButton("Month", CalendarView.MONTH));
        right.add(createViewButton("Week", CalendarView.WEEK));
        right.add(createViewButton("Agenda", CalendarView.AGENDA));

        header.add(left, BorderLayout.WEST);
        header.add(right, BorderLayout.EAST);
        return header;
    }

    private JButton createViewButton(String label, CalendarView view) {
        JButton button = new JButton(label);
        button.addActionListener(e -> {
            currentView = view;
            refreshAll();
        });
        viewButtons.put(view, button);
        return button;
    }

    private JPanel buildMainView() {
        JPanel wrapper = new JPanel(new BorderLayout());
        wrapper.setOpaque(false);

        mainViewPanel.add(monthViewPanel, CalendarView.MONTH.name());
        mainViewPanel.add(weekViewPanel, CalendarView.WEEK.name());
        mainViewPanel.add(agendaViewPanel, CalendarView.AGENDA.name());

        wrapper.add(mainViewPanel, BorderLayout.CENTER);
        return wrapper;
    }

    private void moveRange(int delta) {
        switch (currentView) {
            case MONTH:
                focusDate = focusDate.plusMonths(delta);
                break;
            case WEEK:
                focusDate = focusDate.plusWeeks(delta);
                break;
            case AGENDA:
                focusDate = focusDate.plusDays(delta * 7L);
                break;
            default:
                break;
        }
        refreshAll();
    }

    private void refreshAll() {
        titleLabel.setText(createTitle());
        refreshViewButtons();
        refreshMiniMonth();
        refreshUpcoming();
        refreshMainView();
    }

    private String createTitle() {
        switch (currentView) {
            case WEEK:
                LocalDate start = focusDate.with(TemporalAdjusters.previousOrSame(DayOfWeek.SUNDAY));
                LocalDate end = start.plusDays(6);
                return TITLE_WEEK.format(start) + " - " + end.format(DateTimeFormatter.ofPattern("MMM d, yyyy"));
            case AGENDA:
                return "Agenda starting " + focusDate.format(DateTimeFormatter.ofPattern("MMM d, yyyy"));
            case MONTH:
            default:
                return TITLE_MONTH.format(focusDate);
        }
    }

    private void refreshMiniMonth() {
        miniMonthPanel.removeAll();
        LocalDate first = YearMonth.from(focusDate).atDay(1);
        LocalDate gridStart = first.with(TemporalAdjusters.previousOrSame(DayOfWeek.SUNDAY));

        String[] headers = {"S", "M", "T", "W", "T", "F", "S"};
        for (String header : headers) {
            JLabel label = new JLabel(header, SwingConstants.CENTER);
            label.setForeground(new Color(0x6B778C));
            miniMonthPanel.add(label);
        }

        for (int index = 0; index < 42; index++) {
            LocalDate date = gridStart.plusDays(index);
            JButton button = new JButton(String.valueOf(date.getDayOfMonth()));
            button.setMargin(new java.awt.Insets(2, 2, 2, 2));
            button.setFocusPainted(false);
            button.setBackground(Color.WHITE);
            button.setBorder(BorderFactory.createLineBorder(BORDER));
            if (!YearMonth.from(date).equals(YearMonth.from(focusDate))) {
                button.setForeground(new Color(0x9AA5B1));
            }
            if (date.equals(LocalDate.now())) {
                button.setBorder(BorderFactory.createLineBorder(PRIMARY, 2));
            }
            if (date.equals(focusDate)) {
                button.setBackground(new Color(0xEAF3FF));
            }
            button.addActionListener(e -> {
                focusDate = date;
                refreshAll();
            });
            miniMonthPanel.add(button);
        }
        miniMonthPanel.revalidate();
        miniMonthPanel.repaint();
    }

    private void refreshUpcoming() {
        upcomingPanel.removeAll();
        List<CalendarEvent> filtered = getVisibleEvents();
        filtered.sort(Comparator.comparing(CalendarEvent::getStart));

        int shown = 0;
        for (CalendarEvent event : filtered) {
            if (event.getEnd().toLocalDate().isBefore(LocalDate.now())) {
                continue;
            }
            upcomingPanel.add(createUpcomingItem(event));
            shown++;
            if (shown >= 6) {
                break;
            }
        }

        if (shown == 0) {
            JLabel label = new JLabel("No upcoming items");
            label.setForeground(new Color(0x6B778C));
            upcomingPanel.add(label);
        }

        upcomingPanel.revalidate();
        upcomingPanel.repaint();
    }

    private Component createUpcomingItem(CalendarEvent event) {
        CourseCalendar calendar = calendarIndex.get(event.getCourseId());
        JLabel label = new JLabel("<html><b>" + escape(event.getTitle()) + "</b><br/>"
            + escape(event.getStart().format(DateTimeFormatter.ofPattern("MMM d, h:mm a")))
            + (calendar == null ? "" : "<br/>" + escape(calendar.getName()))
            + "</html>");
        label.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(0, 4, 0, 0, calendar == null ? PRIMARY : calendar.getColor()),
            BorderFactory.createEmptyBorder(6, 8, 10, 8)
        ));

        JPanel wrapper = new JPanel(new BorderLayout());
        wrapper.setOpaque(false);
        wrapper.add(label, BorderLayout.CENTER);
        return wrapper;
    }

    private void refreshMainView() {
        List<CalendarEvent> filteredEvents = getVisibleEvents();
        monthViewPanel.render(
            focusDate,
            LocalDate.now(),
            filteredEvents,
            calendarIndex,
            this::setFocusDate,
            this::openCreateDialog,
            this::openEditDialog
        );
        weekViewPanel.render(
            focusDate,
            LocalDate.now(),
            filteredEvents,
            calendarIndex,
            this::setFocusDate,
            this::openCreateDialog,
            this::openEditDialog
        );
        agendaViewPanel.render(
            focusDate,
            filteredEvents,
            calendarIndex,
            this::openEditDialog
        );

        CardLayout layout = (CardLayout) mainViewPanel.getLayout();
        layout.show(mainViewPanel, currentView.name());
        repaint();
    }

    private void setFocusDate(LocalDate date) {
        focusDate = date;
        refreshAll();
    }

    private List<CalendarEvent> getVisibleEvents() {
        List<CalendarEvent> filtered = new ArrayList<>();
        for (CalendarEvent event : events) {
            CourseCalendar calendar = calendarIndex.get(event.getCourseId());
            if (calendar != null && calendar.isVisible() && matchesSearch(event, calendar)) {
                filtered.add(event);
            }
        }
        filtered.sort(CalendarEvent.BY_START);
        return filtered;
    }

    private void openCreateDialog(LocalDate date) {
        EventEditorDialog.Result result = EventEditorDialog.showDialog(this, calendars, null, date);
        if (result == null || result.getEvent() == null) {
            return;
        }
        events.add(result.getEvent());
        events.sort(CalendarEvent.BY_START);
        persistAndRefresh();
    }

    private void openEditDialog(CalendarEvent source) {
        EventEditorDialog.Result result = EventEditorDialog.showDialog(this, calendars, source.copy(), source.getStart().toLocalDate());
        if (result == null) {
            return;
        }
        if (result.isDeleted()) {
            events.removeIf(existing -> existing.getId().equals(source.getId()));
            persistAndRefresh();
            return;
        }
        CalendarEvent updated = result.getEvent();
        if (updated == null) {
            return;
        }
        for (int index = 0; index < events.size(); index++) {
            if (events.get(index).getId().equals(source.getId())) {
                events.set(index, updated);
                break;
            }
        }
        events.sort(CalendarEvent.BY_START);
        persistAndRefresh();
    }

    private void persistAndRefresh() {
        try {
            eventStore.save(events);
        } catch (Exception error) {
            JOptionPane.showMessageDialog(
                this,
                "Unable to save events to " + storePath + ".",
                "Save error",
                JOptionPane.ERROR_MESSAGE
            );
        }
        refreshAll();
    }

    private void configureSearchField() {
        searchField.setMaximumSize(new Dimension(Integer.MAX_VALUE, 30));
        searchField.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
                updateSearch();
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                updateSearch();
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                updateSearch();
            }
        });
    }

    private void updateSearch() {
        searchQuery = searchField.getText().trim().toLowerCase();
        refreshAll();
    }

    private boolean matchesSearch(CalendarEvent event, CourseCalendar calendar) {
        if (searchQuery.isEmpty()) {
            return true;
        }

        String haystack = String.join(" ",
            event.getTitle(),
            event.getLocation(),
            event.getDetails(),
            calendar.getName()
        ).toLowerCase();

        return haystack.contains(searchQuery);
    }

    private void refreshViewButtons() {
        for (Map.Entry<CalendarView, JButton> entry : viewButtons.entrySet()) {
            boolean active = entry.getKey() == currentView;
            JButton button = entry.getValue();
            button.setBackground(active ? PRIMARY : Color.WHITE);
            button.setForeground(active ? Color.WHITE : Color.BLACK);
            button.setOpaque(true);
            button.setBorder(BorderFactory.createLineBorder(active ? PRIMARY : BORDER));
        }
    }

    private void exportVisibleEvents() {
        try {
            csvExporter.export(exportPath, getVisibleEvents(), calendarIndex);
            JOptionPane.showMessageDialog(
                this,
                "Exported current calendar view to " + exportPath + ".",
                "Export complete",
                JOptionPane.INFORMATION_MESSAGE
            );
        } catch (Exception error) {
            JOptionPane.showMessageDialog(
                this,
                "Unable to export events to " + exportPath + ".",
                "Export error",
                JOptionPane.ERROR_MESSAGE
            );
        }
    }

    private String escape(String value) {
        return value
            .replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;");
    }
}
