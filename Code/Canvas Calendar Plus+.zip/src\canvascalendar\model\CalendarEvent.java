package canvascalendar.model;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Comparator;
import java.util.Objects;

public final class CalendarEvent {
    public static final Comparator<CalendarEvent> BY_START =
        Comparator.comparing(CalendarEvent::getStart).thenComparing(CalendarEvent::getTitle);

    private static final DateTimeFormatter TIME_FORMAT = DateTimeFormatter.ofPattern("h:mm a");

    private final String id;
    private String title;
    private String courseId;
    private LocalDateTime start;
    private LocalDateTime end;
    private String location;
    private String details;

    public CalendarEvent(
        String id,
        String title,
        String courseId,
        LocalDateTime start,
        LocalDateTime end,
        String location,
        String details
    ) {
        this.id = Objects.requireNonNull(id, "id");
        this.title = Objects.requireNonNull(title, "title");
        this.courseId = Objects.requireNonNull(courseId, "courseId");
        this.start = Objects.requireNonNull(start, "start");
        this.end = Objects.requireNonNull(end, "end");
        this.location = location == null ? "" : location;
        this.details = details == null ? "" : details;
    }

    public String getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = Objects.requireNonNull(title, "title");
    }

    public String getCourseId() {
        return courseId;
    }

    public void setCourseId(String courseId) {
        this.courseId = Objects.requireNonNull(courseId, "courseId");
    }

    public LocalDateTime getStart() {
        return start;
    }

    public void setStart(LocalDateTime start) {
        this.start = Objects.requireNonNull(start, "start");
    }

    public LocalDateTime getEnd() {
        return end;
    }

    public void setEnd(LocalDateTime end) {
        this.end = Objects.requireNonNull(end, "end");
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location == null ? "" : location;
    }

    public String getDetails() {
        return details;
    }

    public void setDetails(String details) {
        this.details = details == null ? "" : details;
    }

    public boolean occursOn(LocalDate date) {
        LocalDate startDate = start.toLocalDate();
        LocalDate endDate = end.toLocalDate();
        return !date.isBefore(startDate) && !date.isAfter(endDate);
    }

    public boolean overlaps(LocalDateTime rangeStart, LocalDateTime rangeEnd) {
        return start.isBefore(rangeEnd) && end.isAfter(rangeStart);
    }

    public String getTimeLabel() {
        return TIME_FORMAT.format(start) + " - " + TIME_FORMAT.format(end);
    }

    public CalendarEvent copy() {
        return new CalendarEvent(id, title, courseId, start, end, location, details);
    }
}
