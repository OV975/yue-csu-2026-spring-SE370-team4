package canvascalendar.model;

import java.awt.Color;

public final class CourseCalendar {
    private final String id;
    private final String name;
    private final Color color;
    private boolean visible;

    public CourseCalendar(String id, String name, Color color) {
        this.id = id;
        this.name = name;
        this.color = color;
        this.visible = true;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public Color getColor() {
        return color;
    }

    public boolean isVisible() {
        return visible;
    }

    public void setVisible(boolean visible) {
        this.visible = visible;
    }

    @Override
    public String toString() {
        return name;
    }
}
