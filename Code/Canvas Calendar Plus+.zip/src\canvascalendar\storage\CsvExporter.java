package canvascalendar.storage;

import canvascalendar.model.CalendarEvent;
import canvascalendar.model.CourseCalendar;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public final class CsvExporter {
    private static final DateTimeFormatter DATE_TIME_FORMAT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");

    public void export(Path path, List<CalendarEvent> events, Map<String, CourseCalendar> calendars) throws IOException {
        if (path.getParent() != null) {
            Files.createDirectories(path.getParent());
        }

        List<String> lines = new ArrayList<>();
        lines.add("Title,Course,Start,End,Location,Details");
        for (CalendarEvent event : events) {
            CourseCalendar calendar = calendars.get(event.getCourseId());
            lines.add(String.join(",",
                csv(event.getTitle()),
                csv(calendar == null ? "" : calendar.getName()),
                csv(event.getStart().format(DATE_TIME_FORMAT)),
                csv(event.getEnd().format(DATE_TIME_FORMAT)),
                csv(event.getLocation()),
                csv(event.getDetails())
            ));
        }

        Files.write(path, lines, StandardCharsets.UTF_8);
    }

    private String csv(String value) {
        String sanitized = value == null ? "" : value;
        return "\"" + sanitized.replace("\"", "\"\"") + "\"";
    }
}
