package canvascalendar.model;

public enum CalendarView {
    MONTH,
    WEEK,
    AGENDA
}
