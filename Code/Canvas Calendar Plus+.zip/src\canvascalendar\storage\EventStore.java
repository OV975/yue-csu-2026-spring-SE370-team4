package canvascalendar.storage;

import canvascalendar.model.CalendarEvent;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public final class EventStore {
    private static final DateTimeFormatter DATE_TIME_FORMATTER = DateTimeFormatter.ISO_LOCAL_DATE_TIME;
    private final Path path;

    public EventStore(Path path) {
        this.path = path;
    }

    public List<CalendarEvent> load() throws IOException {
        List<CalendarEvent> events = new ArrayList<>();
        if (!Files.exists(path)) {
            return events;
        }

        List<String> lines = Files.readAllLines(path, StandardCharsets.UTF_8);
        for (String line : lines) {
            if (line.isBlank() || line.startsWith("#")) {
                continue;
            }

            String[] fields = line.split("\t", -1);
            if (fields.length != 7) {
                continue;
            }

            events.add(new CalendarEvent(
                unescape(fields[0]),
                unescape(fields[1]),
                unescape(fields[2]),
                LocalDateTime.parse(unescape(fields[3]), DATE_TIME_FORMATTER),
                LocalDateTime.parse(unescape(fields[4]), DATE_TIME_FORMATTER),
                unescape(fields[5]),
                unescape(fields[6])
            ));
        }

        events.sort(CalendarEvent.BY_START);
        return events;
    }

    public void save(List<CalendarEvent> events) throws IOException {
        if (path.getParent() != null) {
            Files.createDirectories(path.getParent());
        }

        List<String> lines = new ArrayList<>();
        lines.add("# Canvas Calendar Plus+ event store");
        events.stream()
            .sorted(Comparator.comparing(CalendarEvent::getStart).thenComparing(CalendarEvent::getTitle))
            .forEach(event -> lines.add(String.join("\t",
                escape(event.getId()),
                escape(event.getTitle()),
                escape(event.getCourseId()),
                escape(DATE_TIME_FORMATTER.format(event.getStart())),
                escape(DATE_TIME_FORMATTER.format(event.getEnd())),
                escape(event.getLocation()),
                escape(event.getDetails())
            )));

        Files.write(path, lines, StandardCharsets.UTF_8);
    }

    private static String escape(String value) {
        return value
            .replace("\\", "\\\\")
            .replace("\t", "\\t")
            .replace("\r", "\\r")
            .replace("\n", "\\n");
    }

    private static String unescape(String value) {
        StringBuilder builder = new StringBuilder();
        boolean escaping = false;
        for (int index = 0; index < value.length(); index++) {
            char current = value.charAt(index);
            if (escaping) {
                switch (current) {
                    case 't':
                        builder.append('\t');
                        break;
                    case 'r':
                        builder.append('\r');
                        break;
                    case 'n':
                        builder.append('\n');
                        break;
                    case '\\':
                        builder.append('\\');
                        break;
                    default:
                        builder.append(current);
                        break;
                }
                escaping = false;
            } else if (current == '\\') {
                escaping = true;
            } else {
                builder.append(current);
            }
        }

        if (escaping) {
            builder.append('\\');
        }
        return builder.toString();
    }
}
