package canvascalendar.ui;

import canvascalendar.model.CalendarEvent;
import canvascalendar.model.CourseCalendar;
import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dialog;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.List;
import java.util.UUID;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public final class EventEditorDialog extends JDialog {
    private static final DateTimeFormatter INPUT_FORMAT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");

    public static final class Result {
        private final CalendarEvent event;
        private final boolean deleted;

        private Result(CalendarEvent event, boolean deleted) {
            this.event = event;
            this.deleted = deleted;
        }

        public CalendarEvent getEvent() {
            return event;
        }

        public boolean isDeleted() {
            return deleted;
        }
    }

    private final JTextField titleField;
    private final JComboBox<CourseCalendar> calendarBox;
    private final JTextField startField;
    private final JTextField endField;
    private final JTextField locationField;
    private final JTextArea detailsArea;
    private final CalendarEvent originalEvent;

    private Result result;

    private EventEditorDialog(Frame owner, List<CourseCalendar> calendars, CalendarEvent event, LocalDate presetDate) {
        super(owner, event == null ? "Create Event" : "Edit Event", true);
        this.originalEvent = event;

        setModalityType(Dialog.ModalityType.APPLICATION_MODAL);
        setLayout(new BorderLayout(12, 12));
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        JPanel form = new JPanel(new GridBagLayout());
        form.setBorder(BorderFactory.createEmptyBorder(16, 16, 4, 16));
        GridBagConstraints constraints = new GridBagConstraints();
        constraints.insets = new Insets(6, 6, 6, 6);
        constraints.anchor = GridBagConstraints.WEST;
        constraints.fill = GridBagConstraints.HORIZONTAL;
        constraints.weightx = 1.0;

        titleField = new JTextField(26);
        calendarBox = new JComboBox<>(calendars.toArray(new CourseCalendar[0]));
        startField = new JTextField(26);
        endField = new JTextField(26);
        locationField = new JTextField(26);
        detailsArea = new JTextArea(5, 26);
        detailsArea.setLineWrap(true);
        detailsArea.setWrapStyleWord(true);

        addField(form, constraints, 0, "Title", titleField);
        addField(form, constraints, 1, "Calendar", calendarBox);
        addField(form, constraints, 2, "Start", startField);
        addField(form, constraints, 3, "End", endField);
        addField(form, constraints, 4, "Location", locationField);

        constraints.gridx = 0;
        constraints.gridy = 5;
        constraints.weightx = 0.0;
        form.add(new JLabel("Details"), constraints);
        constraints.gridx = 1;
        constraints.weightx = 1.0;
        form.add(new JScrollPane(detailsArea), constraints);

        JPanel footer = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton deleteButton = new JButton("Delete");
        deleteButton.setEnabled(event != null);
        deleteButton.addActionListener(e -> {
            result = new Result(null, true);
            dispose();
        });

        JButton cancelButton = new JButton("Cancel");
        cancelButton.addActionListener(e -> dispose());

        JButton saveButton = new JButton("Save");
        saveButton.addActionListener(e -> save());

        footer.add(deleteButton);
        footer.add(cancelButton);
        footer.add(saveButton);

        populateFields(event, presetDate);

        add(form, BorderLayout.CENTER);
        add(footer, BorderLayout.SOUTH);
        pack();
        setLocationRelativeTo(owner);
    }

    public static Result showDialog(Frame owner, List<CourseCalendar> calendars, CalendarEvent event, LocalDate presetDate) {
        EventEditorDialog dialog = new EventEditorDialog(owner, calendars, event, presetDate);
        dialog.setVisible(true);
        return dialog.result;
    }

    private void populateFields(CalendarEvent event, LocalDate presetDate) {
        LocalDateTime start;
        LocalDateTime end;

        if (event == null) {
            start = LocalDateTime.of(presetDate, LocalTime.of(11, 0));
            end = start.plusHours(1);
            if (calendarBox.getItemCount() > 0) {
                calendarBox.setSelectedIndex(0);
            }
        } else {
            titleField.setText(event.getTitle());
            locationField.setText(event.getLocation());
            detailsArea.setText(event.getDetails());
            start = event.getStart();
            end = event.getEnd();
            selectCalendar(event.getCourseId());
        }

        startField.setText(INPUT_FORMAT.format(start));
        endField.setText(INPUT_FORMAT.format(end));
    }

    private void selectCalendar(String courseId) {
        for (int index = 0; index < calendarBox.getItemCount(); index++) {
            CourseCalendar calendar = calendarBox.getItemAt(index);
            if (calendar.getId().equals(courseId)) {
                calendarBox.setSelectedIndex(index);
                return;
            }
        }
    }

    private void addField(JPanel panel, GridBagConstraints constraints, int row, String label, Component component) {
        constraints.gridx = 0;
        constraints.gridy = row;
        constraints.weightx = 0.0;
        panel.add(new JLabel(label), constraints);

        constraints.gridx = 1;
        constraints.weightx = 1.0;
        panel.add(component, constraints);
    }

    private void save() {
        String title = titleField.getText().trim();
        if (title.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Title is required.", "Missing title", JOptionPane.ERROR_MESSAGE);
            return;
        }

        LocalDateTime start;
        LocalDateTime end;
        try {
            start = LocalDateTime.parse(startField.getText().trim(), INPUT_FORMAT);
            end = LocalDateTime.parse(endField.getText().trim(), INPUT_FORMAT);
        } catch (DateTimeParseException error) {
            JOptionPane.showMessageDialog(
                this,
                "Use date/time format yyyy-MM-dd HH:mm.",
                "Invalid date",
                JOptionPane.ERROR_MESSAGE
            );
            return;
        }

        if (!end.isAfter(start)) {
            JOptionPane.showMessageDialog(this, "End time must be after start time.", "Invalid range", JOptionPane.ERROR_MESSAGE);
            return;
        }

        CourseCalendar calendar = (CourseCalendar) calendarBox.getSelectedItem();
        if (calendar == null) {
            JOptionPane.showMessageDialog(this, "Select a calendar.", "Missing calendar", JOptionPane.ERROR_MESSAGE);
            return;
        }

        CalendarEvent event = new CalendarEvent(
            originalEvent == null ? UUID.randomUUID().toString() : originalEvent.getId(),
            title,
            calendar.getId(),
            start,
            end,
            locationField.getText().trim(),
            detailsArea.getText().trim()
        );

        result = new Result(event, false);
        dispose();
    }
}
