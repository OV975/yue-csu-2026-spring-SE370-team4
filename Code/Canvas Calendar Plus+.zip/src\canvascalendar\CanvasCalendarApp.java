package canvascalendar;

import canvascalendar.ui.CanvasCalendarFrame;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;

public final class CanvasCalendarApp {
    private CanvasCalendarApp() {
    }

    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ignored) {
        }

        SwingUtilities.invokeLater(() -> {
            CanvasCalendarFrame frame = new CanvasCalendarFrame();
            frame.setVisible(true);
        });
    }
}
