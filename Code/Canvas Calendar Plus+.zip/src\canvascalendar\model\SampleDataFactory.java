package canvascalendar.model;

import java.awt.Color;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public final class SampleDataFactory {
    private SampleDataFactory() {
    }

    public static List<CourseCalendar> createCalendars() {
        List<CourseCalendar> calendars = new ArrayList<>();
        calendars.add(new CourseCalendar("bio-220", "BIO-220 Cell Biology", new Color(0x0E8A5F)));
        calendars.add(new CourseCalendar("calc-201", "CALC-201 Integral Calculus", new Color(0x2D72D9)));
        calendars.add(new CourseCalendar("hist-110", "HIST-110 Modern World History", new Color(0xD97706)));
        calendars.add(new CourseCalendar("engr-330", "ENGR-330 Design Studio", new Color(0xC2410C)));
        return calendars;
    }

    public static List<CalendarEvent> createEvents(LocalDate anchorDate) {
        List<CalendarEvent> events = new ArrayList<>();
        LocalDate monday = anchorDate.with(DayOfWeek.MONDAY);

        events.add(event("Bio Lab Report", "bio-220", monday.plusDays(1), 9, 0, 10, 30,
            "Science Hall 201", "Upload your microscopy observations and attach the lab worksheet."));
        events.add(event("Calculus Quiz", "calc-201", monday.plusDays(2), 13, 0, 14, 0,
            "Math Building 118", "Bring a formula sheet. Closed notes except for one handwritten page."));
        events.add(event("History Discussion Post", "hist-110", monday.plusDays(3), 18, 0, 19, 0,
            "Canvas Discussion", "Initial post due before evening seminar starts."));
        events.add(event("Studio Critique", "engr-330", monday.plusDays(4), 15, 30, 17, 0,
            "Design Lab", "Present iteration three mockups and updated user flow."));
        events.add(event("Office Hours", "calc-201", monday.plusDays(1), 11, 0, 12, 0,
            "Room 318", "Optional review session for integration techniques."));
        events.add(event("Reading Checkpoint", "hist-110", monday.plusWeeks(1).plusDays(1), 8, 0, 8, 30,
            "Canvas Module 6", "Confirm completion of chapters 12 and 13."));
        events.add(event("Midterm Project Milestone", "engr-330", monday.plusWeeks(1).plusDays(3), 12, 0, 13, 0,
            "Canvas Assignment", "Submit annotated wireframes and revised rationale."));
        events.add(event("Bio Exam Review", "bio-220", monday.plusWeeks(2), 14, 0, 15, 30,
            "Science Hall 120", "Topics cover membranes, transport, and signaling."));

        return events;
    }

    private static CalendarEvent event(
        String title,
        String courseId,
        LocalDate date,
        int startHour,
        int startMinute,
        int endHour,
        int endMinute,
        String location,
        String details
    ) {
        return new CalendarEvent(
            UUID.randomUUID().toString(),
            title,
            courseId,
            LocalDateTime.of(date.getYear(), date.getMonth(), date.getDayOfMonth(), startHour, startMinute),
            LocalDateTime.of(date.getYear(), date.getMonth(), date.getDayOfMonth(), endHour, endMinute),
            location,
            details
        );
    }
}
