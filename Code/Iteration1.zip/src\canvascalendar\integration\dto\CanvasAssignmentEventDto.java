package canvascalendar.integration.dto;

import java.time.OffsetDateTime;

public final class CanvasAssignmentEventDto {
    private final String id;
    private final String title;
    private final String courseId;
    private final OffsetDateTime startAt;
    private final OffsetDateTime endAt;
    private final String description;
    private final String htmlUrl;

    public CanvasAssignmentEventDto(
        String id,
        String title,
        String courseId,
        OffsetDateTime startAt,
        OffsetDateTime endAt,
        String description,
        String htmlUrl
    ) {
        this.id = id;
        this.title = title;
        this.courseId = courseId;
        this.startAt = startAt;
        this.endAt = endAt;
        this.description = description;
        this.htmlUrl = htmlUrl;
    }

    public String getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getCourseId() {
        return courseId;
    }

    public OffsetDateTime getStartAt() {
        return startAt;
    }

    public OffsetDateTime getEndAt() {
        return endAt;
    }

    public String getDescription() {
        return description;
    }

    public String getHtmlUrl() {
        return htmlUrl;
    }
}
