package canvascalendar.integration;

import canvascalendar.integration.dto.CanvasAssignmentEventDto;
import canvascalendar.integration.dto.CanvasCourseDto;
import canvascalendar.model.CalendarEvent;
import canvascalendar.model.CourseCalendar;
import java.awt.Color;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public final class CanvasSyncService {
    private static final String COURSE_PREFIX = "canvas_course:";
    private static final String EVENT_PREFIX = "canvas_assignment:";

    private final CanvasApiClient apiClient;

    public CanvasSyncService(CanvasApiClient apiClient) {
        this.apiClient = apiClient;
    }

    public SyncResult sync(CanvasSyncConfig config) throws CanvasApiException {
        List<CanvasCourseDto> remoteCourses = apiClient.fetchCourses(config);
        List<String> contextCodes = new ArrayList<>();
        for (CanvasCourseDto course : remoteCourses) {
            contextCodes.add("course_" + course.getId());
        }

        List<CanvasAssignmentEventDto> remoteEvents = apiClient.fetchAssignmentEvents(config, contextCodes);
        List<CourseCalendar> calendars = new ArrayList<>();
        List<CalendarEvent> events = new ArrayList<>();

        for (CanvasCourseDto course : remoteCourses) {
            calendars.add(new CourseCalendar(localCourseId(course.getId()), course.getName(), deriveColor(course.getId())));
        }

        for (CanvasAssignmentEventDto event : remoteEvents) {
            String details = stripHtml(event.getDescription()).trim();
            if (!event.getHtmlUrl().isBlank()) {
                if (!details.isBlank()) {
                    details += "\n\n";
                }
                details += "Canvas URL: " + event.getHtmlUrl();
            }

            events.add(new CalendarEvent(
                localEventId(event.getId()),
                event.getTitle(),
                localCourseId(event.getCourseId()),
                LocalDateTime.from(event.getStartAt().toLocalDateTime()),
                LocalDateTime.from(event.getEndAt().toLocalDateTime()),
                "Canvas Assignment",
                details
            ));
        }

        return new SyncResult(calendars, events);
    }

    public static boolean isCanvasManagedCourse(String courseId) {
        return courseId != null && courseId.startsWith(COURSE_PREFIX);
    }

    public static boolean isCanvasManagedEvent(String eventId) {
        return eventId != null && eventId.startsWith(EVENT_PREFIX);
    }

    public static String localCourseId(String remoteCourseId) {
        return COURSE_PREFIX + remoteCourseId;
    }

    private String localEventId(String remoteEventId) {
        return EVENT_PREFIX + remoteEventId;
    }

    private Color deriveColor(String seed) {
        int hash = Math.abs(seed.hashCode());
        int red = 70 + (hash & 0x3F);
        int green = 90 + ((hash >> 6) & 0x3F);
        int blue = 110 + ((hash >> 12) & 0x3F);
        return new Color(Math.min(red, 220), Math.min(green, 220), Math.min(blue, 220));
    }

    private String stripHtml(String value) {
        if (value == null || value.isBlank()) {
            return "";
        }
        return value
            .replaceAll("(?i)<br\\s*/?>", "\n")
            .replaceAll("<[^>]+>", " ")
            .replace("&nbsp;", " ")
            .replace("&amp;", "&")
            .replace("&lt;", "<")
            .replace("&gt;", ">")
            .replaceAll("[ \\t\\x0B\\f\\r]+", " ")
            .replaceAll("\\n{3,}", "\n\n");
    }

    public static final class SyncResult {
        private final List<CourseCalendar> calendars;
        private final List<CalendarEvent> events;

        public SyncResult(List<CourseCalendar> calendars, List<CalendarEvent> events) {
            this.calendars = calendars;
            this.events = events;
        }

        public List<CourseCalendar> getCalendars() {
            return calendars;
        }

        public List<CalendarEvent> getEvents() {
            return events;
        }
    }
}
