package canvascalendar.integration.dto;

public final class CanvasCourseDto {
    private final String id;
    private final String name;

    public CanvasCourseDto(String id, String name) {
        this.id = id;
        this.name = name;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }
}
