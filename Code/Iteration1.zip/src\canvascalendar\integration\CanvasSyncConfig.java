package canvascalendar.integration;

public final class CanvasSyncConfig {
    private final String baseUrl;
    private final String accessToken;

    public CanvasSyncConfig(String baseUrl, String accessToken) {
        this.baseUrl = normalizeBaseUrl(baseUrl);
        this.accessToken = accessToken == null ? "" : accessToken.trim();
    }

    public String getBaseUrl() {
        return baseUrl;
    }

    public String getAccessToken() {
        return accessToken;
    }

    public boolean isValid() {
        return !baseUrl.isBlank() && !accessToken.isBlank();
    }

    private String normalizeBaseUrl(String value) {
        if (value == null) {
            return "";
        }

        String trimmed = value.trim();
        while (trimmed.endsWith("/")) {
            trimmed = trimmed.substring(0, trimmed.length() - 1);
        }
        if (trimmed.endsWith("/api/v1")) {
            trimmed = trimmed.substring(0, trimmed.length() - "/api/v1".length());
        }
        return trimmed;
    }
}
