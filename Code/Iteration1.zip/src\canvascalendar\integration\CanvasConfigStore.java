package canvascalendar.integration;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

public final class CanvasConfigStore {
    private static final String BASE_URL_KEY = "canvas.baseUrl";
    private final Path path;

    public CanvasConfigStore(Path path) {
        this.path = path;
    }

    public String loadBaseUrl() {
        Properties properties = new Properties();
        if (!Files.exists(path)) {
            return "";
        }

        try (InputStream input = Files.newInputStream(path)) {
            properties.load(input);
            return properties.getProperty(BASE_URL_KEY, "").trim();
        } catch (IOException ignored) {
            return "";
        }
    }

    public void saveBaseUrl(String baseUrl) throws IOException {
        Properties properties = new Properties();
        properties.setProperty(BASE_URL_KEY, baseUrl == null ? "" : baseUrl.trim());
        if (path.getParent() != null) {
            Files.createDirectories(path.getParent());
        }

        try (OutputStream output = Files.newOutputStream(path)) {
            properties.store(output, "Canvas Calendar Plus+ sync settings");
        }
    }
}
