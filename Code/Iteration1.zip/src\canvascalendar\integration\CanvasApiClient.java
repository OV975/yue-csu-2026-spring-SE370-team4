package canvascalendar.integration;

import canvascalendar.integration.dto.CanvasAssignmentEventDto;
import canvascalendar.integration.dto.CanvasCourseDto;
import canvascalendar.integration.json.SimpleJsonParser;
import java.io.IOException;
import java.math.BigDecimal;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public final class CanvasApiClient {
    private final HttpClient httpClient = HttpClient.newBuilder()
        .followRedirects(HttpClient.Redirect.NORMAL)
        .connectTimeout(Duration.ofSeconds(20))
        .build();

    public List<CanvasCourseDto> fetchCourses(CanvasSyncConfig config) throws CanvasApiException {
        List<Map<String, Object>> payload = fetchPagedObjects(
            config,
            config.getBaseUrl() + "/api/v1/courses?enrollment_state=active&per_page=100"
        );

        List<CanvasCourseDto> courses = new ArrayList<>();
        Set<String> seenIds = new LinkedHashSet<>();
        for (Map<String, Object> item : payload) {
            String id = asString(item.get("id"));
            if (id.isBlank() || !seenIds.add(id)) {
                continue;
            }

            String name = asString(item.get("name"));
            if (name.isBlank()) {
                name = asString(item.get("course_code"));
            }
            if (name.isBlank()) {
                name = "Course " + id;
            }
            courses.add(new CanvasCourseDto(id, name));
        }
        return courses;
    }

    public List<CanvasAssignmentEventDto> fetchAssignmentEvents(CanvasSyncConfig config, List<String> contextCodes)
        throws CanvasApiException {
        List<CanvasAssignmentEventDto> events = new ArrayList<>();
        Set<String> seenIds = new LinkedHashSet<>();
        if (contextCodes.isEmpty()) {
            return events;
        }

        for (int start = 0; start < contextCodes.size(); start += 10) {
            int end = Math.min(start + 10, contextCodes.size());
            List<String> batch = contextCodes.subList(start, end);
            StringBuilder url = new StringBuilder(config.getBaseUrl())
                .append("/api/v1/users/self/calendar_events?type=assignment&all_events=true&per_page=100");
            for (String contextCode : batch) {
                url.append("&context_codes[]=").append(encode(contextCode));
            }

            List<Map<String, Object>> payload = fetchPagedObjects(config, url.toString());
            for (Map<String, Object> item : payload) {
                CanvasAssignmentEventDto event = toAssignmentEvent(item);
                if (event == null || !seenIds.add(event.getId())) {
                    continue;
                }
                events.add(event);
            }
        }

        return events;
    }

    private List<Map<String, Object>> fetchPagedObjects(CanvasSyncConfig config, String initialUrl) throws CanvasApiException {
        List<Map<String, Object>> items = new ArrayList<>();
        String nextUrl = initialUrl;

        while (nextUrl != null && !nextUrl.isBlank()) {
            HttpResponse<String> response = sendRequest(config, nextUrl);
            Object root = parseJson(response.body());
            if (!(root instanceof List)) {
                throw new CanvasApiException("Canvas returned an unexpected response shape.");
            }

            for (Object entry : (List<?>) root) {
                if (entry instanceof Map) {
                    items.add(castMap(entry));
                }
            }
            nextUrl = extractNextLink(response.headers().firstValue("Link").orElse(""));
        }

        return items;
    }

    private HttpResponse<String> sendRequest(CanvasSyncConfig config, String url) throws CanvasApiException {
        try {
            HttpRequest request = HttpRequest.newBuilder(URI.create(url))
                .timeout(Duration.ofSeconds(30))
                .header("Authorization", "Bearer " + config.getAccessToken())
                .header("Accept", "application/json")
                .GET()
                .build();

            HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
            if (response.statusCode() < 200 || response.statusCode() >= 300) {
                String body = response.body() == null ? "" : response.body().trim();
                if (body.length() > 300) {
                    body = body.substring(0, 300);
                }
                throw new CanvasApiException("Canvas API request failed with status " + response.statusCode() + ": " + body);
            }
            return response;
        } catch (InterruptedException error) {
            Thread.currentThread().interrupt();
            throw new CanvasApiException("Canvas request was interrupted.", error);
        } catch (IOException error) {
            throw new CanvasApiException("Unable to contact Canvas. Check the base URL, token, and network access.", error);
        }
    }

    private Object parseJson(String body) throws CanvasApiException {
        try {
            return SimpleJsonParser.parse(body);
        } catch (RuntimeException error) {
            throw new CanvasApiException("Unable to parse Canvas JSON response.", error);
        }
    }

    private CanvasAssignmentEventDto toAssignmentEvent(Map<String, Object> item) {
        String id = asString(item.get("id"));
        String title = asString(item.get("title"));
        String contextCode = asString(item.get("context_code"));
        String courseId = parseCourseId(contextCode);
        String startAt = asString(item.get("start_at"));
        String endAt = asString(item.get("end_at"));
        String workflowState = asString(item.get("workflow_state"));

        if (id.isBlank() || title.isBlank() || courseId.isBlank() || startAt.isBlank() || endAt.isBlank()) {
            return null;
        }
        if ("deleted".equalsIgnoreCase(workflowState)) {
            return null;
        }

        try {
            return new CanvasAssignmentEventDto(
                id,
                title,
                courseId,
                OffsetDateTime.parse(startAt),
                OffsetDateTime.parse(endAt),
                asString(item.get("description")),
                asString(item.get("html_url"))
            );
        } catch (RuntimeException error) {
            return null;
        }
    }

    private String parseCourseId(String contextCode) {
        if (!contextCode.startsWith("course_")) {
            return "";
        }
        return contextCode.substring("course_".length());
    }

    private String extractNextLink(String linkHeader) {
        if (linkHeader == null || linkHeader.isBlank()) {
            return null;
        }

        String[] parts = linkHeader.split(",");
        for (String part : parts) {
            String[] segments = part.split(";");
            if (segments.length < 2) {
                continue;
            }
            String urlPart = segments[0].trim();
            String relPart = segments[1].trim();
            if (!relPart.contains("rel=\"next\"")) {
                continue;
            }
            if (urlPart.startsWith("<") && urlPart.endsWith(">")) {
                return urlPart.substring(1, urlPart.length() - 1);
            }
        }
        return null;
    }

    private String asString(Object value) {
        if (value == null) {
            return "";
        }
        if (value instanceof String) {
            return (String) value;
        }
        if (value instanceof BigDecimal) {
            BigDecimal decimal = (BigDecimal) value;
            try {
                return decimal.toBigIntegerExact().toString();
            } catch (ArithmeticException ignored) {
                return decimal.toPlainString();
            }
        }
        return String.valueOf(value);
    }

    @SuppressWarnings("unchecked")
    private Map<String, Object> castMap(Object value) {
        if (value instanceof Map) {
            return new LinkedHashMap<>((Map<String, Object>) value);
        }
        return new LinkedHashMap<>();
    }

    private String encode(String value) {
        return URLEncoder.encode(value, StandardCharsets.UTF_8);
    }
}
