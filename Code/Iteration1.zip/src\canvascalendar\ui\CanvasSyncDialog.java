package canvascalendar.ui;

import canvascalendar.integration.CanvasSyncConfig;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public final class CanvasSyncDialog extends JDialog {
    private final JTextField baseUrlField;
    private final JPasswordField tokenField;

    private CanvasSyncConfig result;

    private CanvasSyncDialog(Frame owner, String baseUrl) {
        super(owner, "Sync Canvas Assignments", true);
        setLayout(new BorderLayout(12, 12));
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        JPanel form = new JPanel(new GridBagLayout());
        form.setBorder(BorderFactory.createEmptyBorder(16, 16, 4, 16));
        GridBagConstraints constraints = new GridBagConstraints();
        constraints.insets = new Insets(6, 6, 6, 6);
        constraints.anchor = GridBagConstraints.WEST;
        constraints.fill = GridBagConstraints.HORIZONTAL;
        constraints.weightx = 1.0;

        baseUrlField = new JTextField(baseUrl, 28);
        tokenField = new JPasswordField(28);

        constraints.gridx = 0;
        constraints.gridy = 0;
        constraints.weightx = 0.0;
        form.add(new JLabel("Canvas Base URL"), constraints);
        constraints.gridx = 1;
        constraints.weightx = 1.0;
        form.add(baseUrlField, constraints);

        constraints.gridx = 0;
        constraints.gridy = 1;
        constraints.weightx = 0.0;
        form.add(new JLabel("Access Token"), constraints);
        constraints.gridx = 1;
        constraints.weightx = 1.0;
        form.add(tokenField, constraints);

        JPanel footer = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton cancelButton = new JButton("Cancel");
        cancelButton.addActionListener(e -> dispose());

        JButton syncButton = new JButton("Sync");
        syncButton.addActionListener(e -> submit());

        footer.add(cancelButton);
        footer.add(syncButton);

        add(form, BorderLayout.CENTER);
        add(footer, BorderLayout.SOUTH);
        pack();
        setLocationRelativeTo(owner);
    }

    public static CanvasSyncConfig showDialog(Frame owner, String baseUrl) {
        CanvasSyncDialog dialog = new CanvasSyncDialog(owner, baseUrl);
        dialog.setVisible(true);
        return dialog.result;
    }

    private void submit() {
        CanvasSyncConfig config = new CanvasSyncConfig(baseUrlField.getText(), new String(tokenField.getPassword()));
        if (!config.isValid()) {
            JOptionPane.showMessageDialog(this, "Enter both a Canvas base URL and an access token.", "Missing information", JOptionPane.ERROR_MESSAGE);
            return;
        }
        result = config;
        dispose();
    }
}
