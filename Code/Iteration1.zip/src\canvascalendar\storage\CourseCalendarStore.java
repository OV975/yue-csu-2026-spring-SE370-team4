package canvascalendar.storage;

import canvascalendar.model.CourseCalendar;
import java.awt.Color;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

public final class CourseCalendarStore {
    private final Path path;

    public CourseCalendarStore(Path path) {
        this.path = path;
    }

    public List<CourseCalendar> load() throws IOException {
        List<CourseCalendar> calendars = new ArrayList<>();
        if (!Files.exists(path)) {
            return calendars;
        }

        List<String> lines = Files.readAllLines(path, StandardCharsets.UTF_8);
        for (String line : lines) {
            if (line.isBlank() || line.startsWith("#")) {
                continue;
            }

            String[] fields = line.split("\t", -1);
            if (fields.length != 4) {
                continue;
            }

            CourseCalendar calendar = new CourseCalendar(
                unescape(fields[0]),
                unescape(fields[1]),
                new Color(Integer.parseInt(unescape(fields[2])))
            );
            calendar.setVisible(Boolean.parseBoolean(unescape(fields[3])));
            calendars.add(calendar);
        }
        return calendars;
    }

    public void save(List<CourseCalendar> calendars) throws IOException {
        if (path.getParent() != null) {
            Files.createDirectories(path.getParent());
        }

        List<String> lines = new ArrayList<>();
        lines.add("# Canvas Calendar Plus+ calendar store");
        for (CourseCalendar calendar : calendars) {
            lines.add(String.join("\t",
                escape(calendar.getId()),
                escape(calendar.getName()),
                escape(String.valueOf(calendar.getColor().getRGB())),
                escape(String.valueOf(calendar.isVisible()))
            ));
        }
        Files.write(path, lines, StandardCharsets.UTF_8);
    }

    private static String escape(String value) {
        return value
            .replace("\\", "\\\\")
            .replace("\t", "\\t")
            .replace("\r", "\\r")
            .replace("\n", "\\n");
    }

    private static String unescape(String value) {
        StringBuilder builder = new StringBuilder();
        boolean escaping = false;
        for (int index = 0; index < value.length(); index++) {
            char current = value.charAt(index);
            if (escaping) {
                switch (current) {
                    case 't':
                        builder.append('\t');
                        break;
                    case 'r':
                        builder.append('\r');
                        break;
                    case 'n':
                        builder.append('\n');
                        break;
                    case '\\':
                        builder.append('\\');
                        break;
                    default:
                        builder.append(current);
                        break;
                }
                escaping = false;
            } else if (current == '\\') {
                escaping = true;
            } else {
                builder.append(current);
            }
        }

        if (escaping) {
            builder.append('\\');
        }
        return builder.toString();
    }
}
