package canvascalendar.integration;

public final class CanvasApiException extends Exception {
    public CanvasApiException(String message) {
        super(message);
    }

    public CanvasApiException(String message, Throwable cause) {
        super(message, cause);
    }
}
