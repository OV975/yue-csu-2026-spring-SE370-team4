# Canvas Calendar Plus+

Canvas Calendar Plus+ is a standalone Java Swing implementation of a Canvas-style calendar interface for assignments and course events.

It includes:

- Month, week, and agenda views
- A Canvas-like left sidebar with mini month, course calendars, and upcoming items
- Search filtering across titles, course names, locations, and details
- Event creation, editing, and deletion
- UI customization for background colors, accent colors, larger text, and background images
- Local persistence to `data/events.db`
- CSV export to `data/calendar-export.csv`
- Sample course and assignment data so the UI opens populated

## Project Structure

`src/canvascalendar/CanvasCalendarApp.java`
Main entry point.

`src/canvascalendar/model/`
Calendar view enum, course calendar model, event model, and sample data generator.

`src/canvascalendar/storage/EventStore.java`
Simple file-backed storage for saving and loading events and calendars.

`src/canvascalendar/ui/`
Swing UI components for the main frame, month view, week view, agenda view, and event editor dialog.

`src/canvascalendar/ui/theme/`
Persistent theme settings and background-image rendering for calendar customization.

## Requirements

- JDK 17 or newer installed and available on `PATH`

## Run on Windows

1. Open PowerShell or Command Prompt in the project folder.
2. Run either `build.bat` / `run.bat` or `.\build.ps1` / `.\run.ps1`

## Run in IntelliJ IDEA

1. Open the project folder in IntelliJ.
2. Let IntelliJ import the included `pom.xml` as a Maven project.
3. Set the project SDK to JDK 17 or newer.
4. Run `canvascalendar.CanvasCalendarApp` or use Maven `exec:java`.

Detailed IntelliJ steps are in `RUN_IN_INTELLIJ.md`.

## Manual Compile

```bat
mkdir out
javac -d out src\canvascalendar\*.java src\canvascalendar\model\*.java src\canvascalendar\storage\*.java src\canvascalendar\integration\*.java src\canvascalendar\integration\dto\*.java src\canvascalendar\integration\json\*.java src\canvascalendar\ui\*.java src\canvascalendar\ui\theme\*.java
java -cp out canvascalendar.CanvasCalendarApp
```

## Notes

- This is a Java desktop recreation inspired by Canvas calendar behavior and layout. It is not Canvas source code and does not include Canvas branding assets.
- Events are stored in `data/events.db`.
- Calendar metadata is stored in `data/calendars.db`.
- UI theme settings are stored in `data/ui-theme.properties`.
- Filter the visible list from the sidebar search field.
- Use `Export CSV` to write the currently visible events to `data/calendar-export.csv`.
- Use `Customize UI` to change colors, choose a background image, and adjust the look of the calendar.
- Double-click a day in month view to create an event quickly.
