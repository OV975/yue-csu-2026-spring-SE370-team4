package canvascalendar.ui.theme;

public enum BackgroundImageMode {
    FILL,
    FIT,
    TILE
}
