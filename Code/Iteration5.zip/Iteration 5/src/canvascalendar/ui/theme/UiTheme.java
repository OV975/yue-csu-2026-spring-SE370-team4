package canvascalendar.ui.theme;

import java.awt.Color;

public final class UiTheme {
    private Color appBackgroundColor;
    private Color sidebarBackgroundColor;
    private Color surfaceColor;
    private Color accentColor;
    private String backgroundImagePath;
    private BackgroundImageMode backgroundImageMode;
    private float backgroundImageOpacity;
    private boolean largeText;

    public UiTheme() {
        this.appBackgroundColor = new Color(0xEEF2F7);
        this.sidebarBackgroundColor = Color.WHITE;
        this.surfaceColor = Color.WHITE;
        this.accentColor = new Color(0x0D6EFD);
        this.backgroundImagePath = "";
        this.backgroundImageMode = BackgroundImageMode.FILL;
        this.backgroundImageOpacity = 0.22f;
        this.largeText = false;
    }

    public Color getAppBackgroundColor() {
        return appBackgroundColor;
    }

    public void setAppBackgroundColor(Color appBackgroundColor) {
        this.appBackgroundColor = appBackgroundColor;
    }

    public Color getSidebarBackgroundColor() {
        return sidebarBackgroundColor;
    }

    public void setSidebarBackgroundColor(Color sidebarBackgroundColor) {
        this.sidebarBackgroundColor = sidebarBackgroundColor;
    }

    public Color getSurfaceColor() {
        return surfaceColor;
    }

    public void setSurfaceColor(Color surfaceColor) {
        this.surfaceColor = surfaceColor;
    }

    public Color getAccentColor() {
        return accentColor;
    }

    public void setAccentColor(Color accentColor) {
        this.accentColor = accentColor;
    }

    public String getBackgroundImagePath() {
        return backgroundImagePath;
    }

    public void setBackgroundImagePath(String backgroundImagePath) {
        this.backgroundImagePath = backgroundImagePath == null ? "" : backgroundImagePath.trim();
    }

    public BackgroundImageMode getBackgroundImageMode() {
        return backgroundImageMode;
    }

    public void setBackgroundImageMode(BackgroundImageMode backgroundImageMode) {
        this.backgroundImageMode = backgroundImageMode == null ? BackgroundImageMode.FILL : backgroundImageMode;
    }

    public float getBackgroundImageOpacity() {
        return backgroundImageOpacity;
    }

    public void setBackgroundImageOpacity(float backgroundImageOpacity) {
        this.backgroundImageOpacity = Math.max(0f, Math.min(1f, backgroundImageOpacity));
    }

    public boolean isLargeText() {
        return largeText;
    }

    public void setLargeText(boolean largeText) {
        this.largeText = largeText;
    }
}
