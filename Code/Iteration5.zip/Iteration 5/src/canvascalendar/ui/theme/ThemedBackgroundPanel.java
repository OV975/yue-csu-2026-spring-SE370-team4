package canvascalendar.ui.theme;

import java.awt.AlphaComposite;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.JPanel;

public final class ThemedBackgroundPanel extends JPanel {
    private UiTheme theme;
    private String cachedPath = null;
    private BufferedImage cachedImage = null;

    public ThemedBackgroundPanel(UiTheme theme) {
        this.theme = theme;
        setOpaque(true);
    }

    public void setTheme(UiTheme theme) {
        this.theme = theme;
        repaint();
    }

    @Override
    protected void paintComponent(Graphics graphics) {
        super.paintComponent(graphics);
        if (theme == null) {
            return;
        }

        Graphics2D g2 = (Graphics2D) graphics.create();
        g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
        g2.setColor(theme.getAppBackgroundColor());
        g2.fillRect(0, 0, getWidth(), getHeight());

        BufferedImage image = loadImage(theme.getBackgroundImagePath());
        if (image != null) {
            g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, theme.getBackgroundImageOpacity()));
            switch (theme.getBackgroundImageMode()) {
                case FIT:
                    paintFit(g2, image);
                    break;
                case TILE:
                    paintTile(g2, image);
                    break;
                case FILL:
                default:
                    paintFill(g2, image);
                    break;
            }
        }
        g2.dispose();
    }

    private BufferedImage loadImage(String path) {
        if (path == null || path.isBlank()) {
            cachedPath = null;
            cachedImage = null;
            return null;
        }
        if (path.equals(cachedPath)) {
            return cachedImage;
        }
        cachedPath = path;
        try {
            cachedImage = ImageIO.read(new File(path));
        } catch (IOException error) {
            cachedImage = null;
        }
        return cachedImage;
    }

    private void paintFill(Graphics2D g2, BufferedImage image) {
        double widthScale = getWidth() / (double) image.getWidth();
        double heightScale = getHeight() / (double) image.getHeight();
        double scale = Math.max(widthScale, heightScale);
        int drawWidth = (int) Math.round(image.getWidth() * scale);
        int drawHeight = (int) Math.round(image.getHeight() * scale);
        int x = (getWidth() - drawWidth) / 2;
        int y = (getHeight() - drawHeight) / 2;
        g2.drawImage(image.getScaledInstance(drawWidth, drawHeight, Image.SCALE_SMOOTH), x, y, null);
    }

    private void paintFit(Graphics2D g2, BufferedImage image) {
        double widthScale = getWidth() / (double) image.getWidth();
        double heightScale = getHeight() / (double) image.getHeight();
        double scale = Math.min(widthScale, heightScale);
        int drawWidth = (int) Math.round(image.getWidth() * scale);
        int drawHeight = (int) Math.round(image.getHeight() * scale);
        int x = (getWidth() - drawWidth) / 2;
        int y = (getHeight() - drawHeight) / 2;
        g2.drawImage(image.getScaledInstance(drawWidth, drawHeight, Image.SCALE_SMOOTH), x, y, null);
    }

    private void paintTile(Graphics2D g2, BufferedImage image) {
        for (int y = 0; y < getHeight(); y += image.getHeight()) {
            for (int x = 0; x < getWidth(); x += image.getWidth()) {
                g2.drawImage(image, x, y, null);
            }
        }
    }
}
