package canvascalendar.ui.theme;

import java.awt.Color;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

public final class UiThemeStore {
    private final Path path;

    public UiThemeStore(Path path) {
        this.path = path;
    }

    public UiTheme load() {
        UiTheme theme = new UiTheme();
        if (!Files.exists(path)) {
            return theme;
        }

        Properties properties = new Properties();
        try (InputStream input = Files.newInputStream(path)) {
            properties.load(input);
            theme.setAppBackgroundColor(readColor(properties, "theme.appBackground", theme.getAppBackgroundColor()));
            theme.setSidebarBackgroundColor(readColor(properties, "theme.sidebarBackground", theme.getSidebarBackgroundColor()));
            theme.setSurfaceColor(readColor(properties, "theme.surface", theme.getSurfaceColor()));
            theme.setAccentColor(readColor(properties, "theme.accent", theme.getAccentColor()));
            theme.setBackgroundImagePath(properties.getProperty("theme.backgroundImagePath", ""));
            theme.setBackgroundImageMode(readMode(properties.getProperty("theme.backgroundImageMode", "FILL")));
            theme.setBackgroundImageOpacity(readFloat(properties.getProperty("theme.backgroundImageOpacity", "0.22"), 0.22f));
            theme.setLargeText(Boolean.parseBoolean(properties.getProperty("theme.largeText", "false")));
        } catch (IOException ignored) {
            return theme;
        }
        return theme;
    }

    public void save(UiTheme theme) throws IOException {
        Properties properties = new Properties();
        properties.setProperty("theme.appBackground", String.valueOf(theme.getAppBackgroundColor().getRGB()));
        properties.setProperty("theme.sidebarBackground", String.valueOf(theme.getSidebarBackgroundColor().getRGB()));
        properties.setProperty("theme.surface", String.valueOf(theme.getSurfaceColor().getRGB()));
        properties.setProperty("theme.accent", String.valueOf(theme.getAccentColor().getRGB()));
        properties.setProperty("theme.backgroundImagePath", theme.getBackgroundImagePath());
        properties.setProperty("theme.backgroundImageMode", theme.getBackgroundImageMode().name());
        properties.setProperty("theme.backgroundImageOpacity", String.valueOf(theme.getBackgroundImageOpacity()));
        properties.setProperty("theme.largeText", String.valueOf(theme.isLargeText()));

        if (path.getParent() != null) {
            Files.createDirectories(path.getParent());
        }
        try (OutputStream output = Files.newOutputStream(path)) {
            properties.store(output, "Canvas Calendar Plus+ UI theme");
        }
    }

    private Color readColor(Properties properties, String key, Color fallback) {
        String value = properties.getProperty(key);
        if (value == null || value.isBlank()) {
            return fallback;
        }
        try {
            return new Color(Integer.parseInt(value), true);
        } catch (NumberFormatException error) {
            return fallback;
        }
    }

    private BackgroundImageMode readMode(String value) {
        try {
            return BackgroundImageMode.valueOf(value);
        } catch (IllegalArgumentException error) {
            return BackgroundImageMode.FILL;
        }
    }

    private float readFloat(String value, float fallback) {
        try {
            return Float.parseFloat(value);
        } catch (NumberFormatException error) {
            return fallback;
        }
    }
}
