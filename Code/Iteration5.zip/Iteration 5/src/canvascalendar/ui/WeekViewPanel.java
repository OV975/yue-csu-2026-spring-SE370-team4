package canvascalendar.ui;

import canvascalendar.model.CalendarEvent;
import canvascalendar.model.CourseCalendar;
import canvascalendar.ui.theme.UiTheme;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.FlowLayout;
import java.awt.Font;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAdjusters;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

public final class WeekViewPanel extends JScrollPane {
    private static final DateTimeFormatter DAY_FORMAT = DateTimeFormatter.ofPattern("EEE d");
    private final JPanel content;

    public WeekViewPanel() {
        content = new JPanel(new java.awt.GridLayout(1, 7, 8, 0));
        content.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
        setViewportView(content);
        setBorder(BorderFactory.createEmptyBorder());
        getVerticalScrollBar().setUnitIncrement(14);
    }

    public void render(
        LocalDate focusDate,
        LocalDate today,
        List<CalendarEvent> events,
        Map<String, CourseCalendar> calendars,
        UiTheme theme,
        Consumer<LocalDate> onDateSelected,
        Consumer<LocalDate> onCreateEvent,
        Consumer<CalendarEvent> onEventSelected
    ) {
        content.removeAll();
        content.setBackground(soft(theme.getAppBackgroundColor(), Color.WHITE, 0.2));
        LocalDate weekStart = focusDate.with(TemporalAdjusters.previousOrSame(DayOfWeek.SUNDAY));

        for (int offset = 0; offset < 7; offset++) {
            LocalDate date = weekStart.plusDays(offset);
            List<CalendarEvent> dayEvents = new ArrayList<>();
            for (CalendarEvent event : events) {
                if (event.occursOn(date)) {
                    dayEvents.add(event);
                }
            }
            dayEvents.sort(Comparator.comparing(CalendarEvent::getStart));
            content.add(buildDayColumn(date, today, dayEvents, calendars, theme, onDateSelected, onCreateEvent, onEventSelected));
        }

        content.revalidate();
        content.repaint();
    }

    private JPanel buildDayColumn(
        LocalDate date,
        LocalDate today,
        List<CalendarEvent> dayEvents,
        Map<String, CourseCalendar> calendars,
        UiTheme theme,
        Consumer<LocalDate> onDateSelected,
        Consumer<LocalDate> onCreateEvent,
        Consumer<CalendarEvent> onEventSelected
    ) {
        JPanel column = new JPanel(new BorderLayout(0, 8));
        column.setBackground(theme.getSurfaceColor());
        column.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(soft(theme.getSurfaceColor(), Color.BLACK, 0.18), date.equals(today) ? 2 : 1),
            BorderFactory.createEmptyBorder(10, 10, 10, 10)
        ));

        JButton header = new JButton(DAY_FORMAT.format(date).toUpperCase());
        header.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
        header.setFocusPainted(false);
        header.setContentAreaFilled(false);
        header.setHorizontalAlignment(JLabel.LEFT);
        header.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        if (date.equals(today)) {
            header.setForeground(theme.getAccentColor());
        }
        header.addActionListener(e -> onDateSelected.accept(date));

        JPanel body = new JPanel();
        body.setOpaque(false);
        body.setLayout(new BoxLayout(body, BoxLayout.Y_AXIS));

        if (dayEvents.isEmpty()) {
            JLabel empty = new JLabel("No assignments scheduled");
            empty.setForeground(new Color(0x6B778C));
            empty.setBorder(BorderFactory.createEmptyBorder(8, 4, 4, 4));
            body.add(empty);
        } else {
            for (CalendarEvent event : dayEvents) {
                body.add(createEventCard(event, calendars, onEventSelected));
            }
        }

        JButton addButton = new JButton("Add Event");
        addButton.setFocusPainted(false);
        addButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        addButton.setBackground(soft(theme.getAccentColor(), Color.WHITE, 0.82));
        addButton.addActionListener(e -> onCreateEvent.accept(date));

        JPanel footer = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        footer.setOpaque(false);
        footer.add(addButton);

        column.add(header, BorderLayout.NORTH);
        column.add(body, BorderLayout.CENTER);
        column.add(footer, BorderLayout.SOUTH);
        return column;
    }

    private JPanel createEventCard(
        CalendarEvent event,
        Map<String, CourseCalendar> calendars,
        Consumer<CalendarEvent> onEventSelected
    ) {
        CourseCalendar calendar = calendars.get(event.getCourseId());
        Color accent = calendar == null ? new Color(0x2D72D9) : calendar.getColor();

        JButton button = new JButton("<html><b>" + escape(event.getTitle()) + "</b><br/>" + escape(event.getTimeLabel()) + "</html>");
        button.setFocusPainted(false);
        button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        button.setHorizontalAlignment(JLabel.LEFT);
        button.setBackground(new Color(accent.getRed(), accent.getGreen(), accent.getBlue(), 38));
        button.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(0, 4, 0, 0, accent),
            BorderFactory.createEmptyBorder(8, 8, 8, 8)
        ));
        button.setFont(button.getFont().deriveFont(Font.PLAIN));
        button.addActionListener(e -> onEventSelected.accept(event));

        JPanel wrapper = new JPanel(new BorderLayout());
        wrapper.setOpaque(false);
        wrapper.setBorder(BorderFactory.createEmptyBorder(0, 0, 8, 0));
        wrapper.add(button, BorderLayout.CENTER);
        return wrapper;
    }

    private String escape(String value) {
        return value.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
    }

    private Color soft(Color first, Color second, double amountSecond) {
        double amountFirst = 1.0 - amountSecond;
        int red = (int) Math.round((first.getRed() * amountFirst) + (second.getRed() * amountSecond));
        int green = (int) Math.round((first.getGreen() * amountFirst) + (second.getGreen() * amountSecond));
        int blue = (int) Math.round((first.getBlue() * amountFirst) + (second.getBlue() * amountSecond));
        return new Color(red, green, blue);
    }
}
