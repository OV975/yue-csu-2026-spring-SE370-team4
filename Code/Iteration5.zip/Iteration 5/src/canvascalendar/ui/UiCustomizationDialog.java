package canvascalendar.ui;

import canvascalendar.ui.theme.BackgroundImageMode;
import canvascalendar.ui.theme.UiTheme;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.io.File;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JColorChooser;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.JTextField;
import javax.swing.filechooser.FileNameExtensionFilter;

public final class UiCustomizationDialog extends JDialog {
    private final UiTheme workingTheme;
    private final JButton appBackgroundButton;
    private final JButton sidebarButton;
    private final JButton surfaceButton;
    private final JButton accentButton;
    private final JTextField imagePathField;
    private final JComboBox<BackgroundImageMode> imageModeBox;
    private final JSlider opacitySlider;
    private final JCheckBox largeTextBox;

    private UiTheme result;

    private UiCustomizationDialog(Frame owner, UiTheme initialTheme) {
        super(owner, "Customize Calendar UI", true);
        this.workingTheme = copyTheme(initialTheme);

        setLayout(new BorderLayout(12, 12));
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        JPanel form = new JPanel(new GridBagLayout());
        form.setBorder(BorderFactory.createEmptyBorder(16, 16, 4, 16));
        GridBagConstraints constraints = new GridBagConstraints();
        constraints.insets = new Insets(6, 6, 6, 6);
        constraints.anchor = GridBagConstraints.WEST;
        constraints.fill = GridBagConstraints.HORIZONTAL;

        appBackgroundButton = createColorButton(workingTheme.getAppBackgroundColor());
        sidebarButton = createColorButton(workingTheme.getSidebarBackgroundColor());
        surfaceButton = createColorButton(workingTheme.getSurfaceColor());
        accentButton = createColorButton(workingTheme.getAccentColor());
        imagePathField = new JTextField(workingTheme.getBackgroundImagePath(), 24);
        imageModeBox = new JComboBox<>(BackgroundImageMode.values());
        imageModeBox.setSelectedItem(workingTheme.getBackgroundImageMode());
        opacitySlider = new JSlider(0, 100, Math.round(workingTheme.getBackgroundImageOpacity() * 100f));
        largeTextBox = new JCheckBox("Use larger text", workingTheme.isLargeText());

        addColorRow(form, constraints, 0, "App Background", appBackgroundButton);
        addColorRow(form, constraints, 1, "Sidebar Background", sidebarButton);
        addColorRow(form, constraints, 2, "Card Surface", surfaceButton);
        addColorRow(form, constraints, 3, "Accent Color", accentButton);

        addRow(form, constraints, 4, "Background Image", createImageSelector());
        addRow(form, constraints, 5, "Image Display", imageModeBox);
        addRow(form, constraints, 6, "Image Opacity", opacitySlider);
        addRow(form, constraints, 7, "Text Size", largeTextBox);

        JPanel footer = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton resetButton = new JButton("Reset");
        resetButton.addActionListener(e -> resetDefaults());

        JButton cancelButton = new JButton("Cancel");
        cancelButton.addActionListener(e -> dispose());

        JButton saveButton = new JButton("Save");
        saveButton.addActionListener(e -> saveTheme());

        footer.add(resetButton);
        footer.add(cancelButton);
        footer.add(saveButton);

        add(form, BorderLayout.CENTER);
        add(footer, BorderLayout.SOUTH);
        pack();
        setLocationRelativeTo(owner);
    }

    public static UiTheme showDialog(Frame owner, UiTheme initialTheme) {
        UiCustomizationDialog dialog = new UiCustomizationDialog(owner, initialTheme);
        dialog.setVisible(true);
        return dialog.result;
    }

    private JPanel createImageSelector() {
        JPanel panel = new JPanel(new BorderLayout(6, 0));
        panel.add(imagePathField, BorderLayout.CENTER);

        JPanel actions = new JPanel(new FlowLayout(FlowLayout.LEFT, 4, 0));
        JButton browseButton = new JButton("Browse");
        browseButton.addActionListener(e -> chooseImage());
        JButton clearButton = new JButton("Clear");
        clearButton.addActionListener(e -> imagePathField.setText(""));
        actions.add(browseButton);
        actions.add(clearButton);

        panel.add(actions, BorderLayout.EAST);
        return panel;
    }

    private JButton createColorButton(Color initialColor) {
        JButton button = new JButton(colorText(initialColor));
        button.setBackground(initialColor);
        button.setForeground(contrastColor(initialColor));
        button.addActionListener(e -> chooseColor(button));
        return button;
    }

    private void chooseColor(JButton button) {
        Color selected = JColorChooser.showDialog(this, "Choose Color", button.getBackground());
        if (selected == null) {
            return;
        }
        button.setBackground(selected);
        button.setForeground(contrastColor(selected));
        button.setText(colorText(selected));
    }

    private void chooseImage() {
        JFileChooser chooser = new JFileChooser();
        chooser.setFileFilter(new FileNameExtensionFilter("Images", "png", "jpg", "jpeg", "gif", "bmp"));
        if (!imagePathField.getText().isBlank()) {
            chooser.setSelectedFile(new File(imagePathField.getText()));
        }
        if (chooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
            imagePathField.setText(chooser.getSelectedFile().getAbsolutePath());
        }
    }

    private void resetDefaults() {
        UiTheme defaults = new UiTheme();
        applyTheme(defaults);
    }

    private void applyTheme(UiTheme theme) {
        updateColorButton(appBackgroundButton, theme.getAppBackgroundColor());
        updateColorButton(sidebarButton, theme.getSidebarBackgroundColor());
        updateColorButton(surfaceButton, theme.getSurfaceColor());
        updateColorButton(accentButton, theme.getAccentColor());
        imagePathField.setText(theme.getBackgroundImagePath());
        imageModeBox.setSelectedItem(theme.getBackgroundImageMode());
        opacitySlider.setValue(Math.round(theme.getBackgroundImageOpacity() * 100f));
        largeTextBox.setSelected(theme.isLargeText());
    }

    private void updateColorButton(JButton button, Color color) {
        button.setBackground(color);
        button.setForeground(contrastColor(color));
        button.setText(colorText(color));
    }

    private void addColorRow(JPanel panel, GridBagConstraints constraints, int row, String label, JButton button) {
        addRow(panel, constraints, row, label, button);
    }

    private void addRow(JPanel panel, GridBagConstraints constraints, int row, String label, java.awt.Component component) {
        constraints.gridx = 0;
        constraints.gridy = row;
        constraints.weightx = 0.0;
        panel.add(new JLabel(label), constraints);

        constraints.gridx = 1;
        constraints.weightx = 1.0;
        panel.add(component, constraints);
    }

    private void saveTheme() {
        workingTheme.setAppBackgroundColor(appBackgroundButton.getBackground());
        workingTheme.setSidebarBackgroundColor(sidebarButton.getBackground());
        workingTheme.setSurfaceColor(surfaceButton.getBackground());
        workingTheme.setAccentColor(accentButton.getBackground());
        workingTheme.setBackgroundImagePath(imagePathField.getText().trim());
        workingTheme.setBackgroundImageMode((BackgroundImageMode) imageModeBox.getSelectedItem());
        workingTheme.setBackgroundImageOpacity(opacitySlider.getValue() / 100f);
        workingTheme.setLargeText(largeTextBox.isSelected());
        result = copyTheme(workingTheme);
        dispose();
    }

    private UiTheme copyTheme(UiTheme source) {
        UiTheme copy = new UiTheme();
        copy.setAppBackgroundColor(source.getAppBackgroundColor());
        copy.setSidebarBackgroundColor(source.getSidebarBackgroundColor());
        copy.setSurfaceColor(source.getSurfaceColor());
        copy.setAccentColor(source.getAccentColor());
        copy.setBackgroundImagePath(source.getBackgroundImagePath());
        copy.setBackgroundImageMode(source.getBackgroundImageMode());
        copy.setBackgroundImageOpacity(source.getBackgroundImageOpacity());
        copy.setLargeText(source.isLargeText());
        return copy;
    }

    private String colorText(Color color) {
        return String.format("#%02X%02X%02X", color.getRed(), color.getGreen(), color.getBlue());
    }

    private Color contrastColor(Color color) {
        double brightness = (0.299 * color.getRed()) + (0.587 * color.getGreen()) + (0.114 * color.getBlue());
        return brightness >= 140 ? Color.BLACK : Color.WHITE;
    }
}
