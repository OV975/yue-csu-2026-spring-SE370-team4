package canvascalendar.ui;

import canvascalendar.model.CalendarEvent;
import canvascalendar.model.CourseCalendar;
import canvascalendar.ui.theme.UiTheme;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.FlowLayout;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

public final class AgendaViewPanel extends JScrollPane {
    private static final DateTimeFormatter DATE_FORMAT = DateTimeFormatter.ofPattern("EEEE, MMM d");
    private final JPanel content;

    public AgendaViewPanel() {
        content = new JPanel();
        content.setLayout(new BoxLayout(content, BoxLayout.Y_AXIS));
        content.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
        setViewportView(content);
        setBorder(BorderFactory.createEmptyBorder());
        getVerticalScrollBar().setUnitIncrement(14);
    }

    public void render(
        LocalDate focusDate,
        List<CalendarEvent> events,
        Map<String, CourseCalendar> calendars,
        UiTheme theme,
        Consumer<CalendarEvent> onEventSelected
    ) {
        content.removeAll();
        content.setBackground(soft(theme.getAppBackgroundColor(), Color.WHITE, 0.2));

        List<CalendarEvent> agenda = new ArrayList<>();
        for (CalendarEvent event : events) {
            if (!event.getEnd().toLocalDate().isBefore(focusDate.minusDays(1))) {
                agenda.add(event);
            }
        }
        agenda.sort(Comparator.comparing(CalendarEvent::getStart));

        if (agenda.isEmpty()) {
            JPanel empty = new JPanel(new FlowLayout(FlowLayout.LEFT));
            empty.setBackground(theme.getSurfaceColor());
            empty.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(soft(theme.getSurfaceColor(), Color.BLACK, 0.18)),
                BorderFactory.createEmptyBorder(16, 16, 16, 16)
            ));
            empty.add(new JLabel("No upcoming assignments or events."));
            content.add(empty);
        } else {
            LocalDate lastDate = null;
            for (CalendarEvent event : agenda) {
                LocalDate current = event.getStart().toLocalDate();
                if (!current.equals(lastDate)) {
                    content.add(createDateHeader(current, theme));
                    lastDate = current;
                }
                content.add(createAgendaRow(event, calendars, theme, onEventSelected));
            }
        }

        content.revalidate();
        content.repaint();
    }

    private JPanel createDateHeader(LocalDate date, UiTheme theme) {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        panel.setOpaque(false);
        panel.setBorder(BorderFactory.createEmptyBorder(0, 0, 8, 0));

        JLabel label = new JLabel(DATE_FORMAT.format(date));
        label.setForeground(theme.getAccentColor().darker());
        label.setBorder(BorderFactory.createEmptyBorder(12, 2, 8, 2));
        panel.add(label);
        return panel;
    }

    private JPanel createAgendaRow(
        CalendarEvent event,
        Map<String, CourseCalendar> calendars,
        UiTheme theme,
        Consumer<CalendarEvent> onEventSelected
    ) {
        CourseCalendar calendar = calendars.get(event.getCourseId());
        Color accent = calendar == null ? theme.getAccentColor() : calendar.getColor();

        JButton button = new JButton("<html><b>" + escape(event.getTitle()) + "</b><br/>"
            + escape(event.getTimeLabel()) + " | " + escape(calendar == null ? "Course" : calendar.getName())
            + (event.getLocation().isBlank() ? "" : "<br/>" + escape(event.getLocation()))
            + "</html>");
        button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        button.setFocusPainted(false);
        button.setHorizontalAlignment(JLabel.LEFT);
        button.setBackground(theme.getSurfaceColor());
        button.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(0, 4, 0, 0, accent),
            BorderFactory.createEmptyBorder(10, 12, 10, 12)
        ));
        button.addActionListener(e -> onEventSelected.accept(event));

        JPanel wrapper = new JPanel(new BorderLayout());
        wrapper.setOpaque(false);
        wrapper.setBorder(BorderFactory.createEmptyBorder(0, 0, 8, 0));
        wrapper.add(button, BorderLayout.CENTER);
        return wrapper;
    }

    private String escape(String value) {
        return value.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
    }

    private Color soft(Color first, Color second, double amountSecond) {
        double amountFirst = 1.0 - amountSecond;
        int red = (int) Math.round((first.getRed() * amountFirst) + (second.getRed() * amountSecond));
        int green = (int) Math.round((first.getGreen() * amountFirst) + (second.getGreen() * amountSecond));
        int blue = (int) Math.round((first.getBlue() * amountFirst) + (second.getBlue() * amountSecond));
        return new Color(red, green, blue);
    }
}
