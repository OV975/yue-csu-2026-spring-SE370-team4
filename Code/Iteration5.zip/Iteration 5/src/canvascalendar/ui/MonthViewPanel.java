package canvascalendar.ui;

import canvascalendar.model.CalendarEvent;
import canvascalendar.model.CourseCalendar;
import canvascalendar.ui.theme.UiTheme;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAdjusters;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.SwingConstants;

public final class MonthViewPanel extends JScrollPane {
    private static final DateTimeFormatter WEEKDAY = DateTimeFormatter.ofPattern("EEE");
    private static final Color MUTED_TEXT = new Color(0x6B778C);

    private final JPanel content;

    public MonthViewPanel() {
        content = new JPanel(new BorderLayout(0, 8));
        setViewportView(content);
        setBorder(BorderFactory.createEmptyBorder());
        getVerticalScrollBar().setUnitIncrement(14);
    }

    public void render(
        LocalDate focusDate,
        LocalDate today,
        List<CalendarEvent> events,
        Map<String, CourseCalendar> calendars,
        UiTheme theme,
        Consumer<LocalDate> onDateSelected,
        Consumer<LocalDate> onCreateEvent,
        Consumer<CalendarEvent> onEventSelected
    ) {
        Color background = soft(theme.getAppBackgroundColor(), Color.WHITE, 0.2);
        content.removeAll();
        content.setBackground(background);

        JPanel header = new JPanel(new GridLayout(1, 7, 6, 0));
        header.setBorder(BorderFactory.createEmptyBorder(8, 8, 0, 8));
        header.setBackground(background);
        LocalDate headerStart = focusDate.withDayOfMonth(1).with(TemporalAdjusters.previousOrSame(DayOfWeek.SUNDAY));
        for (int column = 0; column < 7; column++) {
            JLabel label = new JLabel(WEEKDAY.format(headerStart.plusDays(column)).toUpperCase(), SwingConstants.CENTER);
            label.setForeground(MUTED_TEXT);
            header.add(label);
        }

        JPanel grid = new JPanel(new GridLayout(6, 7, 6, 6));
        grid.setBorder(BorderFactory.createEmptyBorder(0, 8, 8, 8));
        grid.setBackground(background);

        YearMonth month = YearMonth.from(focusDate);
        LocalDate firstCell = month.atDay(1).with(TemporalAdjusters.previousOrSame(DayOfWeek.SUNDAY));
        for (int offset = 0; offset < 42; offset++) {
            LocalDate cellDate = firstCell.plusDays(offset);
            List<CalendarEvent> dayEvents = new ArrayList<>();
            for (CalendarEvent event : events) {
                if (event.occursOn(cellDate)) {
                    dayEvents.add(event);
                }
            }
            dayEvents.sort(Comparator.comparing(CalendarEvent::getStart));
            grid.add(buildDayCell(cellDate, month, focusDate, today, dayEvents, calendars, theme, onDateSelected, onCreateEvent, onEventSelected));
        }

        content.add(header, BorderLayout.NORTH);
        content.add(grid, BorderLayout.CENTER);
        content.revalidate();
        content.repaint();
    }

    private JPanel buildDayCell(
        LocalDate cellDate,
        YearMonth month,
        LocalDate focusDate,
        LocalDate today,
        List<CalendarEvent> dayEvents,
        Map<String, CourseCalendar> calendars,
        UiTheme theme,
        Consumer<LocalDate> onDateSelected,
        Consumer<LocalDate> onCreateEvent,
        Consumer<CalendarEvent> onEventSelected
    ) {
        Color borderColor = soft(theme.getSurfaceColor(), Color.BLACK, 0.18);
        Color selected = soft(theme.getSurfaceColor(), theme.getAccentColor(), 0.18);

        JPanel cell = new JPanel(new BorderLayout(0, 4));
        cell.setBackground(cellDate.equals(focusDate) ? selected : theme.getSurfaceColor());
        cell.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(cellDate.equals(focusDate) ? theme.getAccentColor() : borderColor, cellDate.equals(focusDate) ? 2 : 1),
            BorderFactory.createEmptyBorder(6, 6, 6, 6)
        ));

        JLabel dayLabel = new JLabel(String.valueOf(cellDate.getDayOfMonth()));
        dayLabel.setForeground(month.equals(YearMonth.from(cellDate)) ? Color.BLACK : MUTED_TEXT);
        if (cellDate.equals(today)) {
            dayLabel.setForeground(theme.getAccentColor());
        }

        JPanel labelRow = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 0));
        labelRow.setOpaque(false);
        labelRow.add(dayLabel);

        JPanel eventList = new JPanel();
        eventList.setOpaque(false);
        eventList.setLayout(new BoxLayout(eventList, BoxLayout.Y_AXIS));

        int limit = Math.min(dayEvents.size(), 3);
        for (int index = 0; index < limit; index++) {
            CalendarEvent event = dayEvents.get(index);
            eventList.add(createEventButton(event, calendars, onEventSelected));
        }

        if (dayEvents.size() > limit) {
            JButton moreButton = new JButton("+" + (dayEvents.size() - limit) + " more");
            moreButton.setFocusable(false);
            moreButton.setBorder(BorderFactory.createEmptyBorder(4, 4, 4, 4));
            moreButton.setContentAreaFilled(false);
            moreButton.setForeground(MUTED_TEXT);
            moreButton.setHorizontalAlignment(SwingConstants.LEFT);
            moreButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            moreButton.addActionListener(e -> onDateSelected.accept(cellDate));
            eventList.add(moreButton);
        }

        cell.add(labelRow, BorderLayout.NORTH);
        cell.add(eventList, BorderLayout.CENTER);
        cell.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent event) {
                onDateSelected.accept(cellDate);
                if (event.getClickCount() >= 2) {
                    onCreateEvent.accept(cellDate);
                }
            }
        });
        return cell;
    }

    private JButton createEventButton(
        CalendarEvent event,
        Map<String, CourseCalendar> calendars,
        Consumer<CalendarEvent> onEventSelected
    ) {
        CourseCalendar calendar = calendars.get(event.getCourseId());
        Color color = calendar == null ? new Color(0x2D72D9) : calendar.getColor();

        JButton button = new JButton(event.getTimeLabel() + "  " + event.getTitle());
        button.setFocusable(false);
        button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        button.setBackground(color);
        button.setForeground(Color.WHITE);
        button.setHorizontalAlignment(SwingConstants.LEFT);
        button.setBorder(BorderFactory.createEmptyBorder(4, 6, 4, 6));
        button.addActionListener(e -> onEventSelected.accept(event));
        return button;
    }

    private Color soft(Color first, Color second, double amountSecond) {
        double amountFirst = 1.0 - amountSecond;
        int red = (int) Math.round((first.getRed() * amountFirst) + (second.getRed() * amountSecond));
        int green = (int) Math.round((first.getGreen() * amountFirst) + (second.getGreen() * amountSecond));
        int blue = (int) Math.round((first.getBlue() * amountFirst) + (second.getBlue() * amountSecond));
        return new Color(red, green, blue);
    }
}
