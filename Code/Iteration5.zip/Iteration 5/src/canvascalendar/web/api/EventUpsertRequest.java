package canvascalendar.web.api;

public record EventUpsertRequest(
    String title,
    String courseId,
    String start,
    String end,
    String location,
    String details
) {
}
