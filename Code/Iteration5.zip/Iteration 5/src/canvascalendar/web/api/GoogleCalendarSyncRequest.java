package canvascalendar.web.api;

public record GoogleCalendarSyncRequest(
    String feedUrl,
    String calendarName
) {
}
