package canvascalendar.web.api;

public record GoogleCalendarSyncResponse(
    int importedCalendars,
    int importedEvents
) {
}
