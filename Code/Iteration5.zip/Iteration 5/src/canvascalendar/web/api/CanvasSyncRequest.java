package canvascalendar.web.api;

public record CanvasSyncRequest(
    String baseUrl,
    String accessToken
) {
}
