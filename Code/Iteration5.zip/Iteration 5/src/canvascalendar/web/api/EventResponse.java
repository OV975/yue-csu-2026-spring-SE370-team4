package canvascalendar.web.api;

public record EventResponse(
    String id,
    String title,
    String courseId,
    String start,
    String end,
    String location,
    String details
) {
}
