package canvascalendar.web.api;

public record CalendarResponse(
    String id,
    String name,
    String color,
    boolean visible
) {
}
