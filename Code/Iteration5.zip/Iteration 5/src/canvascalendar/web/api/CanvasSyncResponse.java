package canvascalendar.web.api;

public record CanvasSyncResponse(
    int importedCalendars,
    int importedEvents
) {
}
