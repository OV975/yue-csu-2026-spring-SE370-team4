package canvascalendar.web.api;

public record CalendarUpdateRequest(
    Boolean visible
) {
}
