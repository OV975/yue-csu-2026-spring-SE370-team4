package canvascalendar.web.service;

import canvascalendar.integration.google.GoogleCalendarSyncConfig;
import canvascalendar.integration.google.GoogleCalendarSyncException;
import canvascalendar.integration.google.GoogleCalendarSyncService;
import canvascalendar.model.CalendarEvent;
import canvascalendar.model.CourseCalendar;
import canvascalendar.model.SampleDataFactory;
import canvascalendar.storage.CourseCalendarStore;
import canvascalendar.storage.EventStore;
import canvascalendar.web.api.AppStateResponse;
import canvascalendar.web.api.CalendarResponse;
import canvascalendar.web.api.EventResponse;
import canvascalendar.web.api.EventUpsertRequest;
import canvascalendar.web.api.GoogleCalendarSyncResponse;
import java.awt.Color;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import org.springframework.stereotype.Service;

@Service
public final class CalendarWebService {
    private final EventStore eventStore = new EventStore(Paths.get("data", "events.db"));
    private final CourseCalendarStore calendarStore = new CourseCalendarStore(Paths.get("data", "calendars.db"));
    private final GoogleCalendarSyncService googleCalendarSyncService = new GoogleCalendarSyncService();

    private final List<CourseCalendar> calendars = new ArrayList<>();
    private final List<CalendarEvent> events = new ArrayList<>();
    private final Map<String, CourseCalendar> calendarIndex = new HashMap<>();

    public CalendarWebService() {
        loadState();
    }

    public synchronized AppStateResponse getState() {
        return new AppStateResponse(toCalendarResponses(), toEventResponses());
    }

    public synchronized EventResponse createEvent(EventUpsertRequest request) {
        CalendarEvent event = mapRequest(UUID.randomUUID().toString(), request);
        events.add(event);
        sortAndSave();
        return toEventResponse(event);
    }

    public synchronized EventResponse updateEvent(String id, EventUpsertRequest request) {
        CalendarEvent updated = mapRequest(id, request);
        for (int index = 0; index < events.size(); index++) {
            if (events.get(index).getId().equals(id)) {
                events.set(index, updated);
                sortAndSave();
                return toEventResponse(updated);
            }
        }
        throw new IllegalArgumentException("Event not found: " + id);
    }

    public synchronized void deleteEvent(String id) {
        boolean removed = events.removeIf(event -> event.getId().equals(id));
        if (!removed) {
            throw new IllegalArgumentException("Event not found: " + id);
        }
        save();
    }

    public synchronized CalendarResponse updateCalendar(String calendarId, Boolean visible) {
        CourseCalendar calendar = calendarIndex.get(calendarId);
        if (calendar == null) {
            throw new IllegalArgumentException("Calendar not found: " + calendarId);
        }
        if (visible != null) {
            calendar.setVisible(visible);
        }
        save();
        return toCalendarResponse(calendar);
    }

    public synchronized GoogleCalendarSyncResponse syncGoogleCalendar(String feedUrl, String calendarName) throws GoogleCalendarSyncException {
        GoogleCalendarSyncService.SyncResult result =
            googleCalendarSyncService.sync(new GoogleCalendarSyncConfig(feedUrl, calendarName));
        mergeGoogleCalendarSync(result);
        save();
        return new GoogleCalendarSyncResponse(1, result.events().size());
    }

    private void loadState() {
        try {
            events.addAll(eventStore.load());
        } catch (Exception ignored) {
            events.clear();
        }

        try {
            calendars.addAll(calendarStore.load());
        } catch (Exception ignored) {
            calendars.clear();
        }

        if (calendars.isEmpty()) {
            calendars.addAll(SampleDataFactory.createCalendars());
        }
        if (events.isEmpty()) {
            events.addAll(SampleDataFactory.createEvents(java.time.LocalDate.now()));
        }

        ensureCalendarsForEvents();
        rebuildCalendarIndex();
        sortAndSave();
    }

    private void ensureCalendarsForEvents() {
        Set<String> knownIds = new HashSet<>();
        for (CourseCalendar calendar : calendars) {
            knownIds.add(calendar.getId());
        }
        for (CalendarEvent event : events) {
            if (knownIds.contains(event.getCourseId())) {
                continue;
            }
            CourseCalendar fallback = new CourseCalendar(event.getCourseId(), "Imported Calendar", new Color(0x6B7280));
            calendars.add(fallback);
            knownIds.add(event.getCourseId());
        }
    }

    private void mergeGoogleCalendarSync(GoogleCalendarSyncService.SyncResult result) {
        CourseCalendar syncedCalendar = result.calendar();
        CourseCalendar existing = calendarIndex.get(syncedCalendar.getId());
        if (existing == null) {
            calendars.add(syncedCalendar);
        } else {
            syncedCalendar.setVisible(existing.isVisible());
            existing.setName(syncedCalendar.getName());
            existing.setColor(syncedCalendar.getColor());
        }

        events.removeIf(event ->
            syncedCalendar.getId().equals(event.getCourseId()) && GoogleCalendarSyncService.isGoogleManagedEvent(event.getId())
        );
        events.addAll(result.events());
        ensureCalendarsForEvents();
        rebuildCalendarIndex();
        sortAndSave();
    }

    private CalendarEvent mapRequest(String id, EventUpsertRequest request) {
        if (request == null) {
            throw new IllegalArgumentException("Request body is required.");
        }
        if (isBlank(request.title()) || isBlank(request.courseId()) || isBlank(request.start()) || isBlank(request.end())) {
            throw new IllegalArgumentException("Title, calendar, start, and end are required.");
        }
        if (!calendarIndex.containsKey(request.courseId())) {
            throw new IllegalArgumentException("Unknown calendar: " + request.courseId());
        }
        try {
            LocalDateTime start = LocalDateTime.parse(request.start());
            LocalDateTime end = LocalDateTime.parse(request.end());
            if (!end.isAfter(start)) {
                throw new IllegalArgumentException("End must be after start.");
            }
            return new CalendarEvent(
                id,
                request.title().trim(),
                request.courseId().trim(),
                start,
                end,
                request.location() == null ? "" : request.location().trim(),
                request.details() == null ? "" : request.details().trim()
            );
        } catch (DateTimeParseException error) {
            throw new IllegalArgumentException("Dates must use ISO local date-time format, for example 2026-04-12T14:00.");
        }
    }

    private List<CalendarResponse> toCalendarResponses() {
        List<CalendarResponse> response = new ArrayList<>();
        for (CourseCalendar calendar : calendars) {
            response.add(toCalendarResponse(calendar));
        }
        return response;
    }

    private CalendarResponse toCalendarResponse(CourseCalendar calendar) {
        return new CalendarResponse(
            calendar.getId(),
            calendar.getName(),
            toHex(calendar.getColor()),
            calendar.isVisible()
        );
    }

    private List<EventResponse> toEventResponses() {
        List<EventResponse> response = new ArrayList<>();
        for (CalendarEvent event : events) {
            response.add(toEventResponse(event));
        }
        return response;
    }

    private EventResponse toEventResponse(CalendarEvent event) {
        return new EventResponse(
            event.getId(),
            event.getTitle(),
            event.getCourseId(),
            event.getStart().toString(),
            event.getEnd().toString(),
            event.getLocation(),
            event.getDetails()
        );
    }

    private void rebuildCalendarIndex() {
        calendarIndex.clear();
        for (CourseCalendar calendar : calendars) {
            calendarIndex.put(calendar.getId(), calendar);
        }
    }

    private void sortAndSave() {
        events.sort(CalendarEvent.BY_START);
        save();
    }

    private void save() {
        try {
            eventStore.save(events);
            calendarStore.save(calendars);
        } catch (Exception error) {
            throw new IllegalStateException("Unable to persist calendar data.", error);
        }
    }

    private String toHex(Color color) {
        return String.format("#%02X%02X%02X", color.getRed(), color.getGreen(), color.getBlue());
    }

    private boolean isBlank(String value) {
        return value == null || value.trim().isEmpty();
    }
}
