package canvascalendar;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CanvasCalendarWebApplication {
    public static void main(String[] args) {
        SpringApplication.run(CanvasCalendarWebApplication.class, args);
    }
}
