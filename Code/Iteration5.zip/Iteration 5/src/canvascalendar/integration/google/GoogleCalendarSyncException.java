package canvascalendar.integration.google;

public final class GoogleCalendarSyncException extends Exception {
    public GoogleCalendarSyncException(String message) {
        super(message);
    }

    public GoogleCalendarSyncException(String message, Throwable cause) {
        super(message, cause);
    }
}
