package canvascalendar.integration.google;

import canvascalendar.model.CalendarEvent;
import canvascalendar.model.CourseCalendar;
import java.awt.Color;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.DayOfWeek;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.temporal.TemporalAdjusters;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

public final class GoogleCalendarSyncService {
    private static final DateTimeFormatter BASIC_DATE = DateTimeFormatter.BASIC_ISO_DATE;
    private static final DateTimeFormatter BASIC_DATE_TIME = DateTimeFormatter.ofPattern("yyyyMMdd'T'HHmmss");
    private static final DateTimeFormatter BASIC_DATE_TIME_MINUTES = DateTimeFormatter.ofPattern("yyyyMMdd'T'HHmm");
    private static final Duration DEFAULT_PAST_WINDOW = Duration.ofDays(120);
    private static final Duration DEFAULT_FUTURE_WINDOW = Duration.ofDays(400);
    private static final int MAX_RECURRENCE_OCCURRENCES = 500;
    private static final String GOOGLE_EVENT_PREFIX = "google-event:";
    private static final String GOOGLE_CALENDAR_PREFIX = "google-calendar:";

    private final HttpClient httpClient;

    public GoogleCalendarSyncService() {
        this(HttpClient.newHttpClient());
    }

    GoogleCalendarSyncService(HttpClient httpClient) {
        this.httpClient = Objects.requireNonNull(httpClient, "httpClient");
    }

    public SyncResult sync(GoogleCalendarSyncConfig config) throws GoogleCalendarSyncException {
        if (config == null || isBlank(config.feedUrl())) {
            throw new IllegalArgumentException("A Google Calendar iCal URL is required.");
        }

        String normalizedUrl = config.feedUrl().trim();
        URI uri = parseUri(normalizedUrl);
        String payload = downloadCalendar(uri);
        IcsCalendar calendar = parseCalendar(payload);
        String calendarId = GOOGLE_CALENDAR_PREFIX + sha1(normalizedUrl);
        String calendarName = firstNonBlank(config.calendarName(), calendar.name(), "Google Calendar");
        CourseCalendar courseCalendar = new CourseCalendar(calendarId, calendarName, colorFromKey(calendarId));

        List<CalendarEvent> events = buildEvents(calendar.events(), calendarId);
        return new SyncResult(courseCalendar, events);
    }

    public static boolean isGoogleManagedEvent(String eventId) {
        return eventId != null && eventId.startsWith(GOOGLE_EVENT_PREFIX);
    }

    public static boolean isGoogleManagedCourse(String calendarId) {
        return calendarId != null && calendarId.startsWith(GOOGLE_CALENDAR_PREFIX);
    }

    private URI parseUri(String value) {
        try {
            URI uri = new URI(value);
            if (isBlank(uri.getScheme()) || isBlank(uri.getHost())) {
                throw new IllegalArgumentException("Enter a full Google Calendar iCal URL.");
            }
            return uri;
        } catch (URISyntaxException error) {
            throw new IllegalArgumentException("Enter a valid Google Calendar iCal URL.");
        }
    }

    private String downloadCalendar(URI uri) throws GoogleCalendarSyncException {
        HttpRequest request = HttpRequest.newBuilder(uri)
            .GET()
            .header("Accept", "text/calendar, text/plain;q=0.9, */*;q=0.1")
            .build();

        try {
            HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
            if (response.statusCode() < 200 || response.statusCode() >= 300) {
                throw new GoogleCalendarSyncException("Google Calendar sync failed with HTTP " + response.statusCode() + ".");
            }
            return response.body();
        } catch (IOException | InterruptedException error) {
            if (error instanceof InterruptedException) {
                Thread.currentThread().interrupt();
            }
            throw new GoogleCalendarSyncException("Unable to download the Google Calendar feed.", error);
        }
    }

    private IcsCalendar parseCalendar(String payload) throws GoogleCalendarSyncException {
        if (isBlank(payload)) {
            throw new GoogleCalendarSyncException("The Google Calendar feed was empty.");
        }

        List<String> lines = unfoldLines(payload);
        String calendarName = null;
        List<IcsEvent> events = new ArrayList<>();
        List<IcsProperty> currentEventProperties = null;

        for (String line : lines) {
            if ("BEGIN:VEVENT".equals(line)) {
                currentEventProperties = new ArrayList<>();
                continue;
            }
            if ("END:VEVENT".equals(line)) {
                if (currentEventProperties != null) {
                    events.add(parseEvent(currentEventProperties));
                    currentEventProperties = null;
                }
                continue;
            }
            if (currentEventProperties != null) {
                currentEventProperties.add(parseProperty(line));
                continue;
            }
            IcsProperty property = parseProperty(line);
            if ("X-WR-CALNAME".equals(property.name())) {
                calendarName = unescapeText(property.value());
            }
        }

        return new IcsCalendar(calendarName, events);
    }

    private List<CalendarEvent> buildEvents(List<IcsEvent> icsEvents, String calendarId) {
        List<CalendarEvent> result = new ArrayList<>();
        Map<String, Set<LocalDateTime>> overriddenStarts = collectOverrides(icsEvents);

        for (IcsEvent event : icsEvents) {
            if (event.cancelled() || event.start() == null) {
                continue;
            }

            if (event.recurrenceId() != null) {
                addOccurrence(result, calendarId, event, event.recurrenceId(), event.end());
                continue;
            }

            if (isBlank(event.rrule())) {
                addOccurrence(result, calendarId, event, event.start(), event.end());
                continue;
            }

            expandRecurringEvent(result, calendarId, event, overriddenStarts.getOrDefault(event.uid(), Collections.emptySet()));
        }

        result.sort(CalendarEvent.BY_START);
        return result;
    }

    private Map<String, Set<LocalDateTime>> collectOverrides(List<IcsEvent> icsEvents) {
        Map<String, Set<LocalDateTime>> overriddenStarts = new HashMap<>();
        for (IcsEvent event : icsEvents) {
            if (event.recurrenceId() == null || isBlank(event.uid())) {
                continue;
            }
            overriddenStarts.computeIfAbsent(event.uid(), ignored -> new HashSet<>()).add(event.recurrenceId());
        }
        return overriddenStarts;
    }

    private void expandRecurringEvent(
        List<CalendarEvent> result,
        String calendarId,
        IcsEvent event,
        Set<LocalDateTime> overriddenStarts
    ) {
        Map<String, String> rule = parseRule(event.rrule());
        String frequency = rule.getOrDefault("FREQ", "").toUpperCase(Locale.ROOT);
        if (frequency.isEmpty()) {
            addOccurrence(result, calendarId, event, event.start(), event.end());
            return;
        }

        int interval = parsePositiveInt(rule.get("INTERVAL"), 1);
        Integer count = parseOptionalPositiveInt(rule.get("COUNT"));
        LocalDateTime until = parseUntil(rule.get("UNTIL"), event.start());
        Duration duration = Duration.between(event.start(), event.end());
        LocalDateTime minimumStart = LocalDateTime.now().minus(DEFAULT_PAST_WINDOW);
        LocalDateTime maximumStart = LocalDateTime.now().plus(DEFAULT_FUTURE_WINDOW);
        Set<LocalDateTime> excludedStarts = new HashSet<>(event.exDates());
        excludedStarts.addAll(overriddenStarts);

        switch (frequency) {
            case "DAILY" -> expandDaily(result, calendarId, event, duration, interval, count, until, minimumStart, maximumStart, excludedStarts);
            case "WEEKLY" -> expandWeekly(result, calendarId, event, duration, interval, count, until, minimumStart, maximumStart, excludedStarts, rule.get("BYDAY"));
            case "MONTHLY" -> expandMonthly(result, calendarId, event, duration, interval, count, until, minimumStart, maximumStart, excludedStarts);
            case "YEARLY" -> expandYearly(result, calendarId, event, duration, interval, count, until, minimumStart, maximumStart, excludedStarts);
            default -> addOccurrence(result, calendarId, event, event.start(), event.end());
        }
    }

    private void expandDaily(
        List<CalendarEvent> result,
        String calendarId,
        IcsEvent event,
        Duration duration,
        int interval,
        Integer count,
        LocalDateTime until,
        LocalDateTime minimumStart,
        LocalDateTime maximumStart,
        Set<LocalDateTime> excludedStarts
    ) {
        LocalDateTime occurrenceStart = event.start();
        int occurrenceIndex = 0;
        while (shouldContinue(occurrenceStart, occurrenceIndex, count, until, maximumStart)) {
            maybeAddOccurrence(result, calendarId, event, occurrenceStart, duration, minimumStart, maximumStart, excludedStarts);
            occurrenceStart = occurrenceStart.plusDays(interval);
            occurrenceIndex += 1;
        }
    }

    private void expandWeekly(
        List<CalendarEvent> result,
        String calendarId,
        IcsEvent event,
        Duration duration,
        int interval,
        Integer count,
        LocalDateTime until,
        LocalDateTime minimumStart,
        LocalDateTime maximumStart,
        Set<LocalDateTime> excludedStarts,
        String byDayRule
    ) {
        List<DayOfWeek> recurrenceDays = parseByDays(byDayRule, event.start().getDayOfWeek());
        LocalDate baseDate = event.start().toLocalDate();
        LocalDate weekStart = baseDate.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY));
        int occurrenceIndex = 0;

        while (occurrenceIndex < MAX_RECURRENCE_OCCURRENCES) {
            for (DayOfWeek dayOfWeek : recurrenceDays) {
                LocalDate occurrenceDate = weekStart.plusDays(dayOfWeek.getValue() - 1L);
                LocalDateTime occurrenceStart = LocalDateTime.of(occurrenceDate, event.start().toLocalTime());
                if (occurrenceStart.isBefore(event.start())) {
                    continue;
                }
                if (!shouldContinue(occurrenceStart, occurrenceIndex, count, until, maximumStart)) {
                    return;
                }
                maybeAddOccurrence(result, calendarId, event, occurrenceStart, duration, minimumStart, maximumStart, excludedStarts);
                occurrenceIndex += 1;
            }
            weekStart = weekStart.plusWeeks(interval);
        }
    }

    private void expandMonthly(
        List<CalendarEvent> result,
        String calendarId,
        IcsEvent event,
        Duration duration,
        int interval,
        Integer count,
        LocalDateTime until,
        LocalDateTime minimumStart,
        LocalDateTime maximumStart,
        Set<LocalDateTime> excludedStarts
    ) {
        LocalDateTime occurrenceStart = event.start();
        int occurrenceIndex = 0;
        while (shouldContinue(occurrenceStart, occurrenceIndex, count, until, maximumStart)) {
            maybeAddOccurrence(result, calendarId, event, occurrenceStart, duration, minimumStart, maximumStart, excludedStarts);
            occurrenceStart = occurrenceStart.plusMonths(interval);
            occurrenceIndex += 1;
        }
    }

    private void expandYearly(
        List<CalendarEvent> result,
        String calendarId,
        IcsEvent event,
        Duration duration,
        int interval,
        Integer count,
        LocalDateTime until,
        LocalDateTime minimumStart,
        LocalDateTime maximumStart,
        Set<LocalDateTime> excludedStarts
    ) {
        LocalDateTime occurrenceStart = event.start();
        int occurrenceIndex = 0;
        while (shouldContinue(occurrenceStart, occurrenceIndex, count, until, maximumStart)) {
            maybeAddOccurrence(result, calendarId, event, occurrenceStart, duration, minimumStart, maximumStart, excludedStarts);
            occurrenceStart = occurrenceStart.plusYears(interval);
            occurrenceIndex += 1;
        }
    }

    private boolean shouldContinue(
        LocalDateTime occurrenceStart,
        int occurrenceIndex,
        Integer count,
        LocalDateTime until,
        LocalDateTime maximumStart
    ) {
        if (occurrenceIndex >= MAX_RECURRENCE_OCCURRENCES) {
            return false;
        }
        if (count != null && occurrenceIndex >= count) {
            return false;
        }
        if (until != null && occurrenceStart.isAfter(until)) {
            return false;
        }
        return !occurrenceStart.isAfter(maximumStart);
    }

    private void maybeAddOccurrence(
        List<CalendarEvent> result,
        String calendarId,
        IcsEvent event,
        LocalDateTime occurrenceStart,
        Duration duration,
        LocalDateTime minimumStart,
        LocalDateTime maximumStart,
        Set<LocalDateTime> excludedStarts
    ) {
        if (excludedStarts.contains(occurrenceStart)) {
            return;
        }
        if (occurrenceStart.isBefore(minimumStart) || occurrenceStart.isAfter(maximumStart)) {
            return;
        }
        addOccurrence(result, calendarId, event, occurrenceStart, occurrenceStart.plus(duration));
    }

    private void addOccurrence(
        List<CalendarEvent> result,
        String calendarId,
        IcsEvent event,
        LocalDateTime occurrenceStart,
        LocalDateTime occurrenceEnd
    ) {
        LocalDateTime safeEnd = occurrenceEnd != null && occurrenceEnd.isAfter(occurrenceStart)
            ? occurrenceEnd
            : occurrenceStart.plusHours(1);
        String occurrenceKey = occurrenceStart.toString().replace(":", "-");
        String uid = isBlank(event.uid()) ? sha1(event.title() + occurrenceStart) : sha1(event.uid());
        result.add(new CalendarEvent(
            GOOGLE_EVENT_PREFIX + uid + ":" + occurrenceKey,
            firstNonBlank(event.title(), null, "Google Calendar Event"),
            calendarId,
            occurrenceStart,
            safeEnd,
            firstNonBlank(event.location(), null, ""),
            firstNonBlank(event.description(), null, "")
        ));
    }

    private IcsEvent parseEvent(List<IcsProperty> properties) {
        Map<String, List<IcsProperty>> grouped = new LinkedHashMap<>();
        for (IcsProperty property : properties) {
            grouped.computeIfAbsent(property.name(), ignored -> new ArrayList<>()).add(property);
        }

        IcsProperty startProperty = firstProperty(grouped, "DTSTART");
        LocalDateTime start = parseDateTime(startProperty);
        boolean allDay = isAllDay(startProperty);
        LocalDateTime end = parseDateTime(firstProperty(grouped, "DTEND"));
        if (end == null && start != null) {
            end = allDay ? start.plusDays(1) : start.plusHours(1);
        }

        Set<LocalDateTime> exDates = new HashSet<>();
        for (IcsProperty property : grouped.getOrDefault("EXDATE", List.of())) {
            exDates.addAll(parseExDates(property));
        }

        return new IcsEvent(
            valueOf(grouped, "UID"),
            unescapeText(valueOf(grouped, "SUMMARY")),
            unescapeText(valueOf(grouped, "DESCRIPTION")),
            unescapeText(valueOf(grouped, "LOCATION")),
            start,
            end,
            valueOf(grouped, "RRULE"),
            exDates,
            parseDateTime(firstProperty(grouped, "RECURRENCE-ID")),
            "CANCELLED".equalsIgnoreCase(valueOf(grouped, "STATUS"))
        );
    }

    private Set<LocalDateTime> parseExDates(IcsProperty property) {
        if (property == null || isBlank(property.value())) {
            return Collections.emptySet();
        }
        Set<LocalDateTime> values = new HashSet<>();
        String[] split = property.value().split(",");
        for (String value : split) {
            LocalDateTime parsed = parseDateTime(new IcsProperty(property.name(), property.params(), value.trim()));
            if (parsed != null) {
                values.add(parsed);
            }
        }
        return values;
    }

    private Map<String, String> parseRule(String value) {
        if (isBlank(value)) {
            return Collections.emptyMap();
        }
        Map<String, String> rule = new HashMap<>();
        for (String part : value.split(";")) {
            int separator = part.indexOf('=');
            if (separator <= 0 || separator == part.length() - 1) {
                continue;
            }
            rule.put(part.substring(0, separator).toUpperCase(Locale.ROOT), part.substring(separator + 1));
        }
        return rule;
    }

    private LocalDateTime parseUntil(String value, LocalDateTime fallbackReference) {
        if (isBlank(value)) {
            return null;
        }
        IcsProperty property = new IcsProperty("UNTIL", Map.of(), value);
        LocalDateTime parsed = parseDateTime(property);
        return parsed != null ? parsed : fallbackReference.plus(DEFAULT_FUTURE_WINDOW);
    }

    private List<DayOfWeek> parseByDays(String value, DayOfWeek fallback) {
        if (isBlank(value)) {
            return List.of(fallback);
        }
        List<DayOfWeek> days = new ArrayList<>();
        for (String token : value.split(",")) {
            DayOfWeek day = mapDayOfWeek(token.trim());
            if (day != null) {
                days.add(day);
            }
        }
        if (days.isEmpty()) {
            days.add(fallback);
        }
        days.sort(Comparator.naturalOrder());
        return days;
    }

    private DayOfWeek mapDayOfWeek(String token) {
        return switch (token) {
            case "MO" -> DayOfWeek.MONDAY;
            case "TU" -> DayOfWeek.TUESDAY;
            case "WE" -> DayOfWeek.WEDNESDAY;
            case "TH" -> DayOfWeek.THURSDAY;
            case "FR" -> DayOfWeek.FRIDAY;
            case "SA" -> DayOfWeek.SATURDAY;
            case "SU" -> DayOfWeek.SUNDAY;
            default -> null;
        };
    }

    private LocalDateTime parseDateTime(IcsProperty property) {
        if (property == null || isBlank(property.value())) {
            return null;
        }

        String value = property.value().trim();
        String tzid = property.params().get("TZID");
        String valueType = property.params().get("VALUE");
        if ("DATE".equalsIgnoreCase(valueType) || value.length() == 8) {
            LocalDate date = LocalDate.parse(value.substring(0, 8), BASIC_DATE);
            return date.atStartOfDay();
        }

        try {
            if (value.endsWith("Z")) {
                return parseUtcDateTime(value);
            }
            LocalDateTime localDateTime = parseLocalDateTime(value);
            if (!isBlank(tzid)) {
                ZoneId zoneId = ZoneId.of(tzid.replace("\"", ""));
                return ZonedDateTime.of(localDateTime, zoneId).withZoneSameInstant(ZoneId.systemDefault()).toLocalDateTime();
            }
            return localDateTime;
        } catch (RuntimeException error) {
            return null;
        }
    }

    private LocalDateTime parseUtcDateTime(String value) {
        String trimmed = value.substring(0, value.length() - 1);
        if (trimmed.length() == 15) {
            LocalDateTime utcTime = LocalDateTime.parse(trimmed, BASIC_DATE_TIME);
            return utcTime.atZone(ZoneOffset.UTC).withZoneSameInstant(ZoneId.systemDefault()).toLocalDateTime();
        }
        LocalDateTime utcTime = LocalDateTime.parse(trimmed, BASIC_DATE_TIME_MINUTES);
        return utcTime.atZone(ZoneOffset.UTC).withZoneSameInstant(ZoneId.systemDefault()).toLocalDateTime();
    }

    private LocalDateTime parseLocalDateTime(String value) {
        if (value.length() == 15) {
            return LocalDateTime.parse(value, BASIC_DATE_TIME);
        }
        if (value.length() == 13) {
            return LocalDateTime.parse(value, BASIC_DATE_TIME_MINUTES);
        }
        if (value.length() == 8) {
            return LocalDate.parse(value, BASIC_DATE).atStartOfDay();
        }
        throw new DateTimeParseException("Unsupported ICS date/time", value, 0);
    }

    private boolean isAllDay(IcsProperty property) {
        if (property == null) {
            return false;
        }
        return "DATE".equalsIgnoreCase(property.params().get("VALUE")) || property.value().trim().length() == 8;
    }

    private IcsProperty firstProperty(Map<String, List<IcsProperty>> grouped, String name) {
        List<IcsProperty> properties = grouped.get(name);
        return properties == null || properties.isEmpty() ? null : properties.get(0);
    }

    private String valueOf(Map<String, List<IcsProperty>> grouped, String name) {
        IcsProperty property = firstProperty(grouped, name);
        return property == null ? null : property.value();
    }

    private IcsProperty parseProperty(String line) {
        int separator = line.indexOf(':');
        if (separator < 0) {
            return new IcsProperty(line, Map.of(), "");
        }

        String nameAndParams = line.substring(0, separator);
        String value = line.substring(separator + 1);
        String[] segments = nameAndParams.split(";");
        String name = segments[0].toUpperCase(Locale.ROOT);
        Map<String, String> params = new LinkedHashMap<>();
        for (int index = 1; index < segments.length; index += 1) {
            int equalsIndex = segments[index].indexOf('=');
            if (equalsIndex <= 0 || equalsIndex == segments[index].length() - 1) {
                continue;
            }
            params.put(
                segments[index].substring(0, equalsIndex).toUpperCase(Locale.ROOT),
                segments[index].substring(equalsIndex + 1)
            );
        }
        return new IcsProperty(name, params, value);
    }

    private List<String> unfoldLines(String payload) {
        String[] rawLines = payload.replace("\r\n", "\n").replace('\r', '\n').split("\n");
        List<String> lines = new ArrayList<>();
        StringBuilder current = new StringBuilder();

        for (String rawLine : rawLines) {
            if (rawLine.startsWith(" ") || rawLine.startsWith("\t")) {
                current.append(rawLine.substring(1));
                continue;
            }
            if (current.length() > 0) {
                lines.add(current.toString());
            }
            current.setLength(0);
            current.append(rawLine);
        }
        if (current.length() > 0) {
            lines.add(current.toString());
        }
        return lines;
    }

    private String unescapeText(String value) {
        if (value == null) {
            return "";
        }
        return value
            .replace("\\n", "\n")
            .replace("\\N", "\n")
            .replace("\\,", ",")
            .replace("\\;", ";")
            .replace("\\\\", "\\");
    }

    private int parsePositiveInt(String value, int fallback) {
        Integer parsed = parseOptionalPositiveInt(value);
        return parsed == null ? fallback : parsed;
    }

    private Integer parseOptionalPositiveInt(String value) {
        if (isBlank(value)) {
            return null;
        }
        try {
            int parsed = Integer.parseInt(value);
            return parsed > 0 ? parsed : null;
        } catch (NumberFormatException error) {
            return null;
        }
    }

    private Color colorFromKey(String key) {
        int hueSeed = Math.abs(key.hashCode()) % 360;
        return Color.getHSBColor(hueSeed / 360f, 0.56f, 0.86f);
    }

    private String sha1(String value) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-1");
            byte[] bytes = digest.digest(value.getBytes(StandardCharsets.UTF_8));
            StringBuilder builder = new StringBuilder();
            for (byte current : bytes) {
                builder.append(String.format("%02x", current));
            }
            return builder.toString();
        } catch (NoSuchAlgorithmException error) {
            throw new IllegalStateException("SHA-1 is not available.", error);
        }
    }

    private String firstNonBlank(String first, String second, String fallback) {
        if (!isBlank(first)) {
            return first.trim();
        }
        if (!isBlank(second)) {
            return second.trim();
        }
        return fallback;
    }

    private boolean isBlank(String value) {
        return value == null || value.trim().isEmpty();
    }

    public record SyncResult(
        CourseCalendar calendar,
        List<CalendarEvent> events
    ) {
    }

    private record IcsCalendar(
        String name,
        List<IcsEvent> events
    ) {
    }

    private record IcsEvent(
        String uid,
        String title,
        String description,
        String location,
        LocalDateTime start,
        LocalDateTime end,
        String rrule,
        Set<LocalDateTime> exDates,
        LocalDateTime recurrenceId,
        boolean cancelled
    ) {
    }

    private record IcsProperty(
        String name,
        Map<String, String> params,
        String value
    ) {
    }
}
