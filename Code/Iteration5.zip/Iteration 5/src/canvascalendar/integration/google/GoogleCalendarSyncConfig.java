package canvascalendar.integration.google;

public record GoogleCalendarSyncConfig(
    String feedUrl,
    String calendarName
) {
}
